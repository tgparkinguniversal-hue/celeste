extends Control
signal picked(code:String)
signal placed(lon:float,lat:float)
var shapes:Array=[]
var countries:Array=[]
var selected=""
var zoom=2.6
var center=Vector2(5,8)
var dragging=false
var moved=false
var pointer=Vector2.ZERO
var placing=false
var sim: NationSim
var map_font:Font=ThemeDB.fallback_font
var fingers={}
var pinch_distance=0.0
func _ready():
 mouse_filter=Control.MOUSE_FILTER_STOP
 clip_contents=true
 var raw=JSON.parse_string(FileAccess.get_file_as_string("res://data/world.json"))
 for f in raw:
  var rings=[]
  for r in f.rings:
   var p=PackedVector2Array()
   for pt in r:p.append(Vector2(pt[0],-pt[1]))
   if p.size()>3:
    var rect=Rect2(p[0],Vector2.ZERO)
    for pt in p:rect=rect.expand(pt)
    var indices=Geometry2D.triangulate_polygon(p)
    var mesh=ArrayMesh.new()
    if indices.size()>0:
     var arrays=[];arrays.resize(Mesh.ARRAY_MAX);arrays[Mesh.ARRAY_VERTEX]=p;arrays[Mesh.ARRAY_INDEX]=indices
     mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
    rings.append({"points":p,"rect":rect,"mesh":mesh,"filled":indices.size()>0})
  shapes.append({"id":f.id,"name":f.name,"label":Vector2(f.label[0],-f.label[1]),"rings":rings,"color":f.color})
 gui_input.connect(on_input);resized.connect(queue_redraw)
func screen(p:Vector2)->Vector2:return (p-Vector2(center.x,-center.y))*zoom+size/2
func geo(p:Vector2)->Vector2:
 var v=(p-size/2)/zoom+Vector2(center.x,-center.y)
 return Vector2(v.x,-v.y)
func focus(code:String):
 selected=code
 for f in shapes:
  if f.id!=code:continue
  var bounds=Rect2(f.label,Vector2(.1,.1));var first=true
  for ring in f.rings:
   if ring.rect.size.x>160:continue
   if first:bounds=ring.rect;first=false
   else:bounds=bounds.merge(ring.rect)
  center=Vector2(bounds.get_center().x,-bounds.get_center().y)
  zoom=clampf(minf(size.x/maxf(bounds.size.x,.015),size.y/maxf(bounds.size.y,.015))*.7,2,30000)
  break
 queue_redraw()
func home():center=Vector2(5,8);zoom=minf(size.x/365,size.y/170);queue_redraw()
func zoom_at(mult:float,at:Vector2):
 var before=geo(at);zoom=clampf(zoom*mult,1.5,30000)
 var after=geo(at);center+=before-after;queue_redraw()
func on_input(event:InputEvent):
 if event is InputEventMouse and event.device==-1:return
 if event is InputEventScreenTouch:
  if event.pressed:fingers[event.index]=event.position;pointer=event.position;moved=false
  else:
   fingers.erase(event.index)
   if not moved:click(event.position)
   pinch_distance=0
  return
 if event is InputEventScreenDrag:
  fingers[event.index]=event.position;moved=true
  if fingers.size()==2:
   var vals=fingers.values();var d=vals[0].distance_to(vals[1])
   if pinch_distance>0:zoom_at(d/pinch_distance,(vals[0]+vals[1])/2)
   pinch_distance=d
  else:
   center+=Vector2(-event.relative.x,event.relative.y)/zoom;queue_redraw()
  return
 if event is InputEventMouseButton:
  if event.button_index==MOUSE_BUTTON_WHEEL_UP and event.pressed:zoom_at(1.2,event.position)
  elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN and event.pressed:zoom_at(1/1.2,event.position)
  elif event.button_index==MOUSE_BUTTON_LEFT:
   dragging=event.pressed
   if event.pressed:pointer=event.position;moved=false
   elif not moved:click(event.position)
 if event is InputEventMouseMotion and dragging:
  if event.position.distance_to(pointer)>4:moved=true
  if moved:center+=Vector2(-event.relative.x,event.relative.y)/zoom;queue_redraw()
func contains(code:String,p:Vector2)->bool:
 for f in shapes:
  if f.id!=code:continue
  for ring in f.rings:
   if ring.rect.has_point(Vector2(p.x,-p.y)) and Geometry2D.is_point_in_polygon(Vector2(p.x,-p.y),ring.points):return true
  return f.rings.is_empty() and p.distance_to(Vector2(f.label.x,-f.label.y))<.005
 return false
func click(at:Vector2):
 var p=geo(at)
 if placing:
  if contains(selected,p):placed.emit(p.x,p.y)
  else:placed.emit(999,999)
  return
 var best="";var dist=14.0
 for c in countries:
  var d=screen(Vector2(c.label[0],-c.label[1])).distance_to(at)
  if d<dist:dist=d;best=c.id
 if best!="":picked.emit(best);return
 for f in shapes:
  if contains(f.id,p):picked.emit(f.id);return
func _draw():
 draw_rect(Rect2(Vector2.ZERO,size),Color("244f6b"))
 # Geographic grid: fixed latitude and longitude, independent of zoom.
 var gridstep=30.0 if zoom<8 else (5.0 if zoom<40 else (1.0 if zoom<150 else .1))
 var nw=geo(Vector2.ZERO);var se=geo(size)
 var gx=floor(nw.x/gridstep)*gridstep
 while gx<se.x and gx<=180:
  if gx>=-180:draw_line(screen(Vector2(gx,90)),screen(Vector2(gx,-90)),Color(.75,.85,.9,.055),1)
  gx+=gridstep
 var gy=floor(se.y/gridstep)*gridstep
 while gy<nw.y and gy<=90:
  if gy>=-90:draw_line(screen(Vector2(-180,-gy)),screen(Vector2(180,-gy)),Color(.75,.85,.9,.055),1)
  gy+=gridstep
 var colors=[Color("91a28b"),Color("aeb18b"),Color("b7b591"),Color("96a285"),Color("a5b297"),Color("b7bda0"),Color("a1aa89"),Color("9cac91")]
 var view=Rect2(Vector2(nw.x,-nw.y),Vector2(se.x-nw.x,nw.y-se.y))
 for f in shapes:
  var fill=colors[int(f.color)%colors.size()]
  if f.id==selected:fill=Color("d6c48a")
  elif selected!="":fill=fill.darkened(.12)
  for ring in f.rings:
   if not view.intersects(ring.rect):continue
   if ring.rect.size.length()*zoom<1.2 and f.id!=selected:continue
   var ps=PackedVector2Array()
   for p in ring.points:ps.append(screen(p))
   if ring.filled:draw_mesh(ring.mesh,null,Transform2D(0,Vector2(zoom,zoom),0,size/2-Vector2(center.x,-center.y)*zoom),fill)
   draw_polyline(ps,Color("efce89") if f.id==selected else Color("687b71"),2 if f.id==selected else 1,true)
  var pos=screen(f.label)
  if Rect2(Vector2(20,30),size-Vector2(40,60)).has_point(pos) and (zoom>7 or f.id==selected):
   var font_size=14 if f.id!=selected else 18
   var text_size=map_font.get_string_size(f.name,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size)
   draw_string_outline(map_font,pos-text_size/2,f.name,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,3,Color(.06,.13,.17,.8))
   draw_string(map_font,pos-text_size/2,f.name,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color("f5edcf"))
 for c in countries:
  if c.id==selected:
   var pt=screen(Vector2(c.label[0],-c.label[1]));draw_circle(pt,5,Color("f5d78c"));draw_arc(pt,9,0,TAU,24,Color("fff2cd"),1.5,true)
 if sim!=null and not sim.s.is_empty():
  var idx=0
  for b in sim.s.buildings:
   var pos=screen(Vector2(b.lon,-b.lat))
   if b.initial:pos+=Vector2((idx%3-1)*45,(idx/3-1)*45+35)
   idx+=1
   if not Rect2(Vector2.ZERO,size).has_point(pos):continue
   draw_building(pos,b.kind)
  for p in sim.s.projects:
   var pos=screen(Vector2(p.lon,-p.lat));draw_arc(pos,12,-PI/2,-PI/2+TAU*maxf(p.progress,.02),32,Color("e8b75b"),4,true)
 # Scale bar calculates geodesic length at its actual latitude.
 var p1=geo(Vector2(28,size.y-44));var p2=geo(Vector2(148,size.y-44))
 var km=NationSim.distance_km(p1,p2)
 draw_line(Vector2(28,size.y-38),Vector2(148,size.y-38),Color("e8dfc4"),2)
 draw_string(map_font,Vector2(28,size.y-50),("%.0f km"%km if km>=1 else "%.0f m"%(km*1000)),HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("f5edcf"))
 draw_string(map_font,Vector2(28,size.y-14),"WGS84 • zoom %.1f×"%(zoom/2.5),HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("b5cbd1"))
 if placing:
  draw_rect(Rect2(Vector2(20,86),Vector2(minf(size.x-40,570),56)),Color(.05,.12,.17,.95))
  draw_string(map_font,Vector2(36,120),"Toque em terra no seu país para posicionar a obra.",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("f6d99a"))

func draw_building(pos:Vector2,kind:String):
 # Compact flat markers keep the map readable without miniature buildings.
 var colors={"city":"d5c48b","farm":"a2bb78","power":"edce6e","water":"7fbacb","factory":"b3bdc2","commerce":"d6aa7c","hospital":"df968b","school":"b7a7d6","warehouse":"a9b4a2"}
 var tint=Color(colors.get(kind,"d5c48b"))
 var marker=Rect2(pos-Vector2(17,12),Vector2(34,24))
 draw_rect(marker,Color("152b37"))
 draw_rect(marker,tint,false,1.5)
 var tag=NationSim.BUILDINGS[kind].tag
 var width=map_font.get_string_size(tag,HORIZONTAL_ALIGNMENT_LEFT,-1,11).x
 draw_string(map_font,pos+Vector2(-width/2,4),tag,HORIZONTAL_ALIGNMENT_LEFT,-1,11,tint)
