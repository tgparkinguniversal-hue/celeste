class_name NationSim
extends RefCounted
signal changed
const VERSION=1
const BUILDINGS={
 "city":{"name":"Cidade","cost":6000000,"days":18,"jobs":800,"housing":20000,"power":6,"water":120,"maint":20000,"tag":"CID"},
 "farm":{"name":"Fazenda","cost":1800000,"days":10,"jobs":300,"power":2,"water":100,"food":1800,"maint":15000,"tag":"AGR"},
 "power":{"name":"Usina elétrica","cost":4000000,"days":15,"jobs":150,"generation":120,"maint":50000,"tag":"ENE"},
 "water":{"name":"Estação de água","cost":2000000,"days":12,"jobs":100,"water_supply":1800,"power":3,"maint":25000,"tag":"AGU"},
 "factory":{"name":"Fábrica","cost":5000000,"days":20,"jobs":400,"power":12,"water":50,"maint":150000,"tag":"FAB"},
 "commerce":{"name":"Centro comercial","cost":1200000,"days":9,"jobs":250,"power":4,"water":20,"maint":12000,"tag":"COM"},
 "hospital":{"name":"Hospital","cost":3000000,"days":15,"jobs":200,"power":6,"water":80,"maint":80000,"tag":"SAU"},
 "school":{"name":"Universidade","cost":2200000,"days":14,"jobs":180,"power":4,"water":40,"maint":50000,"tag":"EDU"},
 "warehouse":{"name":"Centro logístico","cost":1500000,"days":10,"jobs":120,"power":3,"water":10,"maint":20000,"tag":"LOG"}
}
const COMPANIES=[{"name":"Horizonte Obras","price":1.0,"speed":1.0,"quality":1.0},{"name":"Vértice Express","price":1.2,"speed":1.5,"quality":.95},{"name":"Popular Engenharia","price":.85,"speed":.75,"quality":.9}]
var s:Dictionary={}
var metrics:Dictionary={}
var ledger:Array=[]
var error=""
func start(country:Dictionary,mode:String):
 ledger.clear();error=""
 var pop=100000.0
 var wealth=1.0
 if mode=="real":
  pop=float(country.population.value) if country.population.value!=null else 1000.0
  if country.gdp_current_usd.value!=null:
   wealth=clampf(float(country.gdp_current_usd.value)/maxf(pop,1.0)/20000.0,.3,4.0)
 var scale=maxf(pop/100000.0,.001)
 s={"version":VERSION,"country":country.duplicate(true),"mode":mode,"day":0,"cash":int(50000000.0*scale*wealth*100),"reserved":0,"scale":scale,"wealth":wealth,"population":pop,"tax_income":.10,"tax_profit":.15,"service_budget":1.0,"buildings":[],"projects":[],"deliveries":[],"equipment":10,"condition":1.0,"maintenance":true,"troops":1000.0*scale,"trainees":[],"research":0,"research_queue":0,"research_days":0,"debt":0,"food":50000.0*scale,"goods":5000.0*scale,"materials":5000.0*scale,"loan_used":false,"events":[],"next_id":1,"trade":true,"strategy":0,"strategy_order":0}
 for k in BUILDINGS:
  s.buildings.append({"id":s.next_id,"kind":k,"lon":float(country.label[0]),"lat":float(country.label[1]),"initial":true,"quality":1.0});s.next_id+=1
 log_event("Mandato iniciado. Economia e construções usam dias simulados.")
 calculate()
func money(v:float)->int:return int(round(v*s.scale*s.wealth*100.0))
func available()->int:return int(s.cash)-int(s.reserved)
func record(amount:int,reason:String):
 ledger.append({"day":s.day,"amount":amount,"reason":reason})
 if ledger.size()>100:ledger.pop_front()
func spend(cents:int,reason:String)->bool:
 if cents<0 or available()<cents:error="Saldo disponível insuficiente.";return false
 s.cash-=cents
 record(-cents,reason)
 return true
func log_event(msg:String):
 s.events.push_front("Dia %d • %s"%[s.day,msg])
 if s.events.size()>50:s.events.pop_back()
func order_build(kind:String,company:int,lon:float,lat:float)->bool:
 if not BUILDINGS.has(kind) or company<0 or company>=COMPANIES.size():return false
 var cost=money(float(BUILDINGS[kind].cost)*float(COMPANIES[company].price))
 if available()<cost:error="Não há verba livre para reservar a obra.";return false
 var item={"id":s.next_id,"kind":kind,"company":company,"cost":cost,"paid":0,"progress":0.0,"lon":lon,"lat":lat}
 s.next_id+=1;s.reserved+=cost;s.projects.append(item)
 log_event("Obra contratada: "+BUILDINGS[kind].name);calculate();changed.emit();return true
func cancel_project(id:int)->bool:
 for i in range(s.projects.size()):
  var p=s.projects[i]
  if int(p.id)==id:
   s.reserved-=int(p.cost)-int(p.paid);s.projects.remove_at(i);log_event("Obra cancelada; somente a reserva não gasta foi liberada.");changed.emit();return true
 return false
func buy_equipment(qty:int)->bool:
 if qty<=0 or qty>100:return false
 if not spend(money(qty*100000),"Compra de equipamentos"):return false
 s.deliveries.append({"qty":qty,"days":5});log_event("Equipamentos comprados; entrega em 5 dias.");changed.emit();return true
func recruit(qty:float)->bool:
 calculate();qty=round(qty*s.scale)
 if qty<=0 or qty>float(metrics.unemployed):error="Não há trabalhadores disponíveis.";return false
 if not spend(money(qty/s.scale*1000),"Formação militar"):return false
 s.trainees.append({"qty":qty,"days":15});calculate();changed.emit();return true
func demobilize():
 var qty=minf(s.troops,500*s.scale);s.troops-=qty;log_event("%d militares voltaram à força de trabalho."%qty);calculate();changed.emit()
func research()->bool:
 if s.research_queue>0 or s.research>=5:error="Pesquisa em andamento ou todos os níveis concluídos.";return false
 if not spend(money(1500000*(s.research+1)),"Pesquisa"):return false
 s.research_queue=s.research+1;s.research_days=25;log_event("Pesquisa de eficiência iniciada.");changed.emit();return true
func buy_strategy()->bool:
 if s.research<3:error="Exige pesquisa nível 3.";return false
 if not spend(money(20000000),"Programa estratégico abstrato"):return false
 s.strategy_order+=1;log_event("Unidade estratégica encomendada: 60 dias, sem combate nesta versão.");s.deliveries.append({"qty":0,"days":60,"strategic":true});changed.emit();return true
func loan()->bool:
 if s.loan_used:error="Crédito emergencial já utilizado.";return false
 var amount=money(20000000);s.cash+=amount;s.debt+=amount;record(amount,"Crédito emergencial");s.loan_used=true;log_event("Crédito recebido; juros de 1% por mês.");changed.emit();return true
func repay()->bool:
 var amount=mini(available(),int(s.debt))
 if amount<=0:return false
 s.cash-=amount;s.debt-=amount;record(-amount,"Amortização de dívida");changed.emit();return true
func count_kind(kind:String)->int:
 var n=0
 for b in s.buildings:
  if b.kind==kind:n+=1
 return n
func calculate():
 if s.is_empty():return
 var scale=float(s.scale);var pop=float(s.population);var housing=100000.0*scale
 var jobs=26000.0*scale;var power=pop*.0004;var generation=0.0;var water=pop*.01;var supply=0.0;var food=0.0;var maint=0.0
 var workforce=pop*.5;var training=0.0
 for t in s.trainees:training+=t.qty
 var private_jobs=26000.0*scale;var gov_jobs=0.0
 for b in s.buildings:
  var d=BUILDINGS[b.kind];jobs+=float(d.get("jobs",0))*scale;housing+=float(d.get("housing",0))*scale
  power+=float(d.get("power",0))*scale;generation+=float(d.get("generation",0))*scale
  water+=float(d.get("water",0))*scale;supply+=float(d.get("water_supply",0))*scale;food+=float(d.get("food",0))*scale
  maint+=float(d.get("maint",0))*scale*s.wealth
  if b.kind in ["hospital","school","power","water","warehouse"]:gov_jobs+=float(d.jobs)*scale
  else:private_jobs+=float(d.jobs)*scale
 var labor=clampf((workforce-s.troops-training)/maxf(jobs,1.0),0,1)
 var energy=clampf(generation/maxf(power,1.0),0,1)
 var water_ratio=clampf(supply/maxf(water,1.0),0,1)
 var logistics=clampf(.4+count_kind("warehouse")*.6/maxf(count_kind("factory"),1),.2,1)
 var equip=clampf(.5+float(s.equipment)/(20.0*maxi(count_kind("factory"),1)),.5,1)*float(s.condition)
 var quality=0.0
 for b in s.buildings:quality+=float(b.get("quality",1))
 quality/=maxi(s.buildings.size(),1)
 var productivity=minf(labor,minf(energy,water_ratio))*logistics*equip*quality*(1.0+s.research*.05)
 var employed=minf(jobs,maxf(0,workforce-s.troops-training))
 var health=clampf(float(count_kind("hospital"))*100000.0*scale*s.service_budget/maxf(pop,1),0,1)
 var education=clampf(float(count_kind("school"))*100000.0*scale*s.service_budget/maxf(pop,1),0,1)
 var food_ratio=clampf(s.food/maxf(pop*.01,1),0,1)
 var happy=clampf(45+15*health+10*education+10*energy+10*food_ratio+10*minf(housing/maxf(pop,1),1)-maxf(s.tax_income-.12,0)*150-maxf(s.tax_profit-.2,0)*60,0,100)
 var wage=1500.0*s.wealth
 var wages=employed*wage
 var profit=maxf(0,200000*count_kind("factory")*scale*s.wealth*productivity+60000*count_kind("commerce")*scale*s.wealth*productivity)
 # The state owns prototype industries: corporate tax plus after-tax dividend = profit, once.
 var income=wages*s.tax_income+profit*s.tax_profit+profit*(1-s.tax_profit)+300000*scale*s.wealth
 var expenses=gov_jobs*wage*s.service_budget+s.troops*1800*s.wealth+training*900*s.wealth+maint+800000*scale*s.wealth*s.service_budget+400000*scale*s.wealth+s.strategy*200000*scale*s.wealth+float(s.debt)/100*.01
 var cashflow=(income-expenses)*100/30
 metrics={"housing":housing,"jobs":jobs,"employed":employed,"workforce":workforce,"unemployed":maxf(0,workforce-s.troops-training-employed),"training":training,"labor":labor,"power":power,"generation":generation,"water":water,"supply":supply,"food_output":food*productivity,"food_need":pop*.01,"productivity":productivity,"health":health,"education":education,"happy":happy,"income":income*100,"expenses":expenses*100,"cashflow":cashflow,"profit":profit*100,"private_jobs":private_jobs,"gov_jobs":gov_jobs,"energy_ratio":energy,"water_ratio":water_ratio,"logistics":logistics,"equipment_ratio":equip}
func tick():
 if s.is_empty():return
 s.day+=1;calculate()
 var scale=float(s.scale)
 var food_balance=metrics.food_output-metrics.food_need
 var import_food=0.0
 if food_balance<0 and s.trade:
  var want=-food_balance
  var cost=int(round(want*20*s.wealth*100))
  if spend(cost,"Importação de alimentos"):import_food=want
 s.food=clampf(s.food+food_balance+import_food,0,100000*scale)
 var factory_output=40.0*count_kind("factory")*scale*metrics.productivity
 # Industries need construction inputs; stock constrains both production and works.
 var used=minf(s.materials,factory_output*.3);s.materials-=used
 var output_ratio=used/maxf(factory_output*.3,.001) if factory_output>0 else 0.0
 s.goods=clampf(s.goods+factory_output*output_ratio-float(s.population)*.0001,0,20000*scale)
 var goods_short=clampf(s.goods/maxf(float(s.population)*.0001,1),0,1)
 # The profit component is settled only for productive, supplied factories.
 var industrial_profit=200000*count_kind("factory")*scale*s.wealth*metrics.productivity
 var profit_correction=industrial_profit*(1-output_ratio*goods_short)*100/30
 var delta=int(round(metrics.cashflow-profit_correction))
 s.cash+=delta
 record(delta,"Resultado fiscal diário")
 metrics.actual_daily=delta
 if s.trade and s.materials<3000*scale:
  var qty=2000*scale
  if spend(int(round(qty*100*s.wealth*100)),"Importação de insumos"):s.materials+=qty
 var completed=[]
 for p in s.projects:
  var d=BUILDINGS[p.kind];var company=COMPANIES[int(p.company)]
  var step=minf(1.0-float(p.progress),float(company.speed)/float(d.days))
  var materials=step*500*scale
  if s.materials<materials:continue
  var new_progress=minf(1.0,float(p.progress)+step)
  var target_paid=mini(int(p.cost),int(round(float(p.cost)*new_progress)))
  var payment=target_paid-int(p.paid)
  # Reserved construction cash is paid once, proportionally; deficit pauses works.
  if int(s.cash)<payment:continue
  s.materials-=materials;s.cash-=payment;record(-payment,"Obra: "+d.name);s.reserved-=payment;p.paid=target_paid;p.progress=new_progress
  if p.progress>=.999999:
   s.buildings.append({"id":p.id,"kind":p.kind,"lon":p.lon,"lat":p.lat,"initial":false,"quality":company.quality});completed.append(p)
   log_event("Concluída: "+d.name)
 for p in completed:s.projects.erase(p)
 var delivered=[]
 for p in s.deliveries:
  p.days-=1
  if p.days<=0:
   if p.get("strategic",false):s.strategy+=1;s.strategy_order-=1
   else:s.equipment+=p.qty
   delivered.append(p);log_event("Entrega recebida.")
 for p in delivered:s.deliveries.erase(p)
 var trained=[]
 for t in s.trainees:
  t.days-=1
  if t.days<=0:s.troops+=t.qty;trained.append(t);log_event("Treinamento militar concluído.")
 for t in trained:s.trainees.erase(t)
 if s.research_queue>0:
  s.research_days-=maxf(.1,metrics.education)
  if s.research_days<=0:s.research=s.research_queue;s.research_queue=0;log_event("Pesquisa concluída: nível %d."%s.research)
 s.condition=maxf(.3,s.condition-.001)
 if s.maintenance and s.condition<.96:
  if spend(money(3000),"Manutenção de máquinas"):s.condition=minf(1,s.condition+.015)
 var growth=(float(metrics.happy)-60.0)/300000.0
 if s.population>=metrics.housing:growth=minf(growth,0)
 if metrics.unemployed>float(s.population)*.12:growth-=.00003
 s.population=maxf(scale*1000,s.population*(1+growth))
 if s.cash<0:
  s.debt+=-int(s.cash);record(-int(s.cash),"Financiamento de déficit");s.cash=0
  if s.day%10==0:log_event("Déficit financiado por dívida; revise impostos e gastos.")
 calculate();changed.emit()
func save_to(path:String)->bool:
 var payload={"version":VERSION,"state":s,"ledger":ledger}
 var serialized=JSON.stringify(payload,"",true,true)
 var f=FileAccess.open(path+".tmp",FileAccess.WRITE)
 if f==null:error="Não foi possível escrever o save.";return false
 f.store_string(serialized);f.flush();f.close()
 if FileAccess.file_exists(path):
  DirAccess.copy_absolute(path,path+".bak")
 var result=DirAccess.rename_absolute(path+".tmp",path)
 if result!=OK:error="Não foi possível concluir o save.";return false
 return true
func load_from(path:String)->bool:
 if not FileAccess.file_exists(path):error="Nenhum save encontrado.";return false
 var p=JSON.parse_string(FileAccess.get_file_as_string(path))
 if not p is Dictionary or p.get("version",0)!=VERSION or not p.get("state") is Dictionary:error="Save inválido ou incompatível.";return false
 var candidate=p.state
 for k in ["cash","reserved","scale","wealth","country","mode","buildings","projects","population","day","tax_income","tax_profit","service_budget","deliveries","equipment","condition","maintenance","troops","trainees","research","research_queue","research_days","debt","food","goods","materials","loan_used","events","next_id","trade","strategy","strategy_order"]:
  if not candidate.has(k):error="Save incompleto.";return false
 if float(candidate.scale)<=0 or float(candidate.population)<=0 or float(candidate.reserved)<0:error="Escala ou saldo inválido.";return false
 for k in ["buildings","projects","deliveries","trainees","events"]:
  if not candidate[k] is Array:error="Lista inválida: "+k;return false
 if not candidate.country is Dictionary or not candidate.country.has_all(["id","name","label"]):error="País inválido.";return false
 for b in candidate.buildings:
  if not b is Dictionary or not b.has_all(["id","kind","lon","lat","initial"]) or not BUILDINGS.has(b.kind):error="Instalação inválida.";return false
 var reserved=0
 for project in candidate.projects:
  if not project is Dictionary or not project.has_all(["id","kind","cost","paid","progress","company","lon","lat"]) or not BUILDINGS.has(project.kind):error="Contrato inválido.";return false
  if project.paid<0 or project.cost<project.paid or project.progress<0 or project.progress>1 or project.company<0 or project.company>=COMPANIES.size():error="Contrato inconsistente.";return false
  reserved+=int(project.cost)-int(project.paid)
 if reserved!=int(candidate.reserved):error="Reserva inconsistente.";return false
 for k in ["version","day","cash","reserved","equipment","research","research_queue","debt","next_id","strategy","strategy_order"]:candidate[k]=int(candidate[k])
 s=candidate;ledger=p.get("ledger",[]);calculate();changed.emit();return true
static func distance_km(a:Vector2,b:Vector2)->float:
 var lat1=deg_to_rad(a.y);var lat2=deg_to_rad(b.y)
 var dlat=lat2-lat1;var dlon=deg_to_rad(b.x-a.x)
 var h=pow(sin(dlat/2),2)+cos(lat1)*cos(lat2)*pow(sin(dlon/2),2)
 return 6371.0088*2*atan2(sqrt(h),sqrt(maxf(0,1-h)))
