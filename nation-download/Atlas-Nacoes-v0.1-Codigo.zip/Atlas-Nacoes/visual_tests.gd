extends SceneTree
var failed=0
func _initialize():call_deferred("run")
func verify(v:bool,msg:String):
 if not v:failed+=1;push_error("UI FAIL: "+msg)
func shot(name:String):
 await process_frame
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png("/tmp/nation/build/"+name+".png")
func run():
 var app=load("res://main.tscn").instantiate();root.add_child(app)
 await process_frame
 await process_frame
 verify(app.countries.size()==195,"country list")
 app.world.home()
 await shot("01-selecao")
 app.pick("BRA");app.start_game();app.speed=0
 await process_frame
 verify(app.active,"start from selection")
 for name in ["País","Construir","Economia","Serviços","Empresas","Equipamentos","Pesquisa","Defesa","Salvar / opções"]:
  app.tab=name;app.render_panel();await process_frame
  verify(app.root.get_combined_minimum_size().x<=1281,"layout width "+name)
  await shot("panel-"+name.replace("/","-"))
 app.tab="Construir";app.render_panel();app.pending_kind="factory";app.place(-47,-15)
 verify(app.sim.s.projects.size()==1,"map placement creates contract")
 for i in 25:app.sim.tick()
 verify(app.sim.count_kind("factory")==2,"integrated construction")
 app.sim.buy_equipment(5);app.sim.recruit(500);app.sim.research()
 for i in 30:app.sim.tick()
 verify(app.sim.s.equipment==15 and app.sim.s.troops==1500 and app.sim.s.research==1,"integrated economy systems")
 app.sim.save_to(app.save_path);var day=app.sim.s.day;app.sim.tick();app.load_game()
 verify(app.sim.s.day==day and app.speed==0,"UI save load")
 app.tab="País";app.render_panel();await create_timer(2).timeout;await shot("02-mandato")
 # Exercise touch pan and pinch through actual input handlers, then verify invalid positions.
 var touch=InputEventScreenTouch.new();touch.index=0;touch.pressed=true;touch.position=Vector2(200,200);app.world.on_input(touch)
 var drag=InputEventScreenDrag.new();drag.index=0;drag.position=Vector2(230,210);drag.relative=Vector2(30,10)
 var before=app.world.center;app.world.on_input(drag);verify(app.world.center!=before,"touch drag")
 touch.pressed=false;touch.position=drag.position;app.world.on_input(touch)
 verify(app.world.contains("BRA",Vector2(-47,-15)),"Brazil land")
 verify(not app.world.contains("BRA",Vector2(0,0)),"foreign/ocean rejected")
 app.world.focus("VAT");verify(app.world.zoom>1000,"microstate zoom")
 app.world.focus("BRA")
 # Phone aspect ratio: logical landscape at 20:9.
 DisplayServer.window_set_size(Vector2i(1600,720));await create_timer(.5).timeout;await process_frame;await process_frame
 app.tab="Construir";app.render_panel();await shot("03-celular-paisagem")
 verify(app.root.get_combined_minimum_size().x<=1601,"phone width")
 print("UI RESULT failures=",failed)
 quit(1 if failed else 0)
