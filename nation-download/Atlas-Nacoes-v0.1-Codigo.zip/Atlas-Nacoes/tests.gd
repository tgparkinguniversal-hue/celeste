extends SceneTree
const Sim=preload("res://sim.gd")
var checks=0
var failures=0
func check(value:bool,msg:String):
 checks+=1
 if not value:failures+=1;push_error("FAIL: "+msg)
func _initialize():
 var catalog=JSON.parse_string(FileAccess.get_file_as_string("res://data/countries.json"))
 check(catalog.size()==195,"195 countries")
 var bra={}
 for c in catalog:
  if c.id=="BRA":bra=c
 var sim=Sim.new();sim.start(bra,"balanced")
 check(sim.s.cash==5000000000,"starting budget")
 var cash=sim.s.cash
 check(sim.order_build("factory",0,-48,-15),"order factory")
 check(sim.s.cash==cash,"reservation does not spend money")
 check(sim.available()==cash-sim.money(5000000),"reserved balance")
 var ledger_index=sim.ledger.size();var cash_before=sim.s.cash
 sim.tick()
 var booked=0
 for entry in sim.ledger.slice(ledger_index):booked+=entry.amount
 check(sim.s.cash-cash_before==booked,"cash agrees with ledger including construction")
 var p=sim.s.projects[0];var paid=p.paid
 check(paid>0 and sim.s.reserved==p.cost-paid,"proportional construction payment")
 cash=sim.s.cash
 check(sim.cancel_project(p.id),"cancel work")
 check(sim.s.reserved==0,"unspent reservation released")
 check(sim.s.cash==cash,"cancel does not refund spent money")
 check(sim.order_build("factory",0,-47,-16),"second factory")
 for i in 25:sim.tick()
 check(sim.s.projects.is_empty(),"factory completed")
 check(sim.count_kind("factory")==2,"factory added once")
 check(sim.s.reserved==0,"no leftover reserve")
 check(sim.buy_equipment(5),"purchase equipment")
 var eq=sim.s.equipment
 for i in 5:sim.tick()
 check(sim.s.equipment==eq+5 and sim.s.deliveries.is_empty(),"delivery only after lead time")
 var soldiers=sim.s.troops
 check(sim.recruit(500),"recruit")
 check(sim.metrics.training==500,"workers reserved for training")
 for i in 15:sim.tick()
 check(sim.s.troops==soldiers+500,"trained soldiers")
 sim.demobilize();check(sim.s.troops==soldiers,"demobilization")
 check(sim.research(),"research order")
 for i in 26:sim.tick()
 check(sim.s.research==1,"research completion")
 check(sim.save_to("user://test-save.json"),"atomic save")
 var other=Sim.new();check(other.load_from("user://test-save.json"),"load")
 check(equivalent(other.s,sim.s),"save roundtrip")
 sim.tick();other.tick();check(equivalent(other.s,sim.s),"deterministic continuation")
 for i in 360:sim.tick()
 check(sim.s.population>0 and sim.s.cash>=0 and sim.s.reserved>=0,"year invariants")
 check(sim.metrics.employed+sim.s.troops+sim.metrics.training<=sim.metrics.workforce+.01,"labor conservation")
 var before=sim.s.cash
 check(sim.loan(),"emergency loan")
 check(not sim.loan(),"no duplicate credit")
 check(sim.s.cash>before and sim.s.debt>0,"loan booked")
 check(sim.repay(),"debt repayment")
 var a=Vector2(0,0);var b=Vector2(1,0)
 check(absf(Sim.distance_km(a,b)-111.195)<.01,"geodesic distance")
 for c in catalog:
  var test=Sim.new();test.start(c,"real");test.tick()
  check(test.s.cash>=0 and test.s.population>0,"real start "+c.id)
 var limited=Sim.new();limited.start(bra,"balanced");limited.s.trade=false;limited.s.materials=0;limited.order_build("factory",0,0,0);limited.tick()
 check(limited.s.projects[0].progress==0,"input shortage pauses construction")
 check(limited.s.goods<5000,"factory cannot create goods without inputs")
 check(sim.save_to("user://test-save.json"),"backup save")
 check(FileAccess.file_exists("user://test-save.json.bak"),"backup created")
 var invalid=FileAccess.open("user://bad-save.json",FileAccess.WRITE);invalid.store_string('{"version":1,"state":{}}');invalid.close()
 check(not other.load_from("user://bad-save.json"),"corrupt save rejected")
 var strategic=Sim.new();strategic.start(bra,"balanced");check(not strategic.buy_strategy(),"strategic research gate")
 strategic.s.research=3;check(strategic.buy_strategy(),"strategic procurement")
 for i in 60:strategic.tick()
 check(strategic.s.strategy==1,"strategic delivery")
 print("RESULT failures=",failures," / ",checks," assertions: construction, accounts, supply, troops, research, saves, all countries.")
 quit(0 if failures==0 else 1)

func equivalent(a,b)->bool:
 if (a is int or a is float) and (b is int or b is float):return absf(float(a)-float(b))<=maxf(.000001,absf(a)*.000000001)
 if a is Dictionary and b is Dictionary:
  if a.size()!=b.size():return false
  for k in a:
   if not b.has(k) or not equivalent(a[k],b[k]):return false
  return true
 if a is Array and b is Array:
  if a.size()!=b.size():return false
  for i in a.size():
   if not equivalent(a[i],b[i]):return false
  return true
 return a==b
