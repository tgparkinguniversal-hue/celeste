extends Control
const Sim=preload("res://sim.gd")
const MapScript=preload("res://map.gd")
var sim=Sim.new()
var countries:Array=[]
var country:Dictionary={}
var scenario="balanced"
var active=false
var speed=1
var accumulator=0.0
var world
var root:VBoxContainer
var sidebar:VBoxContainer
var scroll:ScrollContainer
var hud:Label
var notice:Label
var status:Label
var body:HBoxContainer
var tab="País"
var bindings:Array=[]
var selected_company=0
var pending_kind=""
var search=""
var fps:Label
var autosave_clock=0.0
var notice_clock=0.0
var save_path="user://nation-v1.json"
var metric_clock=0.0
var zoomed=false
var ui_scale=1.0
func _ready():
 countries=JSON.parse_string(FileAccess.get_file_as_string("res://data/countries.json"))
 get_tree().auto_accept_quit=false
 theme=make_theme()
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root=VBoxContainer.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);root.add_theme_constant_override("separation",0);add_child(root)
 var top=PanelContainer.new();top.custom_minimum_size.y=100 if mobile_ui() else 82;root.add_child(top)
 var row=HBoxContainer.new();row.add_theme_constant_override("separation",18);top.add_child(row)
 var brand=Label.new();brand.text="  A T L A S\n  NAÇÕES • ALPHA 0.1";brand.add_theme_color_override("font_color",Color("edcf91"));brand.custom_minimum_size.x=200;row.add_child(brand)
 hud=Label.new();hud.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;hud.custom_minimum_size.x=200;hud.size_flags_horizontal=Control.SIZE_EXPAND_FILL;hud.add_theme_font_size_override("font_size",18);row.add_child(hud)
 for n in [0,1,2,4]:
  row.add_child(button("Ⅱ" if n==0 else str(n)+"×",func():speed=n;update_values(),48))
 fps=Label.new();fps.custom_minimum_size.x=90;fps.add_theme_font_size_override("font_size",14);row.add_child(fps)
 body=HBoxContainer.new();body.size_flags_vertical=Control.SIZE_EXPAND_FILL;body.add_theme_constant_override("separation",0);root.add_child(body)
 world=Control.new();world.set_script(MapScript);world.size_flags_horizontal=Control.SIZE_EXPAND_FILL;world.size_flags_vertical=Control.SIZE_EXPAND_FILL;body.add_child(world);world.countries=countries
 world.picked.connect(pick);world.placed.connect(place)
 var map_tools=HBoxContainer.new();map_tools.position=Vector2(20,20);world.add_child(map_tools)
 map_tools.add_child(button("+",func():world.zoom_at(1.5,world.size/2),50))
 map_tools.add_child(button("−",func():world.zoom_at(1/1.5,world.size/2),50))
 map_tools.add_child(button("Mundo",func():world.home(),96))
 map_tools.add_child(button("País",func():
  if not country.is_empty():world.focus(country.id)
 ,70))
 var panel=PanelContainer.new();panel.custom_minimum_size.x=440 if mobile_ui() else 408;body.add_child(panel)
 var margin=MarginContainer.new();for_margin(margin,18);panel.add_child(margin)
 scroll=ScrollContainer.new();scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;margin.add_child(scroll)
 sidebar=VBoxContainer.new();sidebar.size_flags_horizontal=Control.SIZE_EXPAND_FILL;sidebar.add_theme_constant_override("separation",12);scroll.add_child(sidebar)
 notice=Label.new();notice.custom_minimum_size.y=30;notice.add_theme_font_size_override("font_size",15);notice.add_theme_color_override("font_color",Color("f2d69b"));notice.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;root.add_child(notice)
 var bottom=PanelContainer.new();bottom.custom_minimum_size.y=64;root.add_child(bottom)
 var navscroll=ScrollContainer.new();navscroll.vertical_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;bottom.add_child(navscroll)
 var nav=HBoxContainer.new();nav.add_theme_constant_override("separation",4);navscroll.add_child(nav)
 for title in ["País","Construir","Economia","Serviços","Empresas","Equipamentos","Pesquisa","Defesa","Salvar / opções"]:
  nav.add_child(button("Máquinas" if title=="Equipamentos" else ("Opções" if title=="Salvar / opções" else title),func():
   if active or title=="Salvar / opções":tab=title;render_panel()
   else:toast("Escolha um país e inicie o mandato.")
  ,140 if mobile_ui() else 124))
 resized.connect(resize_ui)
 sim.changed.connect(update_values)
 render_panel();resize_ui();update_values();call_deferred("initial_view")
 if "--demo" in OS.get_cmdline_user_args():call_deferred("demo")
func initial_view():world.home()
func mobile_ui()->bool:return OS.has_feature("android") or "--phone" in OS.get_cmdline_user_args()
func resize_ui():
 if not is_instance_valid(body):return
 var mobile=OS.has_feature("android")
 # Fixed logical canvas with large targets; wide monitors gain map space.
 if mobile:DisplayServer.screen_set_keep_on(true)
func make_style(color:String,border:String,radius:int=12)->StyleBoxFlat:
 var s=StyleBoxFlat.new();s.bg_color=Color(color);s.border_color=Color(border)
 s.set_border_width_all(1);s.set_corner_radius_all(radius);s.content_margin_left=14;s.content_margin_right=14;s.content_margin_top=10;s.content_margin_bottom=10
 return s
func make_theme()->Theme:
 var t=Theme.new();t.default_font_size=18
 t.set_color("font_color","Label",Color("e8e9da"))
 t.set_color("font_color","Button",Color("e8e9da"))
 t.set_color("font_hover_color","Button",Color("fff4d6"))
 t.set_stylebox("normal","Button",make_style("1e3442","3c5560"))
 t.set_stylebox("hover","Button",make_style("334e59","d8bc7c"))
 t.set_stylebox("pressed","Button",make_style("52614e","e8cb89"))
 t.set_stylebox("focus","Button",make_style("334e59","e8cb89"))
 t.set_stylebox("panel","PanelContainer",make_style("122635","344957",0))
 t.set_stylebox("normal","LineEdit",make_style("0e1e2a","4b6064"))
 t.set_color("font_color","LineEdit",Color("fff1d2"));return t
func for_margin(m:MarginContainer,n:int):
 for k in ["margin_left","margin_right","margin_top","margin_bottom"]:m.add_theme_constant_override(k,n)
func button(text:String,fn:Callable,width:int=0)->Button:
 var b=Button.new();b.text=text;b.clip_text=true;b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;b.add_theme_font_size_override("font_size",18 if mobile_ui() else 16);b.custom_minimum_size=Vector2(maxi(width,72) if mobile_ui() else width,72 if mobile_ui() else 52);b.pressed.connect(fn);return b
func label(text:String,font_size:int=18)->Label:
 var l=Label.new();l.text=text;l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;l.add_theme_font_size_override("font_size",font_size+2 if mobile_ui() else font_size);sidebar.add_child(l);return l
func heading(title:String,subtitle:String=""):
 var l=label(title.to_upper(),24);l.add_theme_color_override("font_color",Color("efd099"))
 if subtitle!="":label(subtitle,15)
 sidebar.add_child(HSeparator.new())
func live(fn:Callable,font_size:int=17)->Label:
 var l=label(str(fn.call()),font_size);bindings.append([l,fn]);return l
func action(text:String,fn:Callable):sidebar.add_child(button(text,fn))
func row_actions(items:Array):
 var r=HBoxContainer.new();sidebar.add_child(r)
 for item in items:
  var b=button(item[0],item[1]);b.size_flags_horizontal=Control.SIZE_EXPAND_FILL;r.add_child(b)
func slider(title:String,value:float,low:float,high:float,step:float,fn:Callable):
 var l=label(title+": %.0f%%"%(value*100),17)
 var sl=HSlider.new();sl.min_value=low;sl.max_value=high;sl.step=step;sl.value=value;sl.custom_minimum_size.y=44;sidebar.add_child(sl)
 sl.value_changed.connect(func(v):l.text=title+": %.0f%%"%(v*100);fn.call(v);sim.calculate();update_values())
func currency(cents:float)->String:
 var v=cents/100
 var prefix="−" if v<0 else ""
 v=absf(v)
 if v>=1000000000000:return prefix+"$ %.2f tri"%(v/1000000000000)
 if v>=1000000000:return prefix+"$ %.2f bi"%(v/1000000000)
 if v>=1000000:return prefix+"$ %.2f mi"%(v/1000000)
 if v>=1000:return prefix+"$ %.1f mil"%(v/1000)
 return prefix+"$ %.0f"%v
func number(v:float)->String:
 if absf(v)>=1e9:return "%.2f bi"%(v/1e9)
 if absf(v)>=1e6:return "%.2f mi"%(v/1e6)
 if absf(v)>=1000:return "%.1f mil"%(v/1000)
 return "%.0f"%v
func toast(msg:String):notice.text=msg;notice_clock=8.0
func result(ok:bool,msg:String):
 toast(msg if ok else sim.error);render_panel();world.queue_redraw()
func pick(code:String):
 if active:return
 for c in countries:
  if c.id==code:country=c;world.selected=code;world.queue_redraw();render_panel();update_values();return
 toast("Este território aparece no mapa; selecione uma das 195 nações do catálogo.")
func start_game():
 if country.is_empty():return
 sim.start(country,scenario);active=true;speed=1;accumulator=0;tab="País";world.sim=sim;world.focus(country.id);render_panel();update_values();toast("Mandato iniciado. Arraste o mapa e use a roda ou dois dedos para ampliar.")
func render_panel():
 for n in sidebar.get_children():sidebar.remove_child(n);n.queue_free()
 bindings.clear();scroll.scroll_vertical=0
 if not active and tab!="Salvar / opções":render_select();return
 if tab=="Salvar / opções":render_options();return
 var s=sim.s
 match tab:
  "País":
   heading(country.name,"MANDATO NACIONAL • "+("Cenário equilibrado" if scenario=="balanced" else "Dados reais + parâmetros de jogo"))
   live(func():return "Dia %d  •  Ano %d\nPopulação  %s\nTesouro  %s\nLivre para investir  %s\nResultado mensal*  %s"%[s.day,1+int(s.day/360),number(s.population),currency(s.cash),currency(sim.available()),currency(sim.metrics.cashflow*30)])
   label("*Projeção fiscal antes de obras, compras e importações.",14)
   live(func():return "Satisfação  %.0f/100\nEmprego civil  %s / %s\nMoradias  %s / %s\nProdutividade  %.0f%%"%[sim.metrics.happy,number(sim.metrics.employed),number(sim.metrics.workforce-s.troops-sim.metrics.training),number(s.population),number(sim.metrics.housing),sim.metrics.productivity*100])
   row_actions([["Ⅱ Pausar",func():speed=0;update_values()],["1×",func():speed=1],["2×",func():speed=2],["4×",func():speed=4]])
   action("Avançar 1 dia",func():speed=0;sim.tick();world.queue_redraw())
   heading("Acontecimentos")
   live(func():return "\n\n".join(s.events.slice(0,7)),15)
  "Construir":
   heading("Planejar construção","1. Escolha a empresa. 2. Selecione a obra. 3. Toque no mapa dentro do seu país.")
   var company=OptionButton.new();company.custom_minimum_size.y=50
   for co in Sim.COMPANIES:company.add_item(co.name)
   company.selected=selected_company;company.item_selected.connect(func(i):selected_company=i;render_panel());sidebar.add_child(company)
   var co=Sim.COMPANIES[selected_company]
   label("Preço %.0f%% • ritmo %.0f%% • qualidade %.0f%%"%[co.price*100,co.speed*100,co.quality*100],15)
   label("Projetos representam polos regionais. Tamanho-base: %s pessoas. Posições das instalações iniciais são esquemáticas."%number(s.scale*100000),14)
   for kind in Sim.BUILDINGS:
    var d=Sim.BUILDINGS[kind]
    action("%s  •  %s\n%d dias • %s empregos"%[d.name,currency(sim.money(d.cost*co.price)),ceili(d.days/co.speed),number(d.jobs*s.scale)],func():pending_kind=kind;world.placing=true;toast("Posicione "+d.name+" no mapa. Volte a esta aba para trocar o projeto."))
   action("Cancelar posicionamento",func():world.placing=false;pending_kind="";world.queue_redraw();toast("Posicionamento cancelado."))
  "Economia":
   heading("Tesouro & impostos")
   live(func():return "Receita/mês  %s\nDespesas/mês  %s\nReservas de obras  %s\nDívida  %s"%[currency(sim.metrics.income),currency(sim.metrics.expenses),currency(s.reserved),currency(s.debt)])
   slider("Imposto sobre renda",s.tax_income,0,.4,.01,func(v):s.tax_income=v)
   slider("Imposto sobre lucro",s.tax_profit,0,.4,.01,func(v):s.tax_profit=v)
   label("Indústrias iniciais e novas são estatais: imposto + dividendo líquido somam o lucro uma única vez. Tributos altos reduzem a satisfação.",15)
   row_actions([["Crédito +"+currency(sim.money(20000000)),func():result(sim.loan(),"Crédito emergencial recebido.")],["Quitar dívida",func():result(sim.repay(),"Dívida amortizada.")]])
   heading("Extrato recente")
   live(func():
    var lines=[]
    for i in range(maxi(0,sim.ledger.size()-7),sim.ledger.size()):
     var e=sim.ledger[i];lines.push_front("D%d • %s\n%s"%[e.day,e.reason,currency(e.amount)])
    return "\n\n".join(lines)
   ,14)
  "Serviços":
   heading("População & infraestrutura")
   live(func():return "População  %s\nCapacidade habitacional  %s\nSaúde  %.0f%%  •  Educação  %.0f%%\nEnergia  %.1f / %.1f MW\nÁgua  %.0f / %.0f un./dia\nAlimento em estoque  %s\nProdução/demanda  %s / %s por dia\nInsumos  %s\nProdutos  %s"%[number(s.population),number(sim.metrics.housing),100*sim.metrics.health,100*sim.metrics.education,sim.metrics.power,sim.metrics.generation,sim.metrics.water,sim.metrics.supply,number(s.food),number(sim.metrics.food_output),number(sim.metrics.food_need),number(s.materials),number(s.goods)])
   slider("Orçamento de serviços",s.service_budget,.25,1.5,.05,func(v):s.service_budget=v)
   action("Importação automática: "+("LIGADA" if s.trade else "DESLIGADA"),func():s.trade=not s.trade;render_panel())
   label("Comércio externo é abstrato nesta alpha. Alimentos e insumos têm estoque e custo; falta de insumos interrompe produção e obras. A logística é nacional, sem estradas individuais nesta versão.",15)
  "Empresas":
   heading("Contratos & obras")
   label("Pagamentos por progresso. Uma obra pausa quando faltam insumos ou caixa. Empresas diferem em preço, prazo e qualidade.",15)
   if s.projects.is_empty():label("Sem obras em andamento. Contrate pelo painel Construir.")
   for p in s.projects:
    live(func():return "%s • #%d\n%s\n%.0f%% • pago %s / %s"%[Sim.BUILDINGS[p.kind].name,p.id,Sim.COMPANIES[int(p.company)].name,p.progress*100,currency(p.paid),currency(p.cost)])
    action("Cancelar obra #%d"%p.id,func():result(sim.cancel_project(p.id),"Obra cancelada."))
   heading("Instalações operantes")
   for k in Sim.BUILDINGS:live(func():return "%s: %d"%[Sim.BUILDINGS[k].name,sim.count_kind(k)],16)
  "Equipamentos":
   heading("Máquinas & entregas")
   live(func():return "Máquinas  %d\nCondição  %.0f%%\nProdutividade nacional  %.0f%%"%[s.equipment,s.condition*100,sim.metrics.productivity*100])
   label("Cada máquina amplia a cobertura produtiva até a capacidade nominal. Desgaste reduz o rendimento; manutenção exige dinheiro.",15)
   action("Comprar 5 máquinas • "+currency(sim.money(500000)),func():result(sim.buy_equipment(5),"Compra efetuada. Entrega em 5 dias."))
   action("Manutenção: "+("ATIVA" if s.maintenance else "DESATIVADA"),func():s.maintenance=not s.maintenance;render_panel())
   live(func():
    var lines=[]
    for d in s.deliveries:lines.append(("Programa estratégico" if d.get("strategic",false) else "%d máquinas"%d.qty)+" • %d dias"%d.days)
    return "Entregas:\n"+"\n".join(lines) if not lines.is_empty() else "Nenhuma entrega pendente."
   )
  "Pesquisa":
   heading("Tecnologia & eficiência")
   live(func():return "Nível  %d / 5\nBônus produtivo  +%d%%\n%s"%[s.research,s.research*5,"Pesquisa: %.0f dias restantes"%s.research_days if s.research_queue>0 else "Laboratórios disponíveis"])
   label("Cada nível exige investimento e 25 dias com educação adequada. Orçamento educacional baixo reduz a velocidade.",15)
   action("Pesquisar • "+currency(sim.money(1500000*(s.research+1))),func():result(sim.research(),"Pesquisa iniciada."))
  "Defesa":
   heading("Defesa nacional","SEM COMBATE • FASE ECONÔMICA")
   live(func():return "Tropas ativas  %s\nEm treinamento  %s\nReserva de mão de obra  %s\nSoldos mensais  %s\nProntidão  %.0f%%\nArsenal estratégico  %d"%[number(s.troops),number(sim.metrics.training),number(sim.metrics.unemployed),currency(s.troops*1800*s.wealth*100),minf(s.condition,sim.metrics.energy_ratio)*100,s.strategy])
   label("Recrutar retira pessoas do mercado de trabalho. Treinamento leva 15 dias; tropas exigem soldos contínuos.",15)
   action("Recrutar %s • %s"%[number(500*s.scale),currency(sim.money(500000))],func():result(sim.recruit(500),"Recrutas em treinamento."))
   action("Desmobilizar até "+number(500*s.scale),func():sim.demobilize();render_panel())
   action("Unidade estratégica • "+currency(sim.money(20000000)),func():result(sim.buy_strategy(),"Encomenda estratégica aceita."))
   label("Arsenal é um estoque abstrato com custo e pesquisa nível 3. Sem uso, lançamentos, guerras ou conflitos nesta build.",15)
 update_values()
func render_select():
 heading("Seu país. Seu futuro.","SIMULADOR TYCOON NACIONAL • PRIMEIRA ALPHA")
 label("Escolha no mapa ou pesquise uma das 195 nações. Arraste para mover e amplie para ver países pequenos.",16)
 var input=LineEdit.new();input.placeholder_text="Buscar país ou sigla…";input.custom_minimum_size.y=48;input.text=search;sidebar.add_child(input)
 var results=VBoxContainer.new();sidebar.add_child(results)
 var fill=func(q:String):
  for n in results.get_children():results.remove_child(n);n.queue_free()
  var query=q.to_lower().strip_edges();var found=0
  for c in countries:
   if query!="" and not c.name.to_lower().contains(query) and not c.name_en.to_lower().contains(query) and not c.id.to_lower().contains(query):continue
   var b=button(c.name+"  ·  "+c.id,func():pick(c.id);world.focus(c.id));results.add_child(b);found+=1
  if found==0:
   var l=Label.new();l.text="Nenhum resultado.";results.add_child(l)
 # Put catalog in a bounded scroller so the start button remains accessible.
 sidebar.remove_child(results)
 var list_scroll=ScrollContainer.new();list_scroll.custom_minimum_size.y=170;list_scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;sidebar.add_child(list_scroll);list_scroll.add_child(results);results.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 fill.call(search);input.text_changed.connect(func(q):search=q;fill.call(q))
 if not country.is_empty():
  heading(country.name,"Capital: "+country.capital)
  label("População: "+observation(country.population)+"\nPIB: "+observation(country.gdp_current_usd,true),15)
  var modes=OptionButton.new();modes.add_item("Equilibrado • condições iguais");modes.add_item("Dados reais • contexto econômico");modes.custom_minimum_size.y=48;modes.selected=0 if scenario=="balanced" else 1;modes.item_selected.connect(func(i):scenario="balanced" if i==0 else "real");sidebar.add_child(modes)
  action("INICIAR MANDATO →",start_game)
  label("Dados reais: população e PIB com ano indicado; tesouro, tropas, instalações e orçamento são parâmetros simulados. Ausências usam estimativa explícita.",14)
 else:label("Toque em um país para começar.",20)
 if FileAccess.file_exists(save_path):action("Continuar partida salva",load_game)
func observation(d:Dictionary,is_money:bool=false)->String:
 if d.value==null:return "indisponível • será estimado no modo real"
 return (currency(float(d.value)*100) if is_money else number(float(d.value)))+" • "+str(int(d.year))+(" (dado anterior)" if d.status!="same_year" else "")
func render_options():
 heading("Salvar & opções")
 if active:
  action("Salvar partida agora",func():result(sim.save_to(save_path),"Partida salva no dispositivo."))
 action("Carregar partida",load_game)
 if FileAccess.file_exists(save_path+".bak"):action("Restaurar backup anterior",func():result(sim.load_from(save_path+".bak"),"Backup restaurado.");if_loaded())
 if active:
  action("Voltar à escolha de país",func():sim.save_to(save_path);active=false;speed=0;world.sim=null;world.placing=false;tab="País";render_panel();update_values();world.home())
 action("Tela cheia / janela",func():
  if OS.has_feature("android"):toast("No Android o jogo já usa tela cheia.")
  else:DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)
 )
 action("FPS: livre / 60",func():Engine.max_fps=60 if Engine.max_fps==0 else 0;toast("FPS: "+("livre" if Engine.max_fps==0 else "60")))
 label("Teclado: espaço pausa/continua; 1, 2 e 4 mudam velocidade; F11 alterna tela cheia; Esc cancela posicionamento. Mouse: arrastar e roda. Celular: arrastar e pinça; botões +/− também ampliam.",16)
 label("Salvamento automático a cada 30 segundos e ao minimizar. Sem avanço com o app fechado. Uma partida local com backup. O mapa usa WGS84 e distâncias geodésicas reais, com fronteiras Natural Earth 1:50 milhões; não é um levantamento em escala de 1 metro.",15)
 label("Créditos: Natural Earth (domínio público), dados de população e PIB: datasets / Banco Mundial; catálogo ISO via datasets/country-codes. Arte e código desta alpha são próprios. Inspirado no gênero de gestão nacional; não afiliado ao RoWorld ou Roblox.",14)
 if not OS.has_feature("android"):action("Sair",func():if active:sim.save_to(save_path)
 ;get_tree().quit())
func if_loaded():
 if sim.s.is_empty():return
 active=true;country=sim.s.country;scenario=sim.s.mode;world.sim=sim;world.selected=country.id;world.focus(country.id);speed=0;tab="País";render_panel();update_values()
func load_game():
 if sim.load_from(save_path):if_loaded();toast("Partida carregada e pausada.")
 else:toast(sim.error)
func place(lon:float,lat:float):
 if lon==999:toast("Escolha um ponto em terra dentro do seu país.");return
 if pending_kind=="":return
 result(sim.order_build(pending_kind,selected_company,lon,lat),"Obra contratada. Acompanhe em Empresas.")
 world.placing=false;pending_kind="";world.queue_redraw()
func update_values():
 if not is_instance_valid(hud):return
 if not active:hud.text="ESCOLHA UMA NAÇÃO\nWindows + Android • mapa geográfico";return
 var s=sim.s
 hud.text="%s  ·  DIA %d  ·  %s\n%s habitantes  |  Tesouro %s  |  Satisfação %.0f%%"%[country.name,s.day,"PAUSADO" if speed==0 else "%d×"%speed,number(s.population),currency(s.cash),sim.metrics.happy]
 for pair in bindings:
  if is_instance_valid(pair[0]):pair[0].text=str(pair[1].call())
func _process(delta:float):
 metric_clock+=delta
 if metric_clock>=.25:fps.text="%d FPS\n%d×"%[Engine.get_frames_per_second(),speed];metric_clock=0
 if notice_clock>0:notice_clock-=delta
 else:notice.text="ALPHA 0.1 • Simulação nacional • Toque nos painéis para gerenciar" if active else "Escolha qualquer país • Dois modos • Salvamento local"
 if not active:return
 accumulator+=minf(delta,.25)*speed
 var ticks=0
 while accumulator>=1 and ticks<8:
  accumulator-=1;sim.tick();ticks+=1
 if ticks>0:world.queue_redraw()
 autosave_clock+=delta
 if autosave_clock>=30:sim.save_to(save_path);autosave_clock=0
func _unhandled_key_input(event:InputEvent):
 if not event.is_pressed() or event.is_echo():return
 if event.keycode==KEY_F11:
  DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)
 if event.keycode==KEY_ESCAPE:world.placing=false;pending_kind="";world.queue_redraw()
 if not active:return
 match event.keycode:
  KEY_SPACE:speed=1 if speed==0 else 0
  KEY_1:speed=1
  KEY_2:speed=2
  KEY_4:speed=4
 update_values()
func _notification(what):
 if what==NOTIFICATION_WM_CLOSE_REQUEST:
  if active:sim.save_to(save_path)
  get_tree().quit()
 if what==NOTIFICATION_APPLICATION_PAUSED or what==NOTIFICATION_APPLICATION_FOCUS_OUT:
  if active:sim.save_to(save_path);speed=0
func demo():
 for c in countries:
  if c.id=="BRA":country=c;break
 start_game();speed=0
 sim.order_build("factory",0,-49.0,-15.0)
 tab="País";render_panel()
