extends SceneTree
func _initialize() -> void:
	var source:=Image.load_from_file("res://assets/rig_sheet.png")
	var parts:=CanineRigParts.new()
	for i in range(8):
		var col:=i%4;var row:=int(i/4)
		var x:=roundi(source.get_width()*col/4.0);var y:=roundi(source.get_height()*row/2.0)
		var endx:=roundi(source.get_width()*(col+1)/4.0);var endy:=roundi(source.get_height()*(row+1)/2.0)
		var im:=source.get_region(Rect2i(x,y,endx-x,endy-y))
		if i==1:im=Image.load_from_file("res://assets/rig_torso.png")
		var w:=im.get_width();var h:=im.get_height()
		var mask:=PackedByteArray();mask.resize(w*h)
		for py in range(h):
			for px in range(w):mask[py*w+px]=1 if im.get_pixel(px,py).a>=0.88 else 0
		var components:=SpriteBank.components(mask,w,h);var keep:=PackedInt32Array()
		for component in components:
			if component.size()>keep.size():keep=component
		assert(not keep.is_empty())
		for component in components:
			if component!=keep:parts.removed_pixels+=component.size()
		var box:=SpriteBank.bounds(keep,w)
		var clean:=Image.create(box.size.x+4,box.size.y+4,false,Image.FORMAT_RGBA8);clean.fill(Color.TRANSPARENT)
		for pixel in keep:
			var px:=pixel%w;var py:=int(pixel/w);var color:=im.get_pixel(px,py);color.a=1
			clean.set_pixel(px-box.position.x+2,py-box.position.y+2,color)
		parts.textures.append(ImageTexture.create_from_image(clean))
		print("PART ",i," ",box)
	# Split shin and boot at the ankle, with a small overlap for a sealed joint.
	var lower_leg:=parts.textures[5].get_image()
	var split:=roundi(lower_leg.get_height()*0.58)
	# Tight crops remove the boot's empty side margin from the shin pivot.
	for rect in [Rect2i(0,0,lower_leg.get_width(),split+5),Rect2i(0,split-5,lower_leg.get_width(),lower_leg.get_height()-split+5)]:
		var piece:=lower_leg.get_region(rect)
		parts.textures.append(ImageTexture.create_from_image(piece.get_region(piece.get_used_rect())))
	var result:=ResourceSaver.save(parts,"res://assets/rig_parts.res",ResourceSaver.FLAG_COMPRESS)
	print("RIG_BAKED ",parts.textures.size()," removed ",parts.removed_pixels," result ",result)
	quit(result)
