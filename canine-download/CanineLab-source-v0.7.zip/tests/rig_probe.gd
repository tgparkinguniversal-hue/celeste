extends SceneTree
var checks:=0
var failures:=[]
func _initialize():call_deferred("run")
func check(ok: bool,message: String):
	checks+=1;print(("PASS " if ok else "FAIL ")+message)
	if not ok:failures.append(message)
func bones(node: Node) -> Array[Bone2D]:
	var list: Array[Bone2D]=[]
	if node is Bone2D:list.append(node)
	for child in node.get_children():list.append_array(bones(child))
	return list
func run():
	var rig:=CutoutActor.new();root.add_child(rig)
	check(bones(rig.skeleton).size()>=15,"connected bone hierarchy")
	var scales:=[];var textures:=[]
	for part in rig.art:scales.append(part.scale);textures.append(part.texture)
	var bone_list:=bones(rig.skeleton);var lengths:=[]
	for bone in bone_list:lengths.append(bone.length)
	var fixed_art:=true;var fixed_bones:=true;var joined:=true;var ankle_flat:=true
	var max_error:=0.0;var max_head_step:=0.0
	var previous_head:=rig.skeleton.to_local(rig.head.global_position)
	for state in ["idle","walk","run","crouch","crouch_walk","slide","jump","fall","idle"]:
		for direction in [1.0,-1.0]:
			for frame in range(90):
				var speed:=490.0 if state=="run" else (108.0 if state=="crouch_walk" else (230.0 if state=="walk" else 0.0))
				rig.pose(state,Vector2(speed*direction,-300 if state=="jump" else 250),direction,state not in ["jump","fall"],false,1.0/120)
				for i in range(rig.art.size()):fixed_art=fixed_art and rig.art[i].texture==textures[i] and rig.art[i].scale==scales[i]
				for i in range(bone_list.size()):fixed_bones=fixed_bones and bone_list[i].scale==Vector2.ONE and bone_list[i].length==lengths[i]
				for i in range(2):
					var ankle:=rig.skeleton.to_local(rig.boots[i].global_position)
					max_error=maxf(max_error,ankle.distance_to(rig.feet[i]))
					joined=joined and rig.shins[i].position==Vector2(0,rig.LEG_UPPER) and rig.boots[i].position==Vector2(0,rig.LEG_LOWER)
					ankle_flat=ankle_flat and rig.boots[i].global_transform.y.normalized().distance_to(Vector2.DOWN)<0.001
				var at:=rig.skeleton.to_local(rig.head.global_position)
				max_head_step=maxf(max_head_step,at.distance_to(previous_head));previous_head=at
	check(fixed_art,"identical art and piece scale in all poses and directions")
	check(fixed_bones,"no bone length or scale changes in animations")
	check(joined,"limb pivots stay connected")
	check(max_error<0.15,"two-bone IK reaches smoothed foot targets (error %.3f)"%max_error)
	check(ankle_flat,"boot soles stay oriented to ground in both directions")
	check(max_head_step<4,"crouch and slide transitions have no head position pop (%.2f px)"%max_head_step)
	var head_image:=rig.art[12].texture
	rig.pose("walk",Vector2(230,0),1,true,true,1.0/60)
	check(rig.art[12].texture==head_image,"holding object keeps same face")
	var heads:=[]
	for hz in [30,60,120]:
		rig.reset_pose()
		for frame in range(hz):rig.pose("crouch",Vector2.ZERO,1,true,false,1.0/hz)
		heads.append(rig.skeleton.to_local(rig.head.global_position))
	print("HEAD_FPS ",heads)
	check((heads[0] as Vector2).distance_to(heads[2])<0.2,"pose smoothing independent of 30 60 120 FPS")
	print("RESULT %d checks / %d failures"%[checks,failures.size()])
	FileAccess.open("/tmp/canine-build/v07/rig-results.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures,"max_ik_error":max_error,"max_head_step":max_head_step},"  "))
	quit(0 if failures.is_empty() else 1)
