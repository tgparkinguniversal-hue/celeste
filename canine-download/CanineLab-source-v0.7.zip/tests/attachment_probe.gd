extends SceneTree
var checks:=0
var failures:=[]
func _initialize():call_deferred("run")
func check(ok: bool,message: String):
	checks+=1;print(("PASS " if ok else "FAIL ")+message)
	if not ok:failures.append(message)
func run():
	var view:=SubViewport.new();view.size=Vector2i(256,180);view.transparent_bg=true
	view.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(view)
	var rig:=CutoutActor.new();view.add_child(rig);rig.position=Vector2(128,155)
	var samples:=0;var detached:=[];var under_floor:=[];var lowest_knee:=-1000.0
	for state in ["idle","walk","run","crouch","crouch_walk","slide","jump","fall","hold"]:
		for direction in [1.0,-1.0]:
			rig.reset_pose(direction)
			for phase in range(6):
				for frame in range([1,6,10,15,20,25][phase]):
					rig.pose("idle" if state=="hold" else state,Vector2(490 if state=="run" else (108 if state=="crouch_walk" else (230 if state=="walk" else 0)),-300 if state=="jump" else 200),direction,state not in ["jump","fall"],state=="hold",1.0/120)
					if state not in ["jump","fall","hold"]:
						for knee in rig.shins:lowest_knee=maxf(lowest_knee,rig.to_local(knee.global_position).y)
				await process_frame;await process_frame;await RenderingServer.frame_post_draw
				var im:=view.get_texture().get_image()
				var mask:=PackedByteArray();mask.resize(im.get_width()*im.get_height())
				for y in range(im.get_height()):
					for x in range(im.get_width()):mask[y*im.get_width()+x]=1 if im.get_pixel(x,y).a>=0.8 else 0
				var components:=SpriteBank.components(mask,im.get_width(),im.get_height())
				var substantial:=0
				for part in components:
					if part.size()>3:substantial+=1
				var name_: String=state+"_%s_%d"%["right" if direction>0 else "left",phase]
				if substantial!=1:
					detached.append(name_);im.save_png("/tmp/canine-build/v07/gap-"+name_+".png")
				if state not in ["jump","fall"] and im.get_used_rect().end.y>157:under_floor.append(name_)
				samples+=1
	check(detached.is_empty(),"rendered silhouette remains connected in %d poses (%s)"%[samples,str(detached)])
	check(under_floor.is_empty(),"no rendered body parts pass through ground (%s)"%str(under_floor))
	check(lowest_knee<-6.0,"knees and padding remain above floor (%.2f px)"%lowest_knee)
	var aspect_ok:=true
	for item in rig.art:aspect_ok=aspect_ok and is_equal_approx(item.scale.x,item.scale.y)
	check(aspect_ok,"all art retains source proportions without stretching")
	check(rig.arms[1].position.x<0 and rig.arms[0].position.x>0,"front sleeve correctly placed on near side of chest")
	print("RESULT %d checks / %d failures"%[checks,failures.size()])
	FileAccess.open("/tmp/canine-build/v07/attachment-results.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures,"poses":samples,"detached":detached,"under_floor":under_floor,"lowest_knee":lowest_knee},"  "))
	quit(0 if failures.is_empty() else 1)
