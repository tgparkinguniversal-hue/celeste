extends Node2D
class_name CutoutActor
# Rigid cutout skeleton: art and limb lengths never change with animation state.
const LEG_UPPER:=14.0
const LEG_LOWER:=16.0
const ARM_UPPER:=16.0
const ARM_LOWER:=17.0
var skeleton: Skeleton2D
var pelvis: Bone2D
var spine: Bone2D
var head: Bone2D
var tail: Bone2D
var scarf: Bone2D
var legs: Array[Bone2D]=[]
var shins: Array[Bone2D]=[]
var boots: Array[Bone2D]=[]
var arms: Array[Bone2D]=[]
var forearms: Array[Bone2D]=[]
var art: Array[Sprite2D]=[]
var parts: CanineRigParts
var phase:=0.0
var clock:=0.0
var lower:=0.0
var lean:=0.0
var lift:=0.0
var hip_shift:=0.0
var face:=1.0
var active_pose:="idle"
var feet: Array[Vector2]=[Vector2(9,-4),Vector2(-9,-4)]
var last_grounded:=true
var landing:=0.0
var initialized:=false
var covers: Array[RigJointCover]=[]
func joint(parent: Node,name_: String,at: Vector2,length_: float,z: int=0) -> Bone2D:
	var bone:=Bone2D.new();bone.name=name_;bone.position=at;bone.z_index=z
	bone.set_autocalculate_length_and_angle(false);bone.length=length_
	parent.add_child(bone);bone.rest=bone.transform
	return bone
func skin(parent: Node2D,index: int,size_: Vector2,at: Vector2,tint:=Color.WHITE) -> Sprite2D:
	var item:=Sprite2D.new();item.texture=parts.textures[index]
	item.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	var ratio:=minf(size_.x/item.texture.get_width(),size_.y/item.texture.get_height())
	item.scale=Vector2.ONE*ratio;item.position=at;item.modulate=tint
	parent.add_child(item);art.append(item);return item
func cover(parent: Node2D,radius_: float,color_: Color,at:=Vector2.ZERO) -> void:
	var pad:=RigJointCover.new();pad.radius=radius_;pad.color=color_;pad.position=at;pad.z_index=-1
	parent.add_child(pad);covers.append(pad)
func _ready() -> void:
	parts=load("res://assets/rig_parts.res")
	assert(parts!=null and parts.textures.size()==10)
	skeleton=Skeleton2D.new();add_child(skeleton)
	pelvis=joint(skeleton,"Pelvis",Vector2(0,-31),10)
	spine=joint(pelvis,"Spine",Vector2.ZERO,31)
	# Back limbs draw behind the coat and head. Joints overlap under opaque art.
	for i in range(2):
		var shade:=Color("c3c0b6") if i==0 else Color.WHITE
		var thigh:=joint(pelvis,"Thigh%d"%i,Vector2(6 if i==0 else -6,0),LEG_UPPER,-3 if i==0 else -1)
		var shin:=joint(thigh,"Shin",Vector2(0,LEG_UPPER),LEG_LOWER)
		cover(thigh,6,Color("373442")*shade)
		cover(shin,5,Color("373442")*shade)
		skin(thigh,4,Vector2(15,19),Vector2(0,7),shade)
		skin(shin,8,Vector2(13,17),Vector2(0,7),shade)
		var boot:=joint(shin,"Ankle",Vector2(0,LEG_LOWER),8)
		cover(boot,4,Color("514037")*shade)
		skin(boot,9,Vector2(21,12),Vector2(3,-1),shade)
		boots.append(boot)
		legs.append(thigh);shins.append(shin)
		var arm:=joint(spine,"Arm%d"%i,Vector2(10 if i==0 else -11,-27),ARM_UPPER,-2 if i==0 else 3)
		var forearm:=joint(arm,"Forearm",Vector2(0,ARM_UPPER),ARM_LOWER)
		cover(arm,6,Color("809783")*shade)
		cover(forearm,5.5,Color("809783")*shade)
		skin(arm,2,Vector2(15,22),Vector2(0,8),shade)
		skin(forearm,3,Vector2(16,22),Vector2(0,9),shade)
		arms.append(arm);forearms.append(forearm)
	tail=joint(pelvis,"Tail",Vector2(-14,-8),24,-4)
	skin(tail,6,Vector2(44,36),Vector2(-18,-9))
	skin(spine,1,Vector2(36,40),Vector2(0,-16))
	cover(spine,6,Color("ad4b48"),Vector2(1,-31))
	head=joint(spine,"Head",Vector2(3,-31),10,4)
	skin(head,0,Vector2(78,62),Vector2(0,-27))
	scarf=joint(spine,"Scarf",Vector2(-10,-30),20,2)
	skin(scarf,7,Vector2(28,12),Vector2(-12,3))
	initialized=true
	pose("idle",Vector2.ZERO,1,true,false,1.0/60)
func reset_pose(direction_: float=1) -> void:
	phase=0;clock=0;lower=0;lean=0;lift=0;hip_shift=0;landing=0;face=direction_;last_grounded=true
	feet=[Vector2(9,-4),Vector2(-9,-4)]
	for arm in arms:arm.rotation=0
	for forearm in forearms:forearm.rotation=-0.12
	tail.rotation=0;scarf.rotation=0
func smooth(current: float,target: float,rate: float,dt: float) -> float:
	return lerpf(current,target,1-exp(-rate*dt))
func solve_limb(first: Bone2D,second: Bone2D,target: Vector2,a: float,b: float) -> void:
	# Target is in skeleton coordinates, avoiding changes in bone scale or length.
	var hip:=skeleton.to_local(first.global_position)
	var delta:=target-hip
	var distance:=clampf(delta.length(),absf(a-b)+0.1,a+b-0.1)
	var angle:=atan2(delta.y,delta.x)-acos(clampf((a*a+distance*distance-b*b)/(2*a*distance),-1,1))
	var parent_rotation:float=(first.get_parent() as Node2D).global_rotation-skeleton.global_rotation
	first.rotation=angle-PI/2-parent_rotation
	second.rotation=PI-acos(clampf((a*a+b*b-distance*distance)/(2*a*b),-1,1))
func pose(state_: String,velocity_: Vector2,direction_: float,grounded: bool,holding: bool,dt: float) -> void:
	if not initialized:return
	active_pose=state_;clock+=dt
	face=direction_
	# Mirror all parts together, around one body axis.
	skeleton.scale=Vector2(face,1)
	var speed:=absf(velocity_.x)
	var crouching:=state_ in ["crouch","crouch_walk","slide"]
	var slide:=state_=="slide"
	var rate:=lerpf(1.9,3.2,smoothstep(230,490,speed))*clampf(speed/230,0,1)
	if crouching:rate=clampf(speed/108,0,1)*1.4
	if speed>8 and grounded and not slide:phase=fmod(phase+rate*dt,1.0)
	var run_weight:=smoothstep(250,490,speed)
	lower=smooth(lower,10.0 if crouching else 0.0,20,dt)
	lean=smooth(lean,-0.13 if slide else (0.12 if crouching else run_weight*0.12),14,dt)
	var cycle:=sin(phase*TAU*2)
	var target_lift:float=(1.4 if not crouching else 0.6)*cycle if speed>8 and grounded else sin(clock*2.5)*0.45
	lift=smooth(lift,target_lift,20,dt)
	if grounded and not last_grounded:landing=1
	landing=move_toward(landing,0,dt*8)
	last_grounded=grounded
	hip_shift=smooth(hip_shift,-3.0 if slide else 0.0,18,dt)
	pelvis.position=Vector2(hip_shift,-31+lower+lift+landing*(1.5 if crouching else 3.0))
	spine.rotation=lean
	# The head counters body lean. Its artwork and dimensions are always identical.
	head.rotation=-lean+sin(clock*2.3)*0.012
	tail.rotation=smooth(tail.rotation,sin(clock*5+phase*TAU)*0.09+velocity_.x*direction_*0.00012,10,dt)
	scarf.rotation=smooth(scarf.rotation,-run_weight*0.28+sin(clock*8)*0.06,12,dt)
	for i in range(2):
		var foot:=Vector2(9 if i==0 else -9,-4)
		if grounded and speed>8 and not slide:
			var t:=fmod(phase+i*0.5,1.0)
			var stride:=lerpf(23,34,run_weight)*(0.58 if crouching else 1.0)
			if t<0.6:foot.x=(0.5-t/0.6)*stride
			else:
				var swing:=(t-0.6)/0.4
				foot.x=(-0.5+swing)*stride
				foot.y-=sin(swing*PI)*(5 if crouching else lerpf(8,13,run_weight))
		elif not grounded:
			foot=Vector2(12 if i==0 else -11,-12 if velocity_.y<0 else -6)
		elif slide:foot=Vector2(20 if i==0 else 12,-4 if i==0 else -7)
		feet[i]=feet[i].lerp(foot,1-exp(-30*dt))
		var hip_at:=skeleton.to_local(legs[i].global_position)
		var reach:=feet[i]-hip_at
		var min_reach:=sqrt(LEG_UPPER*LEG_UPPER+LEG_LOWER*LEG_LOWER+2*LEG_UPPER*LEG_LOWER*cos(deg_to_rad(138)))
		var reach_length:=clampf(reach.length(),min_reach,LEG_UPPER+LEG_LOWER-0.15)
		feet[i]=hip_at+reach.normalized()*reach_length
		solve_limb(legs[i],shins[i],feet[i],LEG_UPPER,LEG_LOWER)
		boots[i].rotation=-(legs[i].rotation+shins[i].rotation)
		var swing_angle:=sin(phase*TAU+i*PI)*lerpf(0.28,0.65,run_weight) if grounded and speed>8 else 0.0
		arms[i].rotation=smooth(arms[i].rotation,(-0.95 if holding else (-0.5 if not grounded else swing_angle))-lean,18,dt)
		forearms[i].rotation=smooth(forearms[i].rotation,-0.9 if holding else (-0.18-run_weight*0.48),18,dt)
