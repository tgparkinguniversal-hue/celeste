extends Node2D
class_name RigJointCover
# Opaque overlapping joint pads bridge the cropped art at all bend angles.
var radius:=5.0
var color:=Color("34313e")
func _draw() -> void:
	draw_circle(Vector2.ZERO,radius+0.7,Color("312622"))
	draw_circle(Vector2.ZERO,radius,color)
