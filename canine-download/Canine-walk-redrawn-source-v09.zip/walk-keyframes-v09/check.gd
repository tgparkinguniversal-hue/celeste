extends SceneTree
func _initialize():call_deferred("run")
func run():
	var viewport:=SubViewport.new();viewport.size=Vector2i(520,600);viewport.transparent_bg=true
	viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(viewport)
	var actor=load("res://actor.gd").new();viewport.add_child(actor);actor.position=Vector2(260,555)
	var detached:=[];var soles_ok:=true;var head_ok:=true;var head_texture=actor.head.texture
	var head_scale=actor.head.scale
	for direction in [1.0,-1.0]:
		actor.scale=Vector2(direction,1)
		for i in range(8):
			actor.clock=i/12.0+0.001;actor.animate(0,true)
			head_ok=head_ok and actor.head.texture==head_texture and actor.head.scale==head_scale
			await process_frame;await process_frame;await RenderingServer.frame_post_draw
			var image:=viewport.get_texture().get_image();var mask:=PackedByteArray();mask.resize(image.get_width()*image.get_height())
			for y in range(image.get_height()):
				for x in range(image.get_width()):mask[y*image.get_width()+x]=1 if image.get_pixel(x,y).a>0.8 else 0
			var pieces:=FrameCleaner.components(mask,image.get_width(),image.get_height());var substantial:=0
			for part in pieces:
				if part.size()>3:substantial+=1
			if substantial!=1:detached.append([direction,i,substantial])
			soles_ok=soles_ok and abs(image.get_used_rect().end.y-555)<=1
	var report:={"rendered_poses":16,"head_texture_and_scale_fixed":head_ok,"baseline_fixed":soles_ok,"detached":detached,"frames":actor.bank.frames.size()}
	print("WALK_CHECK ",JSON.stringify(report))
	FileAccess.open("/tmp/canine-build/walk-v09/check.json",FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
	quit(0 if head_ok and soles_ok and detached.is_empty() else 1)
