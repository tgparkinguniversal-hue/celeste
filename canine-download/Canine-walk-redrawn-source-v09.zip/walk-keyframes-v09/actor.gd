extends Node2D
var bank:WalkFrames
var body:Sprite2D
var head:Sprite2D
var idle:Sprite2D
var clock:=0.0
var frame_index:=0
func _ready():
	bank=load("res://frames.res")
	body=Sprite2D.new();body.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;add_child(body)
	head=Sprite2D.new();head.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;head.texture=bank.head;head.scale=Vector2.ONE*bank.head_scale;add_child(head)
	idle=Sprite2D.new();idle.texture=bank.original;idle.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;idle.scale=Vector2.ONE*bank.head_scale
	idle.position=(idle.texture.get_size()/2-Vector2(650,1358))*bank.head_scale;add_child(idle)
func animate(dt:float,moving:bool):
	body.visible=moving;head.visible=moving;idle.visible=not moving
	if not moving:return
	clock+=dt;frame_index=int(clock*12)%8
	body.texture=bank.frames[frame_index]
	var neck:=bank.necks[frame_index];var sole:=bank.soles[frame_index]
	body.position=body.texture.get_size()/2-Vector2(neck.x,sole)
	head.position=Vector2(0,neck.y-sole)+(head.texture.get_size()/2-bank.head_anchor)*bank.head_scale
