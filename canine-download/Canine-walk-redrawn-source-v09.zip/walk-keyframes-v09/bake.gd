extends SceneTree
func clean(im:Image) -> Image:
	var w:=im.get_width();var h:=im.get_height();var mask:=PackedByteArray();mask.resize(w*h)
	for y in range(h):
		for x in range(w):mask[y*w+x]=1 if im.get_pixel(x,y).a>=0.88 else 0
	var parts:=FrameCleaner.components(mask,w,h);var keep:=PackedInt32Array()
	for part in parts:
		if part.size()>keep.size():keep=part
	var rect:=FrameCleaner.bounds(keep,w)
	var result:=Image.create(rect.size.x+4,rect.size.y+4,false,Image.FORMAT_RGBA8);result.fill(Color.TRANSPARENT)
	for k in keep:
		var x:=k%w;var y:=int(k/w);var color:=im.get_pixel(x,y);color.a=1
		result.set_pixel(x-rect.position.x+2,y-rect.position.y+2,color)
	return result
func _initialize():
	var bank:=WalkFrames.new();var sheet:=Image.load_from_file("res://body_sheet.png")
	var total_height:=0.0
	for i in range(8):
		var col:=i%4;var row:=int(i/4)
		var x0:=roundi(col*sheet.get_width()/4.0);var x1:=roundi((col+1)*sheet.get_width()/4.0)
		var y0:=roundi(row*sheet.get_height()/2.0);var y1:=roundi((row+1)*sheet.get_height()/2.0)
		var im:=clean(sheet.get_region(Rect2i(x0,y0,x1-x0,y1-y0)))
		var minx:=im.get_width();var maxx:=0;var miny:=im.get_height();var maxy:=0
		for y in range(int(im.get_height()*0.16)):
			for x in range(int(im.get_width()*0.45),im.get_width()):
				var c:=im.get_pixel(x,y)
				if c.a>0.9 and c.r>0.35 and c.r>c.g*1.5 and c.b>c.g*0.75:
					minx=mini(minx,x);maxx=maxi(maxx,x);miny=mini(miny,y);maxy=maxi(maxy,y)
		var neck:=Vector2((minx+maxx)/2.0,miny+(maxy-miny)*0.35)
		var sole:=float(im.get_height()-2)
		bank.frames.append(ImageTexture.create_from_image(im));bank.necks.append(neck);bank.soles.append(sole)
		total_height+=sole-neck.y
		print("BODY ",i," size ",im.get_size()," neck ",neck," sole ",sole)
	var master:=Image.load_from_file("res://approved.png")
	var cropped:=master.get_region(Rect2i(250,110,700,630))
	for y in range(cropped.get_height()):
		for x in range(cropped.get_width()):
			var p:=Vector2(x+250,y+110)
			var inside:=p.y<625 or (p.x<530 and p.y<716) or (p.x>785 and p.y<705) or (p.y<660 and p.x>=530 and p.x<=785)
			if not inside:cropped.set_pixel(x,y,Color.TRANSPARENT)
	# Keep source crop coordinates so the head never changes registration or art.
	for y in range(cropped.get_height()):
		for x in range(cropped.get_width()):
			var c:=cropped.get_pixel(x,y)
			if c.a<0.88:cropped.set_pixel(x,y,Color.TRANSPARENT)
			else:c.a=1;cropped.set_pixel(x,y,c)
	bank.head=ImageTexture.create_from_image(cropped);bank.head_anchor=Vector2(650-250,660-110)
	bank.head_scale=(total_height/8.0)/(1358-660)
	bank.original=ImageTexture.create_from_image(master)
	var result:=ResourceSaver.save(bank,"res://frames.res",ResourceSaver.FLAG_COMPRESS)
	print("HEAD_SCALE ",bank.head_scale," save ",result)
	quit(result)
