extends SceneTree
func _initialize():
	var src:=Image.load_from_file("res://reference.png")
	var x0:=roundi(src.get_width()/4.0);var x1:=roundi(src.get_width()/2.0);var y1:=roundi(src.get_height()/2.0)
	var cell:=src.get_region(Rect2i(x0,0,x1-x0,y1))
	var w:=cell.get_width();var h:=cell.get_height();var mask:=PackedByteArray();mask.resize(w*h)
	for y in range(h):
		for x in range(w):mask[y*w+x]=1 if cell.get_pixel(x,y).a>=0.88 else 0
	var parts:=TacticalCleaner.components(mask,w,h);var keep:=PackedInt32Array()
	for part in parts:
		if part.size()>keep.size():keep=part
	var box:=TacticalCleaner.bounds(keep,w)
	var result:=Image.create(box.size.x+4,box.size.y+4,false,Image.FORMAT_RGBA8);result.fill(Color.TRANSPARENT)
	for k in keep:
		var x:=k%w;var y:=int(k/w);var c:=cell.get_pixel(x,y);c.a=1;result.set_pixel(x-box.position.x+2,y-box.position.y+2,c)
	result.save_png("res://sprite.png")
	print("SPRITE ",result.get_size());quit()
