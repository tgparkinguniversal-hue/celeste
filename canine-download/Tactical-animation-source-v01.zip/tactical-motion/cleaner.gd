extends Resource
class_name TacticalCleaner
@export var frames: Array[Texture2D] = []
@export var profiles: Array[Dictionary] = []
@export var removed_pixels := 0
@export var head_size := Vector2.ZERO

static func components(mask: PackedByteArray,w: int,h: int) -> Array:
	var visited:=PackedByteArray();visited.resize(w*h)
	var found:=[]
	for start in range(w*h):
		if mask[start]==0 or visited[start]!=0:continue
		var queue:=PackedInt32Array([start]);visited[start]=1;var offset:=0
		while offset<queue.size():
			var at:=queue[offset];offset+=1
			var x:=at%w;var y:=int(at/w)
			for dy in [-1,0,1]:
				for dx in [-1,0,1]:
					var nx:int=x+dx;var ny:int=y+dy
					if nx<0 or nx>=w or ny<0 or ny>=h:continue
					var k:=ny*w+nx
					if mask[k]!=0 and visited[k]==0:visited[k]=1;queue.append(k)
		found.append(queue)
	return found

static func bounds(points: PackedInt32Array,w: int) -> Rect2i:
	var left:=w;var top:=100000;var right:=0;var bottom:=0
	for k in points:
		var x:=k%w;var y:=int(k/w)
		left=mini(left,x);top=mini(top,y);right=maxi(right,x+1);bottom=maxi(bottom,y+1)
	return Rect2i(left,top,right-left,bottom-top)

