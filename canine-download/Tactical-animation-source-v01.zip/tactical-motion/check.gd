extends SceneTree
func _initialize():call_deferred("run")
func run():
	var actor=load("res://actor.gd").new();root.add_child(actor)
	var previous:Array[Vector2]=actor.foot_world.duplicate();var states:Array[bool]=actor.swing.duplicate()
	var drift:=0.0;var step:=0.0;var reach_error:=0.0
	for frame in range(18*120):
		var t:=frame/120.0;var mode: String="walk" if t>=2 and t<8 else ("run" if t>=9 and t<15 else "idle")
		actor.animate(1.0/120,mode)
		for i in range(2):
			var change:float=actor.foot_world[i].distance_to(previous[i]);step=maxf(step,change)
			if not states[i] and not actor.swing[i]:drift=maxf(drift,change)
			var ankle:Vector2=actor.feet[i]-Vector2(0,3.4)
			reach_error=maxf(reach_error,absf(actor.knees[i].distance_to(ankle)-actor.L2))
			previous[i]=actor.foot_world[i];states[i]=actor.swing[i]
	print("MODEL ",JSON.stringify({"max_stance_drift":drift,"max_frame_120hz":step,"max_leg_error":reach_error}))
	quit(0 if drift<0.01 and step<2 and reach_error<0.1 else 1)
