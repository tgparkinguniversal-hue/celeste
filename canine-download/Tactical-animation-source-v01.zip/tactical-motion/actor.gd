extends Node2D
const WALK_SPEED:=17.5
const RUN_SPEED:=35.0
const SLOPE:=0.45
const L1:=12.0
const L2:=12.0
var speed:=0.0
var origin:=Vector2.ZERO
var phase:=0.0
var period:=0.8
var contact:=0.62
var nominal:=WALK_SPEED
var feet:Array[Vector2]=[Vector2(3,-4.8),Vector2(-3,0)]
var foot_world:Array[Vector2]=[Vector2(3,-4.8),Vector2(-3,0)]
var hips:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var knees:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var swing:Array[bool]=[false,false]
var timers:Array[float]=[0.0,0.0]
var durations:Array[float]=[0.3,0.3]
var starts:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var targets:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var lifts:Array[float]=[3.0,3.0]
var last_cycle:Array[int]=[-1,-1]
var upper:Node2D
var boot:AtlasTexture
var lean:=0.0
var flight:=0.0
var last_mode:="idle"
func _ready():
	var texture:Texture2D=load("res://sprite.png")
	boot=AtlasTexture.new();boot.atlas=texture;boot.region=Rect2(26,396,64,49)
	upper=Node2D.new();upper.z_index=2;add_child(upper)
	var body:=Polygon2D.new();body.texture=texture;body.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	body.polygon=PackedVector2Array([Vector2(0,0),Vector2(214,0),Vector2(214,275),Vector2(0,275)])
	body.uv=body.polygon;body.scale=Vector2.ONE*0.12;body.position=-Vector2(100,275)*0.12;upper.add_child(body)
	var barrel:=Line2D.new();barrel.points=PackedVector2Array([Vector2(9,-4.8),Vector2(13.4,-1.2)]);barrel.width=1.0;barrel.default_color=Color("151813");upper.add_child(barrel)
	animate(0,"idle")
func animate(dt:float,mode:String):
	var running:=mode=="run"
	var desired:=RUN_SPEED if running else (WALK_SPEED if mode=="walk" else 0.0)
	speed=move_toward(speed,desired,dt*60)
	if mode!="idle":
		nominal=lerpf(nominal,RUN_SPEED if running else WALK_SPEED,1-exp(-8*dt))
		period=lerpf(period,0.48 if running else 0.8,1-exp(-8*dt))
		contact=lerpf(contact,0.38 if running else 0.62,1-exp(-8*dt))
	phase+=dt/period*(speed/nominal)
	origin+=Vector2(speed,speed*SLOPE)*dt
	for i in range(2):
		var hip_x:float=3 if i==0 else -3
		var depth:float=-4.8 if i==0 else 0
		var cycle:=floori(phase+i*0.5);var t:=fposmod(phase+i*0.5,1)
		if not swing[i] and speed>0.05 and t>=contact and last_cycle[i]!=cycle:
			swing[i]=true;last_cycle[i]=cycle;timers[i]=0
			durations[i]=maxf(0.12,(1-contact)*period)
			starts[i]=foot_world[i]
			var front:=nominal*period*contact/2
			targets[i]=origin+Vector2(speed,speed*SLOPE)*durations[i]+Vector2(hip_x+front,depth+front*SLOPE)
			lifts[i]=5.0 if running else 3.2
		if swing[i]:
			timers[i]+=dt;var u:=clampf(timers[i]/durations[i],0,1)
			var eased:=u*u*(3-2*u)
			foot_world[i]=starts[i].lerp(targets[i],eased)-Vector2(0,sin(u*PI)*lifts[i])
			if u>=1:swing[i]=false;foot_world[i]=targets[i]
		feet[i]=foot_world[i]-origin
	flight=lerpf(flight,1.0 if swing[0] and swing[1] and running else 0.0,1-exp(-20*dt))
	var body_y:float=(-21.5 if running else -22.0)-flight*1.4+sin(phase*TAU*2)*(0.3 if speed>1 else 0.1)
	lean=lerpf(lean,0.12 if running else (0.02 if mode=="walk" else 0.0),1-exp(-10*dt))
	upper.position=Vector2(0,body_y);upper.rotation=lean+sin(phase*TAU)*0.008
	for i in range(2):
		hips[i]=Vector2(3 if i==0 else -3,body_y-0.7 if i==0 else body_y)
		var ankle:=feet[i]-Vector2(0,3.4)
		var delta:=ankle-hips[i];var length:=clampf(delta.length(),0.1,L1+L2-0.05)
		var angle:=delta.angle()-acos(clampf((L1*L1+length*length-L2*L2)/(2*L1*length),-1,1))
		knees[i]=hips[i]+Vector2.from_angle(angle)*L1
	last_mode=mode;queue_redraw()
func _draw():
	draw_set_transform(Vector2(0,-1),0,Vector2(1,0.28));draw_circle(Vector2.ZERO,10,Color(0.02,0.03,0.02,0.17*(1-flight*0.4)));draw_set_transform(Vector2.ZERO)
	draw_rect(Rect2(-6,upper.position.y-1,12,3),Color("454536"))
	for i in range(2):
		var shade:=Color("c2c2b6") if i==0 else Color.WHITE
		var ankle:=feet[i]-Vector2(0,3.4)
		var up:Vector2=(knees[i]-hips[i]).normalized().orthogonal();var low:Vector2=(ankle-knees[i]).normalized().orthogonal();var mid:Vector2=(up+low).normalized()
		var edge:=PackedVector2Array([hips[i]+up*2.5,knees[i]+mid*2.2,ankle+low*1.6,ankle-low*1.6,knees[i]-mid*2.2,hips[i]-up*2.5])
		draw_colored_polygon(edge,Color("484936")*shade)
		var outline:=edge.duplicate();outline.append(edge[0]);draw_polyline(outline,Color("171b16"),0.8,false)
		draw_colored_polygon(PackedVector2Array([hips[i]+up*0.6,knees[i]+mid*0.8,ankle+low*0.4,ankle,knees[i],hips[i]]),Color("5c5d44")*shade)
		var center:Vector2=hips[i].lerp(knees[i],0.5)+up*0.6;var axis:Vector2=(knees[i]-hips[i]).normalized()
		draw_colored_polygon(PackedVector2Array([center-up*1.5-axis*2,center+up*1.5-axis*2,center+up*1.5+axis*2,center-up*1.5+axis*2]),Color("343a2d")*shade)
		draw_texture_rect(boot,Rect2(ankle+Vector2(-3.5,-2.2),Vector2(8,5.6)),false,shade)
