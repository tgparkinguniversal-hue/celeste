extends SceneTree
func _initialize():call_deferred("run")
func pieces(mask:PackedByteArray)->Array:
	var seen:=PackedByteArray();seen.resize(4096);var result:=[]
	for start in range(4096):
		if mask[start]==0 or seen[start]!=0:continue
		var queue:=PackedInt32Array([start]);seen[start]=1;var offset:=0
		while offset<queue.size():
			var k:=queue[offset];offset+=1;var x:=k%64;var y:=int(k/64)
			for dy in [-1,0,1]:
				for dx in [-1,0,1]:
					var nx:int=x+dx;var ny:int=y+dy
					if nx<0 or nx>=64 or ny<0 or ny>=64:continue
					var at:int=ny*64+nx
					if mask[at]!=0 and seen[at]==0:seen[at]=1;queue.append(at)
		result.append(queue.size())
	return result
func run():
	var view:=SubViewport.new();view.size=Vector2i(64,64);view.transparent_bg=true;view.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(view)
	var actor=load("res://actor.gd").new();actor.position=Vector2(32,57);view.add_child(actor)
	var detached:=[];var clipped:=[];var count:=0
	for mode in ["idle","walk","run","idle"]:
		for sample in range(12):
			for frame in range(6):actor.animate(1.0/60,mode)
			await process_frame;await process_frame;await RenderingServer.frame_post_draw
			var im:=view.get_texture().get_image();var mask:=PackedByteArray();mask.resize(4096)
			for y in range(64):
				for x in range(64):mask[y*64+x]=1 if im.get_pixel(x,y).a>0.8 else 0
			var large:=0
			for size in pieces(mask):
				if size>1:large+=1
			if large!=1:detached.append([mode,sample,large])
			for x in range(64):
				if mask[x]!=0 or mask[63*64+x]!=0:clipped.append([mode,sample]);break
			count+=1
	print("RENDER ",JSON.stringify({"poses":count,"detached":detached,"clipped":clipped}))
	quit(0 if detached.is_empty() and clipped.is_empty() else 1)
