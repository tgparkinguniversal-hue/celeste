extends Node2D
var actor
var picture:Sprite2D
var time:=0.0
var mode:="idle"
var camera:Camera2D
var label:Label
var font:=SystemFont.new()
func _ready():
	font.font_names=PackedStringArray(["DejaVu Sans"])
	var view:=SubViewport.new();view.size=Vector2i(64,64);view.transparent_bg=true;view.render_target_update_mode=SubViewport.UPDATE_ALWAYS;add_child(view)
	actor=load("res://actor.gd").new();actor.position=Vector2(32,57);view.add_child(actor)
	picture=Sprite2D.new();picture.texture=view.get_texture();picture.centered=false;picture.scale=Vector2.ONE*6;picture.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;add_child(picture)
	camera=Camera2D.new();camera.position=Vector2(550,350);camera.position_smoothing_enabled=true;camera.position_smoothing_speed=7;add_child(camera)
	var ui:=CanvasLayer.new();add_child(ui)
	var title:=Label.new();title.text="PERSONAGEM TÁTICO · PARADO / ANDANDO / CORRENDO";title.position=Vector2(32,24);title.add_theme_font_override("font",font);title.add_theme_font_size_override("font_size",21);ui.add_child(title)
	label=Label.new();label.position=Vector2(32,65);label.add_theme_font_override("font",font);label.add_theme_font_size_override("font_size",20);ui.add_child(label)
	var note:=Label.new();note.text="Prévia em uma direção · renderização 64×64 ampliada · captura fixa de 60 FPS";note.position=Vector2(32,680);note.add_theme_font_override("font",font);ui.add_child(note)
func _process(dt):
	time+=dt
	mode="walk" if time>=2 and time<8 else ("run" if time>=9 and time<15 else "idle")
	actor.animate(dt,mode)
	var ground:Vector2=Vector2(450,500)+actor.origin*6
	picture.position=ground-Vector2(32,57)*6
	camera.position=ground+Vector2(100,-150)
	label.text={"idle":"PARADO","walk":"ANDANDO","run":"CORRENDO"}[mode]
	queue_redraw()
	if time>18:get_tree().quit()
func _draw():
	draw_rect(Rect2(-5000,-3000,15000,10000),Color("3b4942"))
	for i in range(-80,150):
		var x:float=i*96
		draw_line(Vector2(x-6000,-3000),Vector2(x+10000,5000),Color(0.65,0.7,0.65,0.11),1)
		draw_line(Vector2(x+6000,-3000),Vector2(x-10000,5000),Color(0.65,0.7,0.65,0.11),1)
