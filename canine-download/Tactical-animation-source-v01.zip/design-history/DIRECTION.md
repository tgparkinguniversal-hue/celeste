# Direção visual atual

O usuário substituiu a proposta de aventureiro por uma referência de soldado tático em pixel art de vista lateral, com proporções adultas, roupa escura e detalhes discretos.

Proposta atual: tactical-character-review-v02.png. Estado: aguardando avaliação visual. A imagem é um conceito ampliado inspirado na referência, não uma folha de animação nem um sprite final registrado em grade real.

Preparar animações apenas depois de validar a pose base. Preservar as propostas anteriores como histórico.
