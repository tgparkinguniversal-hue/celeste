# Oito direções — proposta visual

Arquivo: tactical-eight-directions-review-v03.png.

Ordem de leitura: primeira linha, baixo, baixo-direita, direita e cima-direita; segunda linha, cima, cima-esquerda, esquerda e baixo-esquerda.

Folha de referência ampliada para avaliação das poses paradas e da perspectiva. Não é ainda uma atlas final de células reais de 64×64 nem uma animação. Registrar pivôs de apoio, escala, paleta e oclusões do equipamento antes de utilizá-la no jogo.

Estado: aguardando avaliação do usuário.
