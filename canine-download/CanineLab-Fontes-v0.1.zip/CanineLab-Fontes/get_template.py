import ctypes,subprocess,json,hashlib,zipfile
from pathlib import Path
lib=ctypes.CDLL('libarchive.so.13');ptr=ctypes.c_void_p
lib.archive_read_new.restype=ptr
for name in ['archive_read_support_filter_all','archive_read_support_format_zip','archive_read_close','archive_read_free']:
 getattr(lib,name).argtypes=[ptr]
lib.archive_read_open_fd.argtypes=[ptr,ctypes.c_int,ctypes.c_size_t]
lib.archive_read_next_header.argtypes=[ptr,ctypes.POINTER(ptr)]
lib.archive_entry_pathname.argtypes=[ptr];lib.archive_entry_pathname.restype=ctypes.c_char_p
lib.archive_read_data.argtypes=[ptr,ptr,ctypes.c_size_t];lib.archive_read_data.restype=ctypes.c_ssize_t
lib.archive_error_string.argtypes=[ptr];lib.archive_error_string.restype=ctypes.c_char_p
url='https://github.com/godotengine/godot-builds/releases/download/4.2.1-stable/Godot_v4.2.1-stable_export_templates.tpz'
process=subprocess.Popen(['curl','--location','--fail','--silent','--show-error','--max-time','600',url],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
a=lib.archive_read_new();lib.archive_read_support_filter_all(a);lib.archive_read_support_format_zip(a);assert lib.archive_read_open_fd(a,process.stdout.fileno(),65536)==0
try:
 entry=ptr();selected=None
 while lib.archive_read_next_header(a,ctypes.byref(entry))==0:
  name=lib.archive_entry_pathname(entry).decode();print('Archive entry',name,flush=True)
  if name.endswith('/windows_release_x86_64.exe'):
   selected=name;path=Path('/tmp/canine-build/windows_release_x86_64.exe');buffer=ctypes.create_string_buffer(65536)
   with path.open('wb') as output:
    while True:
     n=lib.archive_read_data(a,buffer,len(buffer))
     if n==0:break
     if n<0:raise RuntimeError(lib.archive_error_string(a).decode())
     output.write(buffer.raw[:n])
   break
 if not selected:raise RuntimeError('Android release entry not found: '+str(lib.archive_error_string(a)))
 assert path.read_bytes()[:2]==b'MZ'
 result={'release':'4.2.1-stable','template':selected,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source':'Official Godot templates release, sequential archive extraction'};Path('/workspace/canine-lab/template-inventory.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
finally:
 lib.archive_read_close(a);lib.archive_read_free(a);process.terminate();process.wait(timeout=10)
