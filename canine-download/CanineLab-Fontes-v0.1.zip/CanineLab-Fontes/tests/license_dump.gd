extends SceneTree
func _initialize() -> void:
	var f := FileAccess.open("/workspace/canine-lab/GODOT-LICENSES.txt", FileAccess.WRITE)
	f.store_string(Engine.get_license_text() + "\n\nThird-party licenses\n\n" + JSON.stringify(Engine.get_license_info(), "  ") + "\n\nCopyright information\n\n" + JSON.stringify(Engine.get_copyright_info(), "  "))
	quit()
