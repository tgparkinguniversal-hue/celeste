extends SceneTree
var lab
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	lab = load("res://main.tscn").instantiate()
	root.add_child(lab)
	await process_frame
	lab.player.input_override = true
	for i in range(45):
		await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/screens/idle.png")
	lab.player.test_input = {"axis": 1.0, "run": true}
	for i in range(90):
		await physics_frame
		await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/screens/run.png")
	lab.player.test_input = {"jump": true, "jump_held": true}
	await physics_frame
	await process_frame
	lab.player.test_input = {"jump_held": true}
	for i in range(20):
		await physics_frame
		await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/screens/jump.png")
	print("VISUAL_PROBE_COMPLETE")
	lab.queue_free()
	await process_frame
	quit()
