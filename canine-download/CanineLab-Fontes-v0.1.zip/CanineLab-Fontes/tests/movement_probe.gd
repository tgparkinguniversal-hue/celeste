extends SceneTree
var lab
var p
var checks := 0
var failures: Array[String] = []
func _initialize() -> void:
	call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks += 1
	print(("PASS " if ok else "FAIL ") + message)
	if not ok:
		failures.append(message)
func tick(count: int, cmd := {}) -> void:
	p.test_input = cmd
	for i in range(count):
		await physics_frame
		await process_frame
func reset_player(at := Vector3(-18, 0.04, 0)) -> void:
	p.reset()
	p.global_position = at
	await tick(25)
func run() -> void:
	lab = load("res://main.tscn").instantiate()
	root.add_child(lab)
	p = lab.player
	p.input_override = true
	await reset_player()
	check(p.is_on_floor(), "ground contact")
	await tick(90, {"axis": 1.0})
	check(abs(p.velocity.x - p.WALK) < 0.05, "walk reaches speed")
	check(p.state == "walk", "walk animation state")
	await tick(30)
	check(abs(p.velocity.x) < 0.01, "ground braking")
	await reset_player()
	await tick(90, {"axis": 1.0, "run": true})
	check(abs(p.velocity.x - p.RUN) < 0.05, "run reaches speed")
	check(p.state == "run", "run animation state")
	await tick(1, {"axis": 1.0, "slide": true})
	await tick(5, {"axis": 1.0})
	check(p.slide_time > 0 and p.crouched, "slide enters low collider")
	await tick(100)
	check(p.slide_time <= 0, "slide finishes")
	await reset_player()
	await tick(1, {"jump": true, "jump_held": true})
	var peak_long: float = p.position.y
	for i in range(130):
		await tick(1, {"jump_held": true})
		peak_long = max(peak_long, p.position.y)
	check(peak_long > 1.45, "full jump height")
	check(p.is_on_floor(), "jump returns to ground")
	await reset_player()
	await tick(1, {"jump": true, "jump_held": true})
	var peak_short: float = p.position.y
	for i in range(130):
		await tick(1)
		peak_short = max(peak_short, p.position.y)
	check(peak_short < peak_long * 0.8, "released jump is shorter")
	# Low passage: teleport with collider already reduced.
	await reset_player()
	p.crouched = true
	p.capsule.height = p.LOW_HEIGHT
	p.collider.position.y = p.LOW_HEIGHT / 2
	p.position = Vector3(-5, 0.02, 0)
	await tick(30)
	check(p.crouched and not p.can_stand(), "cannot stand into ceiling")
	p.position = Vector3(-10, 0.02, 0)
	await tick(25)
	check(not p.crouched, "stands after clearance")
	await reset_player()
	# A jump buffered shortly before touchdown must trigger on landing.
	p.position.y = 0.35
	p.velocity.y = -2.0
	await tick(2)
	var initial_jumps: int = p.jumps
	await tick(1, {"jump": true, "jump_held": true})
	await tick(18, {"jump_held": true})
	check(p.jumps > initial_jumps and p.velocity.y > 0, "landing jump buffer")
	await reset_player()
	# Walk beyond the first platform edge with a controlled coyote window.
	p.position = Vector3(5.98, 0.02, 0)
	await tick(3, {"axis": 1.0, "run": true})
	var got_edge := false
	for i in range(40):
		await tick(1, {"axis": 1.0, "run": true})
		if not p.is_on_floor():
			got_edge = true
			break
	var count_before: int = p.jumps
	await tick(1, {"axis": 1.0, "jump": true, "jump_held": true})
	await tick(2, {"jump_held": true})
	check(got_edge and p.jumps > count_before, "coyote jump off edge")
	p.position.y = -12
	await tick(3)
	check(p.position.y > -1 and abs(p.position.z) < 0.001, "fall reset and movement plane")
	check(p.sheet != null and p.atlas != null, "sprite sheet loaded")
	# Synthetic Godot gamepad events exercise action mapping, not USB transport.
	var button := InputEventJoypadButton.new()
	button.button_index = JOY_BUTTON_A
	button.pressed = true
	Input.parse_input_event(button)
	await process_frame
	check(InputMap.event_is_action(button, "jump"), "standard gamepad cross mapping")
	button.pressed = false
	Input.parse_input_event(button)
	var axis := InputEventJoypadMotion.new()
	axis.axis = JOY_AXIS_LEFT_X
	axis.axis_value = 0.07
	Input.parse_input_event(axis)
	await process_frame
	check(is_equal_approx(InputMap.action_get_deadzone("left"), 0.20) and is_equal_approx(InputMap.action_get_deadzone("right"), 0.20), "stick deadzone configured")
	for pair in [[JOY_BUTTON_B, "crouch"], [JOY_BUTTON_X, "slide"], [JOY_BUTTON_START, "pause"], [JOY_BUTTON_LEFT_STICK, "run"]]:
		var b := InputEventJoypadButton.new()
		b.button_index = pair[0]
		b.pressed = true
		check(InputMap.event_is_action(b, pair[1]), "gamepad action " + pair[1])
	lab.set_pause(true)
	check(not p.is_physics_processing() and lab.pause_panel.visible, "pause suspends controller")
	lab.set_pause(false)
	check(p.is_physics_processing(), "resume restores controller")
	print("RESULT %d checks / %d failures" % [checks, failures.size()])
	FileAccess.open("/tmp/canine-build/movement-results.json", FileAccess.WRITE).store_string(JSON.stringify({"checks": checks, "failures": failures, "jump_peak_full": peak_long, "jump_peak_short": peak_short}, "  "))
	lab.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
