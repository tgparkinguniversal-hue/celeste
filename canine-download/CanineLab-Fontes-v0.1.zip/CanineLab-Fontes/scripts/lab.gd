extends Node3D

var player: CaninePlayer
var camera: Camera3D
var hud: Label
var pad_label: Label
var pause_panel: PanelContainer
var paused := false
var camera_x := -18.0
var camera_y := 1.6
var help_visible := true
var elapsed := 0.0
var world: Node3D
var resume_button: Button
var help: Label
var stage_material: StandardMaterial3D

func _ready() -> void:
	configure_input()
	world = Node3D.new()
	world.name = "Stage"
	add_child(world)
	build_stage()
	player = CaninePlayer.new()
	player.name = "Player"
	add_child(player)
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 10.0
	camera.near = 0.1
	camera.far = 150
	add_child(camera)
	update_camera(1)
	build_ui()
	Input.joy_connection_changed.connect(joy_changed)
	joy_changed(0, true)

func configure_input() -> void:
	add_action("left", [KEY_A, KEY_LEFT], [JOY_BUTTON_DPAD_LEFT], JOY_AXIS_LEFT_X, -1)
	add_action("right", [KEY_D, KEY_RIGHT], [JOY_BUTTON_DPAD_RIGHT], JOY_AXIS_LEFT_X, 1)
	add_action("jump", [KEY_SPACE, KEY_W, KEY_UP], [JOY_BUTTON_A])
	add_action("run", [KEY_SHIFT], [JOY_BUTTON_LEFT_STICK], JOY_AXIS_TRIGGER_RIGHT, 1)
	add_action("crouch", [KEY_CTRL, KEY_S, KEY_DOWN], [JOY_BUTTON_B])
	add_action("slide", [KEY_C], [JOY_BUTTON_X])
	add_action("reset", [KEY_R], [JOY_BUTTON_BACK])
	add_action("pause", [KEY_ESCAPE], [JOY_BUTTON_START])
	add_action("help", [KEY_TAB, KEY_F1], [JOY_BUTTON_Y])

func add_action(action: String, keycodes: Array, buttons: Array, axis := -1, value := 0.0) -> void:
	if InputMap.has_action(action):
		InputMap.erase_action(action)
	InputMap.add_action(action, 0.20)
	for key in keycodes:
		var event := InputEventKey.new()
		event.physical_keycode = key
		InputMap.action_add_event(action, event)
	for button in buttons:
		var event := InputEventJoypadButton.new()
		event.button_index = button
		InputMap.action_add_event(action, event)
	if axis >= 0:
		var event := InputEventJoypadMotion.new()
		event.axis = axis
		event.axis_value = value
		InputMap.action_add_event(action, event)

func block(center: Vector3, size: Vector3, color: Color, angle := 0.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = center
	body.rotation.z = angle
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.9
	mesh.material_override = mat
	body.add_child(mesh)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	world.add_child(body)
	return body

func sign_at(text: String, at: Vector3) -> void:
	var label := Label3D.new()
	label.text = text
	label.font_size = 48
	label.pixel_size = 0.006
	label.modulate = Color(0.60, 0.69, 0.72)
	label.position = at
	label.no_depth_test = false
	world.add_child(label)

func build_stage() -> void:
	var environment := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("1b232c")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("b1bac2")
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.environment = env
	add_child(environment)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-45, -25, 0)
	light.light_energy = 1.4
	light.shadow_enabled = true
	add_child(light)
	# Three flat test zones with genuine gaps; all are untextured boxes.
	block(Vector3(-9, -0.5, 0), Vector3(30, 1, 5), Color("7e898d"))
	block(Vector3(13, -0.5, 0), Vector3(8, 1, 5), Color("7e898d"))
	block(Vector3(30, -0.5, 0), Vector3(20, 1, 5), Color("7e898d"))
	block(Vector3(-24.5, 2, 0), Vector3(1, 6, 5), Color("515e66"))
	block(Vector3(40.5, 2, 0), Vector3(1, 6, 5), Color("515e66"))
	# Clearance gate: 1.05 m underneath, only crouch/slide fits.
	block(Vector3(-5, 1.43, 0), Vector3(4, 0.66, 3.8), Color("a0a9aa"))
	# Low steps, high landing pads and a gentle ramp.
	block(Vector3(1, 0.2, 0), Vector3(1.4, 0.4, 4), Color("9da5a4"))
	block(Vector3(3, 0.45, 0), Vector3(1.4, 0.9, 4), Color("aab1af"))
	block(Vector3(11, 1.3, 0), Vector3(2.4, 0.45, 3.8), Color("aab1af"))
	block(Vector3(15, 2.3, 0), Vector3(2.6, 0.45, 3.8), Color("bdc2bd"))
	block(Vector3(24, 0.65, 0), Vector3(5, 0.32, 4), Color("969f9f"), deg_to_rad(15))
	block(Vector3(28, 1.25, 0), Vector3(3.2, 0.4, 4), Color("bdc2bd"))
	block(Vector3(33, 0.35, 0), Vector3(1.2, 0.7, 3.8), Color("969f9f"))
	# Abstract background pillars: no texture assets.
	for i in range(18):
		var x := -26.0 + i * 4.0
		block(Vector3(x, 1.5, -6), Vector3(0.06, 7, 0.06), Color("35414b"))
	for i in range(15):
		var line := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(0.025, 0.012, 4.5)
		line.mesh = box
		line.position = Vector3(-22 + i * 2, 0.008, 0)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color("a3acaa")
		line.material_override = mat
		world.add_child(line)
	sign_at("01  /  ACELERAÇÃO", Vector3(-16, 3.3, -1.4))
	sign_at("02  /  AGACHAR · DESLIZAR", Vector3(-5, 3.3, -1.4))
	sign_at("03  /  SALTOS", Vector3(11, 4.5, -1.4))
	sign_at("04  /  RAMPA", Vector3(27, 4.5, -1.4))

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := PanelContainer.new()
	panel.position = Vector2(28, 24)
	panel.size = Vector2(365, 96)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.07, 0.10, 0.13, 0.91)
	style.border_color = Color("465968")
	style.set_border_width_all(1)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 13
	style.content_margin_bottom = 13
	style.set_corner_radius_all(5)
	panel.add_theme_stylebox_override("panel", style)
	layer.add_child(panel)
	var column := VBoxContainer.new()
	panel.add_child(column)
	var title := Label.new()
	title.text = "CANINE  /  MOVEMENT LAB"
	title.add_theme_font_size_override("font_size", 17)
	title.modulate = Color("e1bb80")
	column.add_child(title)
	hud = Label.new()
	hud.add_theme_font_size_override("font_size", 14)
	column.add_child(hud)
	pad_label = Label.new()
	pad_label.add_theme_font_size_override("font_size", 12)
	pad_label.modulate = Color("9bb4c1")
	column.add_child(pad_label)
	help = Label.new()
	help.position = Vector2(30, 608)
	help.add_theme_font_size_override("font_size", 14)
	help.text = "TECLADO   A D / ← → mover   ·   Shift correr   ·   Espaço pular   ·   Ctrl agachar   ·   C deslizar\nDUALSENSE   analógico / direcional   ·   R2 / L3 correr   ·   × pular   ·   ○ agachar   ·   □ deslizar\nR / Create reiniciar   ·   Esc / Options pausar   ·   Tab / △ ocultar ajuda"
	layer.add_child(help)
	pause_panel = PanelContainer.new()
	pause_panel.position = Vector2(440, 260)
	pause_panel.size = Vector2(400, 160)
	pause_panel.add_theme_stylebox_override("panel", style)
	var pause_column := VBoxContainer.new()
	pause_panel.add_child(pause_column)
	var label := Label.new()
	label.text = "PAUSADO\n\nEsc / Options para continuar"
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_column.add_child(label)
	resume_button = Button.new()
	resume_button.text = "Continuar"
	resume_button.pressed.connect(func(): set_pause(false))
	pause_column.add_child(resume_button)
	var exit_button := Button.new()
	exit_button.text = "Sair do jogo"
	exit_button.pressed.connect(func(): get_tree().quit())
	pause_column.add_child(exit_button)
	pause_panel.visible = false
	layer.add_child(pause_panel)

func joy_changed(_id: int, _connected: bool) -> void:
	if not pad_label:
		return
	var ids := Input.get_connected_joypads()
	pad_label.text = "Teclado ativo · conecte seu DualSense por USB/Bluetooth"
	if not ids.is_empty():
		pad_label.text = Input.get_joy_name(ids[0]) + " · controle conectado"

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and is_instance_valid(player):
		set_pause(true)

func set_pause(value: bool) -> void:
	paused = value
	if is_instance_valid(player):
		player.set_physics_process(not paused)
		player.set_process(not paused)
	if pause_panel:
		pause_panel.visible = paused
		if paused and resume_button:
			resume_button.grab_focus()

func _process(dt: float) -> void:
	if Input.is_physical_key_pressed(KEY_F11) and not get_meta("fullscreen_key", false):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)
	set_meta("fullscreen_key", Input.is_physical_key_pressed(KEY_F11))
	if Input.is_action_just_pressed("pause"):
		set_pause(not paused)
	if Input.is_action_just_pressed("reset"):
		player.reset()
	if Input.is_action_just_pressed("help"):
		help_visible = not help_visible
		help.visible = help_visible
	if paused:
		return
	elapsed += dt
	update_camera(dt)
	var states := {"idle": "PARADO", "walk": "ANDANDO", "run": "CORRENDO", "crouch": "AGACHADO", "slide": "DESLIZANDO", "jump": "SUBINDO", "fall": "CAINDO"}
	hud.text = "%s   ·   %.1f m/s   ·   %d FPS" % [states.get(player.state, player.state), absf(player.velocity.x), Engine.get_frames_per_second()]

func update_camera(dt: float) -> void:
	var look := clampf(player.velocity.x * 0.23, -1.4, 1.4)
	camera_x = lerpf(camera_x, player.position.x + look, 1 - exp(-dt * 5.5))
	camera_y = lerpf(camera_y, maxf(1.6, player.position.y + 1.2), 1 - exp(-dt * 3.4))
	camera.position = Vector3(camera_x, camera_y + 3.4, 14)
	camera.look_at(Vector3(camera_x, camera_y, 0), Vector3.UP)
