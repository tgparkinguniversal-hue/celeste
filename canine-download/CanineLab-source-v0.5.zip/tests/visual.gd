extends SceneTree
var app
func _initialize() -> void:call_deferred("run")
func run() -> void:
	app=load("res://main.tscn").instantiate();root.add_child(app)
	for i in range(40):await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/v04/title.png")
	app.set_mode("game")
	for i in range(10):await process_frame
	app.set_mode("pause")
	for i in range(5):await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/v04/pause.png")
	app.play();app.player.override_input=true
	app.player.commands={"axis":1.0,"crouch":true}
	for i in range(40):await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/v04/crawl.png")
	app.open_controls()
	for i in range(3):await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/v04/controls.png")
	print("VISUAL_COMPLETE")
	app.queue_free();await process_frame;quit()
