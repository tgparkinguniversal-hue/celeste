extends SceneTree
func _initialize() -> void:
	var bank:=SpriteBank.bake()
	var result:=ResourceSaver.save(bank,"/tmp/canine-build/v05/actor_bank.res",ResourceSaver.FLAG_COMPRESS)
	print("BANK ",bank.frames.size()," frames; removed=",bank.removed_pixels," head=",bank.head_size," save=",result)
	for i in [0,8,16,27,40,50,56,60]:print("PROFILE ",i," ",bank.profiles[i])
	quit(result)
