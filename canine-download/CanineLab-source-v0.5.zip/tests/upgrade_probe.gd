extends SceneTree
var shell
var app
var failures:=[]
var checks:=0
func _initialize():call_deferred("run")
func check(ok: bool,msg: String):
	checks+=1;print(("PASS " if ok else "FAIL ")+msg)
	if not ok:failures.append(msg)
func frames(n: int):
	for i in range(n):await physics_frame;await process_frame
func run():
	shell=load("res://shell.tscn").instantiate();root.add_child(shell);app=shell.game
	await frames(4)
	check(shell.render_view.size==Vector2i(1920,1080),"Full HD actual render target")
	check(shell.render_view.get_texture().get_size()==Vector2(1920,1080),"Full HD texture")
	shell.render_view.get_texture().get_image().save_png("/tmp/canine-build/v05/title-fullhd.png")
	# Route a real mouse click through the scaled SubViewportContainer.
	var at=app.first_title.get_global_rect().get_center()
	for pressed in [true,false]:
		var e:=InputEventMouseButton.new();e.button_index=MOUSE_BUTTON_LEFT;e.pressed=pressed
		e.position=shell.container.position+at*Vector2(shell.target_size)/Vector2(1280,720)*shell.container.scale
		root.push_input(e);await frames(2)
	check(app.mode=="game","mouse routed through scaled viewport")
	app.play();app.player.override_input=true;await frames(20)
	var bank:SpriteBank=app.player.bank
	var stable:=true;var isolated:=true
	for i in range(bank.frames.size()):
		var profile=bank.profiles[i]
		stable=stable and (Vector2(profile.head.size)*Vector2(profile.scale)).distance_to(bank.head_size)<0.001
		var im=bank.frames[i].get_image();var mask:=PackedByteArray();mask.resize(im.get_width()*im.get_height())
		for y in range(im.get_height()):
			for x in range(im.get_width()):mask[y*im.get_width()+x]=1 if im.get_pixel(x,y).a>0 else 0
		isolated=isolated and SpriteBank.components(mask,im.get_width(),im.get_height()).size()==1
	check(stable,"canonical head proportions across all 68 frames")
	check(isolated,"no disconnected flying pixels in baked frames")
	check(bank.frames.size()==68 and bank.profiles[64].group=="slide","dedicated low slide cycle")
	shell.set_quality(1);await frames(3)
	check(shell.render_view.size==Vector2i(2560,1440) and shell.render_view.get_texture().get_size()==Vector2(2560,1440),"QHD actual render texture")
	check(shell.render_view.size_2d_override==Vector2i(1280,720),"logical scale preserved at QHD")
	app.open_options();await frames(2)
	shell.render_view.get_texture().get_image().save_png("/tmp/canine-build/v05/options-qhd.png")
	shell.set_quality(0);app.play();await frames(110)
	var prop=app.world.props[0]
	check(app.world.props.size()==6,"six rigid physics objects")
	check(absf(prop.position.y+prop.dimensions.y/2)<5,"crate settles on floor")
	app.player.position=prop.position+Vector2(-90,prop.dimensions.y/2-1)
	app.player.previous_position=app.player.position
	app.player.commands={"grab":true};await frames(6)
	check(is_instance_valid(app.player.grabbed),"E R1 grab acquires nearby body")
	var oldx:float=prop.position.x
	app.player.commands={"grab":true,"axis":-1.0};await frames(100)
	check(prop.position.x<oldx-45,"grab spring pulls crate backwards")
	app.player.commands={};await frames(2)
	check(app.player.grabbed==null,"release object")
	app.world.request_point=prop.position;app.world.pending_pick=true;await frames(1)
	check(app.world.mouse_body==prop,"mouse point pick finds physics object")
	app.world.mouse_body=null
	var old_lift:Vector2=app.world.lift.position;await frames(20)
	check(app.world.lift.position.distance_to(old_lift)>1,"moving platform travels")
	app.set_mode("pause");await frames(2);var oldp:Vector2=prop.position;old_lift=app.world.lift.position;await frames(15)
	print("PAUSE_DATA ",prop.freeze," ",prop.position-oldp," lift ",app.world.lift.position-old_lift)
	check(prop.freeze and prop.position.distance_to(oldp)<0.1 and app.world.lift.position==old_lift,"pause freezes props and platform")
	app.restart();await frames(2)
	print("RESET_DATA ",prop.position," start ",prop.start_position)
	check(absf(prop.position.x-prop.start_position.x)<1 and absf(prop.position.y-prop.start_position.y)<2,"restart restores physics props")
	app.player.position=Vector2(46*72,-2);app.player.previous_position=app.player.position;await frames(60)
	shell.render_view.get_texture().get_image().save_png("/tmp/canine-build/v05/physics-fullhd.png")
	print("RESULT %d checks / %d failures"%[checks,failures.size()])
	FileAccess.open("/tmp/canine-build/v05/upgrade-results.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures},"  "))
	quit(0 if failures.is_empty() else 1)
