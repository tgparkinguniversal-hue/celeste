extends Resource
class_name SpriteBank
@export var frames: Array[Texture2D] = []
@export var profiles: Array[Dictionary] = []
@export var removed_pixels := 0
@export var head_size := Vector2.ZERO

static func components(mask: PackedByteArray,w: int,h: int) -> Array:
	var visited:=PackedByteArray();visited.resize(w*h)
	var found:=[]
	for start in range(w*h):
		if mask[start]==0 or visited[start]!=0:continue
		var queue:=PackedInt32Array([start]);visited[start]=1;var offset:=0
		while offset<queue.size():
			var at:=queue[offset];offset+=1
			var x:=at%w;var y:=int(at/w)
			for dy in [-1,0,1]:
				for dx in [-1,0,1]:
					var nx:int=x+dx;var ny:int=y+dy
					if nx<0 or nx>=w or ny<0 or ny>=h:continue
					var k:=ny*w+nx
					if mask[k]!=0 and visited[k]==0:visited[k]=1;queue.append(k)
		found.append(queue)
	return found

static func bounds(points: PackedInt32Array,w: int) -> Rect2i:
	var left:=w;var top:=100000;var right:=0;var bottom:=0
	for k in points:
		var x:=k%w;var y:=int(k/w)
		left=mini(left,x);top=mini(top,y);right=maxi(right,x+1);bottom=maxi(bottom,y+1)
	return Rect2i(left,top,right-left,bottom-top)

static func bake() -> SpriteBank:
	var bank:=SpriteBank.new()
	for source in [["res://assets/hero.png",8,7,"main"],["res://assets/crouch_v05.png",4,2,"crawl"],["res://assets/slide_v05.png",2,2,"slide"]]:
		var image:=Image.load_from_file(source[0]);image.convert(Image.FORMAT_RGBA8)
		var cols:int=source[1];var rows:int=source[2]
		for i in range(cols*rows):
			var col:=i%cols;var row:=int(i/cols)
			var x0:=roundi(col*image.get_width()/float(cols));var x1:=roundi((col+1)*image.get_width()/float(cols))
			var y0:=roundi(row*image.get_height()/float(rows));var y1:=roundi((row+1)*image.get_height()/float(rows))
			var frame:=image.get_region(Rect2i(x0,y0,x1-x0,y1-y0))
			var w:=frame.get_width();var h:=frame.get_height();var mask:=PackedByteArray();mask.resize(w*h)
			for y in range(h):
				for x in range(w):mask[y*w+x]=1 if frame.get_pixel(x,y).a>=0.88 else 0
			var parts:=components(mask,w,h);var biggest:=PackedInt32Array()
			for part in parts:
				if part.size()>biggest.size():biggest=part
			assert(not biggest.is_empty())
			var rect:=bounds(biggest,w)
			for part in parts:
				if part.size()!=biggest.size():bank.removed_pixels+=part.size()
			var clean:=Image.create(rect.size.x+4,rect.size.y+4,false,Image.FORMAT_RGBA8);clean.fill(Color.TRANSPARENT)
			var orange:=PackedByteArray();orange.resize(w*h)
			for k in biggest:
				var x:=k%w;var y:=int(k/w);var c:=frame.get_pixel(x,y)
				clean.set_pixel(x-rect.position.x+2,y-rect.position.y+2,Color(c.r,c.g,c.b,1))
				if c.r>0.35 and c.g>0.157 and c.r>c.g*1.15 and c.g>c.b*1.15:orange[k]=1
			var heads:=components(orange,w,h);var head:=PackedInt32Array()
			for part in heads:
				var b:=bounds(part,w)
				if b.end.x>w*0.5 and b.position.y<rect.position.y+rect.size.y*0.65 and part.size()>head.size():head=part
			assert(not head.is_empty())
			var head_box:=bounds(head,w)
			if bank.frames.is_empty():bank.head_size=Vector2(head_box.size)*(124.0/rect.size.y)
			var scaling:=bank.head_size/Vector2(head_box.size)
			var anchor_x:=head_box.get_center().x-rect.position.x+2.0
			bank.frames.append(ImageTexture.create_from_image(clean))
			bank.profiles.append({"group":source[3],"scale":scaling,"foot":rect.size.y+2.0,"anchor_x":anchor_x,"head":Rect2(head_box),"components":1,"source_frame":i,"visible_size":Vector2(rect.size)*scaling})
	return bank
