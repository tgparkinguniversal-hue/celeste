extends Node2D
class_name TestWorld2D
var platforms: Array[Rect2] = []
var props: Array[PhysicsProp]=[]
var lift: TestLift
var interactive:=false
var mouse_body: PhysicsProp
var mouse_local:=Vector2.ZERO
var pending_pick:=false
var request_point:=Vector2.ZERO
var tutorials_visible := true
var camera_x := 0.0
var ui_font := SystemFont.new()
var serif := SystemFont.new()
var small_font := SystemFont.new()

func _ready() -> void:
	ui_font.font_names=PackedStringArray(["Segoe UI","DejaVu Sans"])
	serif.font_names=PackedStringArray(["Georgia","DejaVu Serif"])
	serif.font_weight=700
	small_font.font_names=ui_font.font_names
	add_rect(-24,30,0,2.1)
	add_rect(9,8,0,2.1)
	add_rect(20,20,0,2.1)
	add_rect(-25,1,6,8)
	add_rect(73,1,6,8)
	add_rect(40,33,0,2.1)
	add_rect(-7,4,2.26,0.66)
	add_rect(0.3,1.4,0.4,0.4)
	add_rect(2.3,1.4,0.9,0.9)
	add_rect(9.8,2.4,1.2,1.2)
	add_rect(13.7,2.6,1.4,1.4)
	# Polygon-only ramp collision and matching 2D art, no 3D meshes.
	var ramp:=StaticBody2D.new()
	var collision:=CollisionPolygon2D.new()
	collision.polygon=PackedVector2Array([Vector2(21.5*72,0),Vector2(26.5*72,-1.294*72),Vector2(26.5*72,0)])
	ramp.add_child(collision)
	add_child(ramp)
	add_rect(26.5,3.2,1.294,1.294)
	add_rect(32.4,1.2,0.7,0.7)
	for i in range(4):add_rect(66+i*1.5,1.3,0.2+i*0.25,0.2+i*0.25)
	spawn_prop(Vector2(44*72,-35),Vector2(56,56),12,"crate")
	spawn_prop(Vector2(46*72,-35),Vector2(56,56),12,"crate")
	spawn_prop(Vector2(46*72,-100),Vector2(48,48),8,"crate")
	spawn_prop(Vector2(49*72,-35),Vector2(64,64),24,"crate")
	spawn_prop(Vector2(52*72,-80),Vector2(46,46),6,"ball")
	spawn_prop(Vector2(54*72,-140),Vector2(54,54),9,"ball")
	lift=TestLift.new();lift.position=Vector2(61*72,-110);add_child(lift)

func add_rect(x: float,w: float,height: float,depth: float) -> void:
	var rect:=Rect2(x*72,-height*72,w*72,depth*72)
	platforms.append(rect)
	var body:=StaticBody2D.new()
	body.position=rect.get_center()
	var collision:=CollisionShape2D.new()
	var shape:=RectangleShape2D.new()
	shape.size=rect.size
	collision.shape=shape
	body.add_child(collision)
	add_child(body)

func _draw() -> void:
	# Flat layered architecture provides depth through shading and small offsets.
	for rect in platforms:
		draw_colored_polygon(PackedVector2Array([rect.position,rect.position+Vector2(16,-10),rect.position+Vector2(rect.size.x+16,-10),rect.position+Vector2(rect.size.x,0)]),Color("879b9e"))
		draw_rect(rect,Color("52696f"))
		draw_colored_polygon(PackedVector2Array([rect.end,rect.end+Vector2(16,-10),rect.position+Vector2(rect.size.x+16,-10),rect.position+Vector2(rect.size.x,0)]),Color("3d555d"))
		draw_line(rect.position,rect.position+Vector2(rect.size.x,0),Color("b2c0bb"),2)
		draw_line(rect.position+Vector2(0,8),rect.position+Vector2(rect.size.x,8),Color(0.8,0.9,0.88,0.16),1)
		var start:=ceilf(rect.position.x/72)*72
		for x in range(int(start),int(rect.end.x),72):
			draw_line(Vector2(x,rect.position.y+15),Vector2(x,rect.end.y),Color(0.8,0.9,0.9,0.07),1)
		for y in range(int(rect.position.y+72),int(rect.end.y),72):
			draw_line(Vector2(rect.position.x,y),Vector2(rect.end.x,y),Color(0.8,0.9,0.9,0.07),1)
		for x in range(int(start),int(rect.end.x-35),144):
			for offset in [0,12,24]:
				draw_line(Vector2(x+offset,rect.position.y+10),Vector2(x+offset+6,rect.position.y+10),Color(0.9,0.9,0.85,0.35),2)
	var ramp:=PackedVector2Array([Vector2(21.5*72,0),Vector2(26.5*72,-1.294*72),Vector2(26.5*72,0)])
	draw_colored_polygon(ramp,Color("627b7f"))
	draw_line(ramp[0],ramp[1],Color("b2c0bb"),2)
	if tutorials_visible:
		card(Vector2(-16*72,-260),"01 · ENCONTRE SEU RITMO","Incline para andar. Explore a corrida.",[["stick","Mover"],["r2","Correr"]])
		card(Vector2(-5*72,-300),"02 · PASSAGEM FURTIVA","Abaixe-se e continue em movimento.",[["circle","Agachar"],["square","Deslizar"]])
		card(Vector2(11*72,-345),"03 · GANHE ALTURA","Toque para um salto curto; segure para ir além.",[["cross","Pular"]])
		card(Vector2(47*72,-300),"05 · OBJETOS COM PESO","Segure E / R1 para puxar. Use o mouse para arrastar.",[["r1","Segurar"],["mouse","Arrastar"]])
		card(Vector2(62*72,-345),"06 · EQUILÍBRIO E APOIO","Suba na plataforma móvel e teste os degraus.",[["cross","Pular"]])
		card(Vector2(27*72,-345),"04 · CONTINUE O CAMINHO","Experimente a rampa e as transições.",[["stick","Mover"],["cross","Pular"]])

func card(at: Vector2,title: String,description: String,icons: Array) -> void:
	var rect:=Rect2(at-Vector2(175,0),Vector2(350,112))
	var style:=StyleBoxFlat.new()
	style.bg_color=Color(0.06,0.14,0.17,0.94)
	style.border_color=Color(0.7,0.79,0.78,0.25)
	style.set_border_width_all(1)
	style.set_corner_radius_all(14)
	draw_style_box(style,rect)
	draw_string(ui_font,rect.position+Vector2(18,26),title,HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("e4c8a7"))
	draw_string(ui_font,rect.position+Vector2(18,49),description,HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color("b8c7c8"))
	for i in range(icons.size()):
		var p:=rect.position+Vector2(32+i*155,82)
		LumeGlyph.paint(self,icons[i][0],p,13,Color("e8e3d9"))
		draw_string(ui_font,p+Vector2(26,5),icons[i][1],HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("e8e3d9"))

func spawn_prop(at: Vector2,size: Vector2,weight: float,type: String) -> PhysicsProp:
	var prop:=PhysicsProp.new();prop.position=at;prop.dimensions=size;prop.mass=weight;prop.kind=type;prop.label="%.0f kg"%weight
	add_child(prop);props.append(prop);return prop

func set_active(value: bool) -> void:
	interactive=value
	if not value:mouse_body=null;pending_pick=false
	for prop in props:prop.set_paused(not value)
	if is_instance_valid(lift):lift.active=value

func reset_props() -> void:
	mouse_body=null
	for prop in props:prop.reset_body()
	if is_instance_valid(lift):lift.clock=0;lift.position=lift.origin

func _unhandled_input(event: InputEvent) -> void:
	if not interactive:return
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
		if event.pressed:request_point=get_global_mouse_position();pending_pick=true
		else:mouse_body=null;pending_pick=false

func _physics_process(_dt: float) -> void:
	if not interactive:return
	if pending_pick:
		pending_pick=false
		var q:=PhysicsPointQueryParameters2D.new();q.position=request_point;q.collision_mask=2
		var hits:=get_world_2d().direct_space_state.intersect_point(q,1)
		if not hits.is_empty() and hits[0].collider is PhysicsProp:
			mouse_body=hits[0].collider;mouse_local=mouse_body.to_local(request_point)
	if is_instance_valid(mouse_body):
		var point:=mouse_body.to_global(mouse_local)
		var error:=get_global_mouse_position()-point
		var force:=error*mouse_body.mass*80-mouse_body.linear_velocity*mouse_body.mass*17
		if force.length()>90000:force=force.normalized()*90000
		mouse_body.apply_force(force,point-mouse_body.global_position)
