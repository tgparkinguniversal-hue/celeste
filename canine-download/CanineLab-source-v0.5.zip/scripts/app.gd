extends Node2D
var player: Hero2D
var world: TestWorld2D
var camera: Camera2D
var backdrop
var ui: Control
var title_menu: Control
var pause_menu: Control
var options_menu: Control
var controls: ControlsCard
var fps_panel: PanelContainer
var fps: Label
var render_host: Node
var quality_choice: OptionButton
var mode := "title"
var return_mode := "title"
var elapsed := 0.0
var frame_count := 0
var show_fps := true
var tutorials_enabled := true
var full_screen_check: CheckButton
var fps_check: CheckButton
var first_title: Button
var first_pause: Button
var pause_hint: Label

func _ready() -> void:
	Engine.max_fps=0
	OS.low_processor_usage_mode=false
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	configure_input()
	var background_layer:=CanvasLayer.new()
	background_layer.layer=-20
	add_child(background_layer)
	backdrop=load("res://scripts/backdrop.gd").new()
	background_layer.add_child(backdrop)
	world=TestWorld2D.new()
	add_child(world)
	player=Hero2D.new()
	add_child(player)
	camera=Camera2D.new()
	camera.position=player.position+Vector2(260,-260)
	add_child(camera)
	camera.make_current()
	build_interface()
	set_mode("title")

func bind(action: String,keys: Array,buttons: Array,axis: int=-1,value:=0.0) -> void:
	if InputMap.has_action(action):InputMap.erase_action(action)
	InputMap.add_action(action,0.2)
	for key in keys:
		var e:=InputEventKey.new();e.physical_keycode=key;InputMap.action_add_event(action,e)
	for button in buttons:
		var e:=InputEventJoypadButton.new();e.button_index=button;InputMap.action_add_event(action,e)
	if axis>=0:
		var e:=InputEventJoypadMotion.new();e.axis=axis;e.axis_value=value;InputMap.action_add_event(action,e)
func configure_input() -> void:
	bind("left",[KEY_A,KEY_LEFT],[JOY_BUTTON_DPAD_LEFT],JOY_AXIS_LEFT_X,-1)
	bind("right",[KEY_D,KEY_RIGHT],[JOY_BUTTON_DPAD_RIGHT],JOY_AXIS_LEFT_X,1)
	bind("run",[KEY_SHIFT],[JOY_BUTTON_LEFT_STICK],JOY_AXIS_TRIGGER_RIGHT,1)
	bind("jump",[KEY_SPACE,KEY_W,KEY_UP],[JOY_BUTTON_A])
	bind("crouch",[KEY_CTRL,KEY_S,KEY_DOWN],[JOY_BUTTON_B])
	bind("slide",[KEY_C],[JOY_BUTTON_X])
	bind("grab",[KEY_E],[JOY_BUTTON_RIGHT_SHOULDER])
	bind("pause",[KEY_ESCAPE],[JOY_BUTTON_START])
	bind("controls",[KEY_F2],[JOY_BUTTON_TOUCHPAD])
	bind("reset",[KEY_R],[JOY_BUTTON_BACK])
	bind("help",[KEY_TAB,KEY_F1],[JOY_BUTTON_Y])

func column(parent: Control,at: Vector2,size: Vector2,separation:=10) -> VBoxContainer:
	var col:=VBoxContainer.new()
	col.position=at;col.size=size
	col.add_theme_constant_override("separation",separation)
	parent.add_child(col)
	return col
func spacer(col: VBoxContainer,height: float) -> void:
	var c:=Control.new();c.custom_minimum_size.y=height;col.add_child(c)
func open_controls() -> void:
	return_mode=mode
	set_mode("controls")
	controls.close_button.grab_focus()
func open_options() -> void:
	return_mode=mode
	set_mode("options")
func back() -> void:
	set_mode(return_mode)
func play() -> void:
	set_mode("game")
func restart() -> void:
	player.reset();world.reset_props();set_mode("game")
func home() -> void:
	player.reset();world.reset_props();set_mode("title")

func build_interface() -> void:
	var layer:=CanvasLayer.new();layer.layer=10;add_child(layer)
	ui=Control.new();ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui.theme=SoftUI.theme();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;layer.add_child(ui)
	title_menu=Control.new();title_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui.add_child(title_menu)
	var intro:=column(title_menu,Vector2(790,140),Vector2(400,460),6)
	intro.add_child(SoftUI.label("UMA AVENTURA EM PIXELS  ·  PC 0.5",11))
	spacer(intro,14)
	intro.add_child(SoftUI.label("CANINE",60,true,true))
	intro.add_child(SoftUI.label("Laboratório de Movimento",19,true,true))
	spacer(intro,28)
	intro.add_child(SoftUI.label("Uma aventura em pixels.\nUm espaço para encontrar seu ritmo.",15))
	spacer(intro,20)
	first_title=SoftUI.button("Entrar no laboratório  →",play,true);intro.add_child(first_title)
	intro.add_child(SoftUI.button("Controles",open_controls))
	intro.add_child(SoftUI.button("Opções",open_options))
	intro.add_child(SoftUI.button("Sair do aplicativo",func():get_tree().quit()))
	spacer(intro,53)
	intro.add_child(SoftUI.label("TECLADO + DUALSENSE · CENÁRIO 2D EM CAMADAS",10))
	intro.add_child(SoftUI.label("Conecte o controle e pressione × para entrar.",10))
	var title_cards: Control=load("res://scripts/title_cards.gd").new();title_menu.add_child(title_cards)
	pause_menu=Control.new();pause_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui.add_child(pause_menu)
	var dim:=ColorRect.new();dim.color=Color(0.02,0.05,0.07,0.45);dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);pause_menu.add_child(dim)
	var panel:=PanelContainer.new();panel.position=Vector2(370,95);panel.size=Vector2(540,535);pause_menu.add_child(panel)
	var pc:=VBoxContainer.new();pc.add_theme_constant_override("separation",7);panel.add_child(pc)
	pc.add_child(SoftUI.label("UMA PAUSA NO CAMINHO",11));spacer(pc,15)
	pc.add_child(SoftUI.label("Vamos de novo?",38,true,true));spacer(pc,24)
	first_pause=SoftUI.button("Continuar",play);pc.add_child(first_pause)
	pc.add_child(SoftUI.button("Controles",open_controls))
	pc.add_child(SoftUI.button("Opções",open_options))
	pc.add_child(SoftUI.button("Voltar ao início do mapa",restart))
	pc.add_child(SoftUI.button("Menu inicial",home))
	pause_hint=SoftUI.label("Esc / Options para continuar",11);pc.add_child(pause_hint)
	options_menu=Control.new();options_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui.add_child(options_menu)
	var op:=PanelContainer.new();op.position=Vector2(370,110);op.size=Vector2(540,500);options_menu.add_child(op)
	var oc:=VBoxContainer.new();oc.add_theme_constant_override("separation",18);op.add_child(oc)
	oc.add_child(SoftUI.label("DO SEU JEITO",11));oc.add_child(SoftUI.label("Opções",36,true,true))
	fps_check=CheckButton.new();fps_check.text="Mostrar FPS e tempo por quadro";fps_check.button_pressed=true;fps_check.toggled.connect(func(v):show_fps=v;fps_panel.visible=v);oc.add_child(fps_check)
	full_screen_check=CheckButton.new();var full:=full_screen_check;full.text="Tela cheia";full.toggled.connect(func(v):DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if v else DisplayServer.WINDOW_MODE_WINDOWED);DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED));oc.add_child(full)
	oc.add_child(SoftUI.label("Qualidade de renderização",14,false))
	quality_choice=OptionButton.new()
	quality_choice.add_item("Full HD · 1920 × 1080",0)
	quality_choice.add_item("2K / QHD · 2560 × 1440",1)
	quality_choice.item_selected.connect(func(index):
		if is_instance_valid(render_host):render_host.set_quality(index))
	oc.add_child(quality_choice)
	oc.add_child(SoftUI.label("Resolução interna real · proporção 16:9 · FPS livre",12))
	oc.add_child(SoftUI.button("Voltar",back,true))
	controls=ControlsCard.new();controls.closed.connect(back);ui.add_child(controls)
	var fps_layer:=CanvasLayer.new();fps_layer.layer=40;add_child(fps_layer)
	fps_panel=PanelContainer.new();fps_panel.position=Vector2(24,22);fps_panel.size=Vector2(216,48);fps_panel.theme=ui.theme
	var style:=SoftUI.panel();style.set_corner_radius_all(17);style.content_margin_top=9;style.content_margin_bottom=9;style.content_margin_left=15;style.content_margin_right=15;style.shadow_size=0;fps_panel.add_theme_stylebox_override("panel",style)
	fps=SoftUI.label("FPS  —",14,false);fps_panel.add_child(fps);fps_layer.add_child(fps_panel)
	var help:=SoftUI.label("Esc / Options  pausa     F2 / touchpad  controles     R / Create  reiniciar     E / R1  segurar objeto",12,false)
	help.position=Vector2(28,682);help.modulate=Color("a5bdbd");ui.add_child(help);help.name="Shortcuts"

func set_mode(value: String) -> void:
	if value=="game" and mode!="game":player.input_grace=0.12
	mode=value
	title_menu.visible=mode=="title"
	pause_menu.visible=mode=="pause"
	options_menu.visible=mode=="options"
	controls.visible=mode=="controls"
	player.locked=mode!="game"
	if mode!="game":player.grabbed=null
	world.set_active(mode=="game")
	player.set_physics_process(mode in ["title","game"])
	player.set_process(mode in ["title","game"])
	world.tutorials_visible=tutorials_enabled and mode!="title" and not(mode in ["controls","options"] and return_mode=="title")
	world.queue_redraw()
	ui.get_node("Shortcuts").visible=mode=="game"
	if mode=="options":
		full_screen_check.set_pressed_no_signal(DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN)
		fps_check.grab_focus()
	if mode=="title":first_title.grab_focus()
	if mode=="pause":first_pause.grab_focus()
	if mode=="game":get_viewport().gui_release_focus()

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT and is_instance_valid(player) and mode=="game":set_mode("pause")
func _process(dt: float) -> void:
	elapsed+=dt;frame_count+=1
	if elapsed>=0.25:
		fps.text="%d FPS   ·   %.2f ms"%[roundi(frame_count/elapsed),elapsed/frame_count*1000]
		elapsed=0;frame_count=0
	if Input.is_action_just_pressed("pause"):
		if mode in ["controls","options"]:back()
		elif mode=="game":set_mode("pause")
		elif mode=="pause":play()
	if Input.is_action_just_pressed("controls"):
		if mode=="controls":back()
		else:open_controls()
	if mode=="game" and Input.is_action_just_pressed("reset"):player.reset();world.reset_props()
	if mode=="game" and Input.is_action_just_pressed("help"):
		tutorials_enabled=not tutorials_enabled
		world.tutorials_visible=tutorials_enabled
		world.queue_redraw()
	if Input.is_physical_key_pressed(KEY_F11) and not get_meta("f11",false):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN);DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	set_meta("f11",Input.is_physical_key_pressed(KEY_F11))
	if mode in ["game","title"]:
		var look:=260.0 if mode=="title" else clampf(player.velocity.x*0.18,-95,95)
		var target:=player.position+Vector2(look,-260 if mode=="title" else -170)
		camera.position=camera.position.lerp(target,1-exp(-dt*5.2))
		backdrop.scroll=camera.position.x
		backdrop.queue_redraw()
