extends Control
var render_view: SubViewport
var container: SubViewportContainer
var game
var target_size:=Vector2i(1920,1080)
func _ready() -> void:
	container=SubViewportContainer.new()
	container.stretch=false
	container.focus_mode=Control.FOCUS_ALL
	container.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	add_child(container)
	render_view=SubViewport.new()
	render_view.name="GameRender"
	render_view.gui_embed_subwindows=true
	render_view.size=target_size
	render_view.size_2d_override=Vector2i(1280,720)
	render_view.size_2d_override_stretch=true
	render_view.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	container.add_child(render_view)
	game=load("res://main.tscn").instantiate()
	game.render_host=self
	render_view.add_child(game)
	get_viewport().size_changed.connect(layout_render)
	layout_render()
	container.grab_focus()
func set_quality(index: int) -> void:
	target_size=Vector2i(1920,1080) if index==0 else Vector2i(2560,1440)
	render_view.size=target_size
	if is_instance_valid(game):game.quality_choice.select(index)
	layout_render()
func layout_render() -> void:
	var available:=get_viewport_rect().size
	var ratio:=minf(available.x/target_size.x,available.y/target_size.y)
	container.size=Vector2(target_size)
	container.scale=Vector2.ONE*ratio
	container.position=(available-Vector2(target_size)*ratio)/2
