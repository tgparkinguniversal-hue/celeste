extends RefCounted
class_name SoftUI
static func sans() -> SystemFont:
	var f:=SystemFont.new()
	f.font_names=PackedStringArray(["Inter","Segoe UI","DejaVu Sans"])
	return f
static func serif() -> SystemFont:
	var f:=SystemFont.new()
	f.font_names=PackedStringArray(["Georgia","DejaVu Serif","Liberation Serif"])
	f.font_weight=700
	return f
static func panel() -> StyleBoxFlat:
	var s:=StyleBoxFlat.new()
	s.bg_color=Color(0.11,0.18,0.21,0.97)
	s.border_color=Color(0.72,0.81,0.79,0.4)
	s.set_border_width_all(1)
	s.set_corner_radius_all(28)
	s.content_margin_left=32
	s.content_margin_right=32
	s.content_margin_top=28
	s.content_margin_bottom=28
	s.shadow_color=Color(0.01,0.04,0.05,0.25)
	s.shadow_size=18
	return s
static func button_style(color: Color) -> StyleBoxFlat:
	var s:=StyleBoxFlat.new()
	s.bg_color=color
	s.set_corner_radius_all(24)
	s.content_margin_left=22
	s.content_margin_right=22
	s.content_margin_top=12
	s.content_margin_bottom=12
	return s
static func theme() -> Theme:
	var t:=Theme.new()
	t.default_font=sans()
	t.default_font_size=16
	t.set_stylebox("panel","PanelContainer",panel())
	t.set_stylebox("normal","Button",button_style(Color(0,0,0,0)))
	t.set_stylebox("hover","Button",button_style(Color("f2c8a4")))
	t.set_stylebox("focus","Button",button_style(Color("f2c8a4")))
	t.set_stylebox("pressed","Button",button_style(Color("dfb28c")))
	t.set_color("font_color","Button",Color("eee6d7"))
	t.set_color("font_hover_color","Button",Color("443e39"))
	t.set_color("font_focus_color","Button",Color("443e39"))
	t.set_color("font_pressed_color","Button",Color("443e39"))
	t.set_color("font_color","Label",Color("eee6d7"))
	t.set_constant("outline_size","Label",0)
	return t
static func label(text: String,size:=16,center:=true,heading:=false) -> Label:
	var l:=Label.new()
	l.text=text
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_font_override("font",serif() if heading else sans())
	if center:l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	return l
static func button(text: String,callback: Callable,primary:=false) -> Button:
	var b:=Button.new()
	b.text=text
	b.custom_minimum_size=Vector2(320,46)
	b.pressed.connect(callback)
	if primary:
		b.add_theme_stylebox_override("normal",button_style(Color("f2c8a4")))
		b.add_theme_color_override("font_color",Color("443e39"))
	return b
