extends AnimatableBody2D
class_name TestLift
var origin:=Vector2.ZERO
var clock:=0.0
var active:=true
func _ready() -> void:
	origin=position
	sync_to_physics=true
	var shape:=RectangleShape2D.new();shape.size=Vector2(156,18)
	var collider:=CollisionShape2D.new();collider.shape=shape;add_child(collider)
func _physics_process(dt: float) -> void:
	if not active:return
	clock+=dt
	position=origin+Vector2(sin(clock*0.8)*100,0)
func _draw() -> void:
	draw_rect(Rect2(-78,-9,156,18),Color("9cafad"))
	for x in range(-70,72,20):draw_line(Vector2(x,-4),Vector2(x+8,4),Color("4e686e"),3)
