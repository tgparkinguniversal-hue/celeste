extends RigidBody2D
class_name PhysicsProp
var kind := "crate"
var dimensions := Vector2(56,56)
var start_position := Vector2.ZERO
var label := "12 kg"
var paused := false
var pending_reset := false
var saved_velocity := Vector2.ZERO
var saved_spin := 0.0
func _ready() -> void:
	add_to_group("draggable")
	collision_layer=2;collision_mask=7
	gravity_scale=1728.0/980.0
	linear_damp=0.12;angular_damp=1.0
	continuous_cd=RigidBody2D.CCD_MODE_CAST_SHAPE
	var mat:=PhysicsMaterial.new();mat.friction=0.65;mat.bounce=0.08 if kind=="crate" else 0.45;physics_material_override=mat
	var collider:=CollisionShape2D.new()
	if kind=="ball":
		var shape:=CircleShape2D.new();shape.radius=dimensions.x/2;collider.shape=shape
	else:
		var shape:=RectangleShape2D.new();shape.size=dimensions;collider.shape=shape
	add_child(collider)
	start_position=position
	z_index=5
func set_paused(value: bool) -> void:
	if value==paused:return
	paused=value
	if value:
		saved_velocity=linear_velocity;saved_spin=angular_velocity;freeze=true
	else:
		freeze=false;linear_velocity=saved_velocity;angular_velocity=saved_spin
func reset_body() -> void:
	pending_reset=true
	freeze=true;position=start_position;rotation=0;linear_velocity=Vector2.ZERO;angular_velocity=0;saved_velocity=Vector2.ZERO;saved_spin=0
	freeze=paused
func _physics_process(_dt: float) -> void:
	if position.y>750:reset_body()
	if linear_velocity.length()>1400:linear_velocity=linear_velocity.normalized()*1400
func _draw() -> void:
	if kind=="ball":
		draw_circle(Vector2.ZERO,dimensions.x/2,Color("c29d78"));draw_arc(Vector2.ZERO,dimensions.x/2-2,0,TAU,36,Color("ebcfaa"),2,true)
		draw_line(Vector2(-dimensions.x/2,0),Vector2(dimensions.x/2,0),Color("795f4c"),3)
		draw_line(Vector2(0,-dimensions.x/2),Vector2(0,dimensions.x/2),Color("795f4c"),3)
	else:
		var rect:=Rect2(-dimensions/2,dimensions)
		draw_rect(rect,Color("8c735c"));draw_rect(rect.grow(-3),Color("c3a680"),false,3)
		draw_line(rect.position+Vector2(7,7),rect.end-Vector2(7,7),Color("5e5349"),5)
		draw_line(Vector2(rect.end.x-7,rect.position.y+7),Vector2(rect.position.x+7,rect.end.y-7),Color("5e5349"),5)
		draw_rect(Rect2(Vector2(-12,-8),Vector2(24,16)),Color("e1c5a0"))

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
	if pending_reset:
		state.transform=Transform2D(0,start_position)
		state.linear_velocity=Vector2.ZERO;state.angular_velocity=0
		pending_reset=false
