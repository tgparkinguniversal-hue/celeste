extends Control
var font:=SoftUI.sans()
func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
func _draw() -> void:
	var style:=SoftUI.panel();style.set_corner_radius_all(16);style.content_margin_top=12
	draw_style_box(style,Rect2(172,306,360,120))
	draw_string(font,Vector2(192,332),"ENCONTRE SEU RITMO",HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("f0d0ae"))
	for item in [["A",Vector2(204,359)],["D",Vector2(244,359)],["SHIFT",Vector2(224,397)]]:
		var pos: Vector2=item[1];var text: String=item[0]
		var rect:=Rect2(pos-Vector2(23,16),Vector2(46 if text=="SHIFT" else 32,28))
		var key:=SoftUI.button_style(Color(0,0,0,0));key.border_color=Color("e5e0d3");key.set_border_width_all(2);key.set_corner_radius_all(6)
		draw_style_box(key,rect)
		draw_string(font,rect.position+Vector2(5,19),text,HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color("eee6d7"))
	draw_string(font,Vector2(295,365),"Andar",HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("eee6d7"))
	draw_string(font,Vector2(295,403),"Correr",HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("eee6d7"))
	draw_style_box(style,Rect2(565,335,175,92))
	draw_string(font,Vector2(580,359),"PASSAGEM FURTIVA",HORIZONTAL_ALIGNMENT_LEFT,-1,10,Color("f0d0ae"))
	LumeGlyph.paint(self,"circle",Vector2(590,391),12,Color("eee6d7"))
	draw_string(font,Vector2(610,395),"Abaixe e caminhe",HORIZONTAL_ALIGNMENT_LEFT,-1,10,Color("bccbca"))
