extends Node2D
var scroll := 0.0
func _draw() -> void:
	# Screen-space parallax layers, all 2D. Gradual tones replace a 3D room.
	for i in range(24):
		var t:=i/23.0
		draw_rect(Rect2(0,i*30,1280,31),Color("29474d").lerp(Color("142e36"),t))
	for i in range(-1,10):
		var x:=i*190-fposmod(scroll*0.10,190)
		draw_rect(Rect2(x,80,130,530),Color(0.28,0.44,0.46,0.08))
		draw_line(Vector2(x,0),Vector2(x,720),Color(0.75,0.85,0.83,0.05),1)
	for i in range(-1,18):
		var x:=i*95-fposmod(scroll*0.23,95)
		draw_line(Vector2(x,280),Vector2(x,650),Color(0.7,0.82,0.8,0.05),1)
	for y in range(120,720,95):draw_line(Vector2(0,y),Vector2(1280,y),Color(0.7,0.82,0.8,0.045),1)
