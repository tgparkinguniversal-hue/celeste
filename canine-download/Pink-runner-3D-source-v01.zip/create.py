import bpy, math, json, os
from mathutils import Vector, Matrix
from pathlib import Path
OUT=Path('/tmp/pink3d')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.render.engine='BLENDER_WORKBENCH'
scene.display.shading.light='FLAT';scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=False;scene.display.shading.show_specular_highlight=False;scene.display.shading.show_object_outline=False
scene.display.shading.background_type='VIEWPORT';scene.display.shading.background_color=(0.174,0.223,0.31)
scene.display.render_aa='OFF'
scene.render.resolution_x=256;scene.render.resolution_y=160;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.render.fps=60;scene.frame_start=1;scene.frame_end=36
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast' if False else 'None'
scene.view_settings.exposure=0;scene.view_settings.gamma=1
if hasattr(scene.eevee,'taa_render_samples'):scene.eevee.taa_render_samples=1
scene.render.image_settings.color_mode='RGBA'
def linear(c):return c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4
def rgb(h):return tuple(linear(int(h[i:i+2],16)/255) for i in (0,2,4))
def material(name,h):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb(h),1);m.use_nodes=True;n=m.node_tree.nodes;n.clear();em=n.new('ShaderNodeEmission');em.inputs['Color'].default_value=(*rgb(h),1);out=n.new('ShaderNodeOutputMaterial');m.node_tree.links.new(em.outputs[0],out.inputs[0]);return m
colors={'skin':'ffe1d5','skin_dark':'e7b9b4','hair':'f5bdcc','hair_light':'ffdae2','hair_dark':'d894b1','coat':'a17bbe','coat_light':'bb99d0','coat_dark':'725a91','inner':'574c70','shorts':'e1f0ef','shorts_dark':'b3d0d4','boots':'344145','boots_dark':'253135','eye':'523c4b'}
mats={k:material(k,v) for k,v in colors.items()}
world=bpy.data.worlds.new('Slate background');scene.world=world;world.use_nodes=True;world.color=rgb('748297')
world.node_tree.nodes['Background'].inputs[0].default_value=(*rgb('748297'),1);world.node_tree.nodes['Background'].inputs[1].default_value=1
# Real armature: each rigid part has one fixed-length deform bone.
armdata=bpy.data.armatures.new('RunnerRig');arm=bpy.data.objects.new('RunnerRig',armdata);scene.collection.objects.link(arm)
bpy.context.view_layer.objects.active=arm;arm.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
lengths={'pelvis':.2,'spine':.45,'head':.34}
for side in ['near','far']:
 lengths.update({f'thigh_{side}':.42,f'shin_{side}':.43,f'foot_{side}':.21,f'arm_{side}':.24,f'forearm_{side}':.23,f'hand_{side}':.08})
for name,L in lengths.items():
 b=armdata.edit_bones.new(name);b.head=(0,0,0);b.tail=(0,0,L)
bpy.ops.object.mode_set(mode='OBJECT');arm.show_in_front=True
for p in arm.pose.bones:p.rotation_mode='QUATERNION'
def bind(obj,bone):
 vg=obj.vertex_groups.new(name=bone);vg.add(list(range(len(obj.data.vertices))),1,'REPLACE')
 mod=obj.modifiers.new('Rigid skeletal skin','ARMATURE');mod.object=arm
 return obj
def shade(obj,base,light=None,dark=None):
 for key in [base,light or base,dark or base]:obj.data.materials.append(mats[key])
 for p in obj.data.polygons:
  score=p.normal.dot(Vector((-.3,-.5,.8)).normalized());p.material_index=1 if score>.45 else (2 if score<-.1 else 0)
 return obj
def sphere(name,center,scale,color,bone=None,light=None,dark=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=10,ring_count=6,location=center)
 ob=bpy.context.object;ob.name=name;ob.scale=scale;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 shade(ob,color,light,dark)
 return bind(ob,bone) if bone else ob
def box(name,center,size,color,bone=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);ob=bpy.context.object;ob.name=name;ob.scale=size;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);shade(ob,color)
 return bind(ob,bone) if bone else ob
def mesh(name,verts,faces,color,bone=None,light=None,dark=None):
 data=bpy.data.meshes.new(name);data.from_pydata(verts,[],faces);data.update();ob=bpy.data.objects.new(name,data);scene.collection.objects.link(ob);shade(ob,color,light,dark)
 return bind(ob,bone) if bone else ob
def tube(name,z0,z1,r0,r1,color,bone,light=None,dark=None):
 verts=[]
 for z,r in [(z0,r0),(z1,r1)]:
  for k in range(8):
   a=k*math.tau/8;verts.append((math.cos(a)*r,math.sin(a)*r,z))
 faces=[tuple(range(7,-1,-1)),tuple(range(8,16))]+[(k,(k+1)%8,(k+1)%8+8,k+8) for k in range(8)]
 return mesh(name,verts,faces,color,bone,light,dark)
# Compact outfit and long black boots.
sphere('Light shorts',(0,0,-.025),(.14,.175,.105),'shorts','pelvis','shorts','shorts_dark')
sphere('Purple coat torso',(0,0,.22),(.135,.175,.245),'coat','spine','coat_light','coat_dark')
tube('High collar',.395,.45,.085,.08,'coat_dark','spine')
for side in ['near','far']:
 tube('Skin thigh '+side,0,.42,.069,.058,'skin',f'thigh_{side}','skin','skin_dark')
 tube('Short cuff '+side,0,.095,.077,.073,'shorts',f'thigh_{side}','shorts','shorts_dark')
 tube('High boot upper '+side,.18,.435,.069,.061,'boots',f'thigh_{side}','boots','boots_dark')
 sphere('Boot knee '+side,(0,0,0),(.064,.064,.065),'boots',f'shin_{side}','boots','boots_dark')
 tube('Boot calf '+side,0,.43,.065,.043,'boots',f'shin_{side}','boots','boots_dark')
 box('Boot sole '+side,(.055,0,-.025),(.18,.105,.065),'boots',f'foot_{side}')
 sphere('Boot toe '+side,(.10,0,-.008),(.05,.055,.045),'boots',f'foot_{side}','boots','boots_dark')
 tube('Coat sleeve '+side,0,.245,.075,.061,'coat',f'arm_{side}','coat_light','coat_dark')
 sphere('Elbow '+side,(0,0,0),(.063,.064,.061),'coat',f'forearm_{side}','coat','coat_dark')
 tube('Dark fore sleeve '+side,0,.23,.062,.044,'inner',f'forearm_{side}')
 sphere('Hand '+side,(0,0,.025),(.044,.04,.06),'skin',f'hand_{side}','skin','skin_dark')
# Head and hair are stable 3D meshes, shared by every frame.
sphere('Face',(.05,0,.13),(.135,.112,.151),'skin','head','skin','skin_dark')
sphere('Nose',(.177,-.018,.13),(.036,.042,.032),'skin','head')
sphere('Pink bob',(-.035,.005,.205),(.174,.132,.173),'hair','head','hair_light','hair_dark')
for y in [-.132,.132]:
 verts=[(-.15,y,.28),(-.06,y,.355),(.06,y,.33),(.15,y,.255),(.14,y,.17),(.08,y,.225),(.035,y,.155),(-.02,y,.22),(-.085,y,.14)]
 mesh('Hair fringe',verts,[tuple(range(len(verts)))],'hair','head','hair_light','hair_dark')
 verts=[(-.075,y,.24),(.012,y,.205),(.028,y,.10),(.09,y,-.045),(.005,y,.015),(-.07,y,.10)]
 mesh('Side hair lock',verts,[tuple(range(len(verts)))],'hair_light','head')
# Visible cheek patch follows the same head bone; bangs stay behind the face.
mesh('Near face plane',[(.025,-.145,.17),(.06,-.145,.24),(.135,-.145,.21),(.18,-.14,.15),(.14,-.145,.085),(.065,-.145,.065),(.025,-.145,.10)],[tuple(range(7))],'skin','head')
# Small side eye, not oversized facial detail.
box('Eye',(.12,-.152,.17),(.032,.008,.022),'eye','head')
# A shallow cheek patch preserves a readable face at sprite resolution.
sphere('Visible cheek',(.105,-.161,.145),(.082,.016,.093),'skin','head')
box('Visible eye',(.13,-.184,.17),(.036,.008,.025),'eye','head')
# Cloth meshes use continuous vertex animation and phase-lagged waves.
cloths=[]
for side in [-1,1]:
 verts=[]
 for k in range(5):
  t=k/4;verts.extend([(-.05-.65*t,side*.14,.88+.08*(1-.3*t)),(-.05-.65*t,side*.14,.88-.08*(1-.3*t))])
 ob=mesh('Coat tail '+str(side),verts,[(2*k,2*k+1,2*k+3,2*k+2) for k in range(4)],'coat',None,'coat_light','coat_dark');cloths.append((ob,side))
# Ponytail is a continuous tapered tube, attached to the same head point.
ponyverts=[]
for k in range(5):
 for j in range(6):ponyverts.append((0,0,0))
ponyfaces=[]
for k in range(4):
 for j in range(6):ponyfaces.append((k*6+j,k*6+(j+1)%6,(k+1)*6+(j+1)%6,(k+1)*6+j))
ponyfaces.append(tuple(range(24,30)))
pony=mesh('Trailing pink hair',ponyverts,ponyfaces,'hair',None,'hair_light','hair_dark')
# Fixed side camera, mild elevation only; no perspective size changes.
bpy.ops.object.camera_add(location=(.45,-8,1.45));camera=bpy.context.object;camera.name='Pixel orthographic camera'
target=Vector((.05,0,.82));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=4.8;scene.camera=camera
max_bone_error=0.0
rest={name:armdata.bones[name].matrix_local.to_3x3().to_4x4() for name in lengths}
def pose(name,start,direction):
 p=arm.pose.bones[name];d=Vector(direction).normalized();x=Vector((0,1,0)).cross(d).normalized();y=d.cross(x).normalized();rotation=Matrix((x,y,d)).transposed().to_4x4();m=Matrix.Translation(Vector(start))@rotation@rest[name]
 p.matrix=m
 for prop in ['location','rotation_quaternion','scale']:p.keyframe_insert(data_path=prop,frame=scene.frame_current)
def transform(p,origin,rot):return Vector(origin)+rot@Vector(p)
def footpath(t):
 if t<.28:return .30-.70*(t/.28),.04,0
 u=(t-.28)/.72;ease=u*u*(3-2*u)
 return -.40+.70*ease,.04+.44*math.sin(math.pi*u),.35*math.sin(math.pi*u)
for frame in range(1,38):
 scene.frame_set(frame);phi=(frame-1)/36*math.tau
 hip=Vector((.0,0,.76+.018*math.cos(phi*2)))
 lean=.82+.025*math.sin(phi*2);R=Matrix.Rotation(lean,3,'Y')
 pose('pelvis',hip,Vector((0,0,1)))
 pose('spine',hip,R@Vector((0,0,1)))
 neck=transform((0,0,.44),hip,R)
 headR=Matrix.Rotation(.16+.02*math.sin(phi),3,'Y')
 pose('head',neck,headR@Vector((0,0,1)))
 for idx,side in enumerate(['near','far']):
  yy=-.10 if idx==0 else .10
  t=((frame-1)/36+idx*.5)%1
  fx,fz,roll=footpath(t);h=hip+Vector((0,yy,0));f=Vector((fx,yy,fz))
  delta=f-h;dx,dz=delta.x,delta.z;distance=min(.42+.43-.0001,math.hypot(dx,dz))
  theta=math.atan2(dz,dx)+math.acos(max(-1,min(1,(.42**2+distance**2-.43**2)/(2*.42*distance))))
  knee=h+Vector((.42*math.cos(theta),0,.42*math.sin(theta)))
  pose('thigh_'+side,h,knee-h);pose('shin_'+side,knee,f-knee)
  footR=Matrix.Rotation(roll,3,'Y');pose('foot_'+side,f,footR@Vector((0,0,1)))
  max_bone_error=max(max_bone_error,abs((knee-h).length-.42),abs((f-knee).length-.43))
  shoulder=transform((0,-.16 if idx==0 else .16,.38),hip,R)
  c=math.cos(phi+idx*math.pi)
  hand_delta=Vector((.015-.18*c,0,.18+.12*c))
  wrist=shoulder+hand_delta
  d=hand_delta.length;axis=hand_delta.normalized()
  along=(.24**2-.23**2+d*d)/(2*d);radius=math.sqrt(max(0,.24**2-along**2))
  hint=Vector((-.25*c,-.09 if idx==0 else .09,-.08))
  bend=(hint-axis*hint.dot(axis)).normalized()
  elbow=shoulder+axis*along+bend*radius
  pose('arm_'+side,shoulder,elbow-shoulder);pose('forearm_'+side,elbow,wrist-elbow);pose('hand_'+side,wrist,wrist-elbow)
 for ob,side in cloths:
  for k in range(5):
   t=k/4;wave=(.045*math.sin(phi*2-3*t)+.018*math.sin(phi-5*t))*t
   center=hip+Vector((-.045-.70*t,side*(.125+.02*t),.07+wave))
   for edge in range(2):
    v=ob.data.vertices[k*2+edge];v.co=center+Vector((0,0,(1 if edge==0 else -1)*(.10-.085*t)))
    v.keyframe_insert('co',frame=frame)
 tailroot=transform((-.17,0,.17),neck,headR)
 for k in range(5):
  t=k/4;center=tailroot+Vector((-.36*t,.02*math.sin(phi-3*t),-.12*t+.055*math.sin(phi*2-3*t)*t))
  radius=[.065,.09,.075,.045,.008][k]
  for j in range(6):
   a=j*math.tau/6;v=pony.data.vertices[k*6+j];v.co=center+Vector((0,math.cos(a)*radius,math.sin(a)*radius));v.keyframe_insert('co',frame=frame)
for datablock in [arm]+[ob.data for ob,_ in cloths]+[pony.data]:
 if datablock.animation_data and datablock.animation_data.action:
  for fc in datablock.animation_data.action.fcurves:
   for kp in fc.keyframe_points:kp.interpolation='LINEAR'
scene.frame_set(7);bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'pink_runner.blend'))
(OUT/'check.json').write_text(json.dumps({'frames_per_cycle':36,'fps':60,'max_bone_length_error_m':max_bone_error,'camera':'orthographic','resolution':[256,160],'reference_motion':'interpreted from single image'},indent=2))
scene.render.filepath=str(OUT/'sample.png');bpy.ops.render.render(write_still=True)

scene.render.filepath=str(OUT/"frames/frame_");bpy.ops.render.render(animation=True)
