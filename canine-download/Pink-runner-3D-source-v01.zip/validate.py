import bpy,json,math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
scene=bpy.context.scene;arm=bpy.data.objects['RunnerRig'];deps=bpy.context.evaluated_depsgraph_get()
def snapshot(frame):
 scene.frame_set(frame);bpy.context.view_layer.update();r={}
 for o in scene.objects:
  if o.type!='MESH':continue
  e=o.evaluated_get(deps);m=e.to_mesh();r[o.name]=[e.matrix_world@v.co for v in m.vertices];e.to_mesh_clear()
 return r
first=snapshot(1);last=snapshot(37)
seam=max((a-b).length for name in first for a,b in zip(first[name],last[name]))
length_error=0;minx=miny=1;maxx=maxy=0
for frame in range(1,37):
 points=snapshot(frame)
 for bone in arm.pose.bones:
  length=bone.bone.length;m=bone.matrix
  error=abs(((m@Vector((0,length,0)))-(m@Vector((0,0,0)))).length-length)
  length_error=max(length_error,error)
 for vertices in points.values():
  for p in vertices:
   q=world_to_camera_view(scene,scene.camera,p);minx=min(minx,q.x);maxx=max(maxx,q.x);miny=min(miny,q.y);maxy=max(maxy,q.y)
r={'unique_cycle_frames':36,'fps':60,'native_resolution':[256,160],'loop_mesh_endpoint_error_m':seam,'max_rig_bone_length_error_m':length_error,'camera_bounds_normalized':[minx,miny,maxx,maxy],'camera':'orthographic','motion_interpreted_from_single_reference':True}
open('/tmp/pink3d/validation.json','w').write(json.dumps(r,indent=2));print('VALIDATION',json.dumps(r))
assert seam<0.0001 and length_error<0.0001 and minx>0 and miny>0 and maxx<1 and maxy<1
