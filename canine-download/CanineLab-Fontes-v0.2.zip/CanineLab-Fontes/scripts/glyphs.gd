extends RefCounted
class_name CanineGlyph

static func paint(c: CanvasItem, kind: String, p: Vector2, r: float, color := Color.WHITE) -> void:
	var width := maxf(1.6, r * 0.095)
	if kind in ["cross", "circle", "square", "triangle", "stick", "l3"]:
		c.draw_arc(p, r, 0, TAU, 48, color, width, true)
		c.draw_arc(p, r * 0.82, 0, TAU, 48, color, width * 0.75, true)
	match kind:
		"cross":
			c.draw_line(p + Vector2(-r, -r) * 0.39, p + Vector2(r, r) * 0.39, color, width, true)
			c.draw_line(p + Vector2(r, -r) * 0.39, p + Vector2(-r, r) * 0.39, color, width, true)
		"circle": c.draw_arc(p, r * 0.42, 0, TAU, 40, color, width, true)
		"square": c.draw_rect(Rect2(p - Vector2.ONE * r * 0.42, Vector2.ONE * r * 0.84), color, false, width)
		"triangle": c.draw_polyline(PackedVector2Array([p + Vector2(0, -r * 0.5), p + Vector2(r * 0.5, r * 0.4), p + Vector2(-r * 0.5, r * 0.4), p + Vector2(0, -r * 0.5)]), color, width, true)
		"stick", "l3":
			c.draw_polyline(PackedVector2Array([p + Vector2(-r * 0.19, -r * 0.4), p + Vector2(-r * 0.19, r * 0.32), p + Vector2(r * 0.3, r * 0.32)]), color, width, true)
			if kind == "stick":
				for sign_x in [-1.0, 1.0]:
					c.draw_polyline(PackedVector2Array([p + Vector2(sign_x * r * 1.12, -r * 0.2), p + Vector2(sign_x * r * 1.35, 0), p + Vector2(sign_x * r * 1.12, r * 0.2)]), color, width, true)
		"r2", "options", "touchpad", "create":
			var style := StyleBoxFlat.new()
			style.bg_color = color
			style.set_corner_radius_all(int(r * 0.3))
			c.draw_style_box(style, Rect2(p - Vector2(r * 1.1, r * 0.75), Vector2(r * 2.2, r * 1.5)))
			var text: String = {"r2": "R2", "options": "≡", "touchpad": "PAD", "create": "|||"}.get(kind, kind)
			var font := ThemeDB.fallback_font
			var size := int(r * (0.65 if kind == "touchpad" else 0.95))
			var text_size := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size)
			c.draw_string(font, p + Vector2(-text_size.x * 0.5, size * 0.33), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color("172230"))
