extends Control
class_name CanineControlsPanel
signal closed
var font := ThemeDB.fallback_font
var close_button: Button
var device_id := -1
var analog_value := Vector2.ZERO
var trigger_value := 0.0

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	close_button = Button.new()
	close_button.position = Vector2(1040, 642)
	close_button.size = Vector2(172, 42)
	close_button.text = "Voltar  ·  Esc"
	close_button.pressed.connect(func(): closed.emit())
	add_child(close_button)

func _process(_dt: float) -> void:
	var devices := Input.get_connected_joypads()
	device_id = -1 if devices.is_empty() else devices[0]
	analog_value = Vector2.ZERO if device_id < 0 else Vector2(Input.get_joy_axis(device_id, JOY_AXIS_LEFT_X), Input.get_joy_axis(device_id, JOY_AXIS_LEFT_Y))
	trigger_value = 0 if device_id < 0 else maxf(0, Input.get_joy_axis(device_id, JOY_AXIS_TRIGGER_RIGHT))
	if visible:
		queue_redraw()

func text(at: Vector2, value: String, size := 17, color := Color("d9e4ed")) -> void:
	draw_string(font, at, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func outline(points: Array, offset: Vector2) -> PackedVector2Array:
	var result := PackedVector2Array()
	for i in range(points.size()):
		var a: Vector2 = points[(i - 1 + points.size()) % points.size()]
		var b: Vector2 = points[i]
		var c: Vector2 = points[(i + 1) % points.size()]
		var d: Vector2 = points[(i + 2) % points.size()]
		for j in range(8):
			var t := j / 8.0
			result.append(offset + 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t * t * t))
	return result

func leader(p: Vector2, end: Vector2, left: bool) -> void:
	var elbow_x := 390.0 if left else 898.0
	draw_polyline(PackedVector2Array([p, Vector2(elbow_x, p.y), Vector2(elbow_x, end.y), end]), Color("627a90"), 1.3, true)
	draw_circle(p, 3, Color("c1d6e6"))

func entry(kind: String, title: String, description: String, y: float, point: Vector2, left: bool) -> void:
	var start := Vector2(78 if left else 940, y)
	leader(point, Vector2(358 if left else 912, y - 7), left)
	CanineGlyph.paint(self, kind, start, 15, Color("d8eaff"))
	text(start + Vector2(29, -1), title, 17)
	text(start + Vector2(29, 21), description, 12, Color("91a9bb"))

func _draw() -> void:
	draw_rect(Rect2(0, 0, 1280, 720), Color(0.035, 0.055, 0.085, 0.98))
	text(Vector2(350, 68), "CONTROLES  /  DUALSENSE", 28, Color("edc792"))
	text(Vector2(350, 96), "Movimentação analógica progressiva · teste os comandos com o controle conectado", 15, Color("9eb3c4"))
	draw_line(Vector2(62, 119), Vector2(1212, 119), Color("344657"), 1)
	var shell := outline([Vector2(-172,-43),Vector2(-148,-66),Vector2(-105,-69),Vector2(-72,-58),Vector2(72,-58),Vector2(105,-69),Vector2(148,-66),Vector2(172,-43),Vector2(188,18),Vector2(209,111),Vector2(198,132),Vector2(174,123),Vector2(122,64),Vector2(76,48),Vector2(-76,48),Vector2(-122,64),Vector2(-174,123),Vector2(-198,132),Vector2(-209,111),Vector2(-188,18)], Vector2(640, 300))
	draw_colored_polygon(shell, Color("e1e7ed"))
	var border := shell.duplicate()
	border.append(shell[0])
	draw_polyline(border, Color("8da0b1"), 3, true)
	# Dark center and touch surface distinguish the DualSense layout.
	draw_colored_polygon(PackedVector2Array([Vector2(540,315),Vector2(740,315),Vector2(769,378),Vector2(735,396),Vector2(545,396),Vector2(511,378)]), Color("162433"))
	draw_colored_polygon(PackedVector2Array([Vector2(565,240),Vector2(715,240),Vector2(726,302),Vector2(554,302)]), Color("bac8d3"))
	draw_polyline(PackedVector2Array([Vector2(562,244),Vector2(558,302),Vector2(722,302),Vector2(718,244)]), Color("6aa6d0"), 2, true)
	for x in [505, 775]:
		draw_style_box(rounded(Color("293a4b"), 9), Rect2(x-30,222,60,23))
	# D-pad.
	for rect in [Rect2(487,267,16,58),Rect2(466,288,58,16)]:
		draw_rect(rect, Color("7c8d9b"))
	for y in [274, 318]:
		draw_line(Vector2(492,y),Vector2(498,y),Color("d5dfe7"),2)
	# Live left stick plus idle right stick.
	for pos in [Vector2(580,354),Vector2(700,354)]:
		draw_circle(pos, 31, Color("0a1420"))
		draw_arc(pos, 29, 0, TAU, 48, Color("536a7c"), 2, true)
	var stick := Vector2(580,354) + analog_value * 10
	draw_circle(stick, 23, Color("34495c"))
	draw_circle(Vector2(700,354), 23, Color("34495c"))
	for i in range(4):
		var point: Vector2 = [Vector2(786,274),Vector2(811,298),Vector2(786,322),Vector2(761,298)][i]
		var kind: String = ["triangle", "circle", "cross", "square"][i]
		var button: int = [JOY_BUTTON_Y,JOY_BUTTON_B,JOY_BUTTON_A,JOY_BUTTON_X][i]
		var pressed := device_id >= 0 and Input.is_joy_button_pressed(device_id, button)
		draw_circle(point, 17, Color("759fc2") if pressed else Color("acbcc8"))
		CanineGlyph.paint(self, kind, point, 11, Color("33495e"))
	CanineGlyph.paint(self, "create", Vector2(539,268), 9, Color("718a9d"))
	CanineGlyph.paint(self, "options", Vector2(741,268), 9, Color("718a9d"))
	draw_circle(Vector2(640,351), 8, Color("95a8b7"))
	for x in range(622,660,6):
		draw_circle(Vector2(x,318),1.3,Color("607589"))
	entry("stick", "Mover / andar / correr", "Inclinação controla a velocidade", 200, Vector2(580,354), true)
	entry("r2", "Correr com mais resposta", "R2 ou L3 + direção", 275, Vector2(775,229), true)
	entry("create", "Voltar ao início", "Create  ·  teclado R", 350, Vector2(539,268), true)
	entry("touchpad", "Abrir os controles", "Touchpad  ·  teclado F2", 425, Vector2(640,267), true)
	entry("cross", "Pular", "Segure para saltar mais alto", 200, Vector2(786,322), false)
	entry("circle", "Agachar", "Em corrida também desliza", 275, Vector2(811,298), false)
	entry("square", "Deslizar", "Precisa estar em movimento", 350, Vector2(761,298), false)
	entry("options", "Pausar / continuar", "Options  ·  teclado Esc", 425, Vector2(741,268), false)
	text(Vector2(62,515), "TECLADO", 16, Color("edc792"))
	text(Vector2(62,546), "A / D ou setas   mover       Shift   correr       Espaço   pular       Ctrl   agachar       C   deslizar", 16)
	text(Vector2(62,575), "Tab / △   ajuda       F2 / touchpad   controles       F11   tela cheia       R / Create   reiniciar", 15, Color("9eb3c4"))
	var connection := "Nenhum controle conectado · teclado disponível"
	if device_id >= 0:
		connection = Input.get_joy_name(device_id) + " · L %.2f / %.2f · R2 %.2f" % [analog_value.x, analog_value.y, trigger_value]
	text(Vector2(62,628), connection, 14, Color("8fb5c8"))
	text(Vector2(62,671), "Resistência física dos gatilhos adaptativos não implementada nesta versão.", 12, Color("748e9f"))

func rounded(color: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(radius)
	return style
