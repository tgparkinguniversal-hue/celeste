extends SceneTree
var lab
var p
var failures: Array[String] = []
var measured := []
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	lab = load("res://main.tscn").instantiate()
	root.add_child(lab)
	p = lab.player
	p.input_override = true
	for raw in [0.0, 0.3, 0.5, 0.7, 1.0]:
		p.reset()
		p.test_input = {}
		for i in range(20):
			await physics_frame
			await process_frame
		p.test_input = {"axis": p.analog_response(raw), "analog": true, "speed_limit": p.analog_speed_limit(raw, false)}
		for i in range(90):
			await physics_frame
			await process_frame
		var expected: float = p.analog_response(raw) * p.analog_speed_limit(raw, false)
		var actual: float = p.velocity.x
		measured.append({"raw": raw, "target": expected, "actual": actual})
		if absf(actual - expected) >= 0.02:
			failures.append("raw %.2f target %.3f actual %.3f" % [raw, expected, actual])
	print("ANALOG_RESULT ", JSON.stringify(measured))
	print("RESULT 5 checks / %d failures" % failures.size())
	FileAccess.open("/tmp/canine-build/analog-v02-results.json", FileAccess.WRITE).store_string(JSON.stringify({"checks": 5, "failures": failures, "measurements": measured},"  "))
	lab.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
