extends Node2D
var actor
var elapsed:=0.0
var travel_x:=500.0
var camera_x:=0.0
var label: Label
var ui_font:=SystemFont.new()
func _ready():
	ui_font.font_names=PackedStringArray(["DejaVu Sans"])
	actor=load("res://actor.gd").new();add_child(actor)
	var title:=Label.new();title.text="CANINE · REVISÃO DA CAMINHADA";title.position=Vector2(40,30);title.add_theme_font_override("font",ui_font);title.add_theme_font_size_override("font_size",23);add_child(title)
	label=Label.new();label.position=Vector2(40,75);label.add_theme_font_override("font",ui_font);label.add_theme_font_size_override("font_size",17);add_child(label)
	var note:=Label.new();note.text="Prévia visual · pose aprovada · captura fixa de 60 FPS";note.position=Vector2(40,675);note.add_theme_font_override("font",ui_font);add_child(note)
func _process(dt):
	elapsed+=dt
	var moving:=(elapsed>2 and elapsed<7.4) or (elapsed>8.6 and elapsed<14)
	var direction:=1.0 if elapsed<8 else -1.0
	actor.animate(dt,moving)
	actor.scale=Vector2(0.36*direction,0.36)
	travel_x+=213.408*direction*actor.amount*dt
	camera_x=lerpf(camera_x,maxf(0,travel_x-640),1-exp(-dt*7))
	actor.position=Vector2(travel_x-camera_x,610)-Vector2(600*0.36*direction,1358*0.36)
	label.text="POSE PARADA" if not moving else ("CAMINHADA →" if direction>0 else "← CAMINHADA")
	queue_redraw()
	if elapsed>16:get_tree().quit()
func _draw():
	draw_rect(Rect2(0,610,1280,110),Color("23383e"))
	draw_line(Vector2(0,610),Vector2(1280,610),Color("adc0bb"),2)
	for tile in range(-1,22):
		var x:float=tile*64-fmod(camera_x,64)
		draw_line(Vector2(x,615),Vector2(x,720),Color(0.5,0.6,0.6,0.12),1)
