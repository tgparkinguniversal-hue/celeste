extends SceneTree
var lab
var p
var checks := 0
var failures: Array[String] = []
func _initialize() -> void:
	call_deferred("run")
func check(ok: bool, name: String) -> void:
	checks += 1
	print(("PASS " if ok else "FAIL ") + name)
	if not ok: failures.append(name)
func settle(count := 25) -> void:
	for i in range(count):
		await physics_frame
		await process_frame
func body_at(x: float):
	for b in lab.world.get_children():
		if b is StaticBody3D and absf(b.position.x-x)<0.01: return b
	return null
func run() -> void:
	lab = load("res://main.tscn").instantiate()
	root.add_child(lab)
	p = lab.player
	p.input_override = true
	p.test_input = {}
	await settle()
	check(lab.controls_panel.controller_art.get_width() > 1000,"detailed controller artwork loaded")
	check(lab.grid_texture.get_image().has_mipmaps(),"grid texture mipmaps available")
	check(lab.controls_panel.controller_art.get_image().has_mipmaps(),"controller artwork mipmaps available")
	var loose_strips := 0
	for node in lab.world.get_children():
		if node is MeshInstance3D: loose_strips += 1
	check(loose_strips == 0,"no overlapping floor strips")
	var ramp = body_at(24)
	var mesh = ramp.get_child(0)
	var size: Vector3 = mesh.mesh.size
	var left: Vector3 = ramp.transform * Vector3(-size.x/2,size.y/2,0)
	var right: Vector3 = ramp.transform * Vector3(size.x/2,size.y/2,0)
	check(absf(left.y)<0.0001,"ramp entry flush with ground")
	var landing
	for node in lab.world.get_children():
		if node is StaticBody3D and node.position.x > 27 and node.position.x < 29: landing=node
	var landing_size: Vector3 = landing.get_child(0).mesh.size
	check(absf(landing.position.x-landing_size.x/2-right.x)<0.0001,"ramp and landing edges meet")
	check(absf(landing.position.y+landing_size.y/2-right.y)<0.0001,"ramp and landing heights meet")
	for x in [11.0,15.0]:
		var platform = body_at(x)
		var ps: Vector3 = platform.get_child(0).mesh.size
		check(absf(platform.position.y-ps.y/2)<0.0001,"jump platform grounded %.0f"%x)
	p.reset()
	p.position=Vector3(9.5,0.03,0)
	await settle(50)
	var camera: Camera3D=lab.camera
	var actual: Vector3=p.sprite.global_position
	var base: Vector3=p.global_position+Vector3(0,p.base_y*(1+p.visual_squash),0)
	check(camera.unproject_position(actual).distance_to(camera.unproject_position(base))<1.0,"foreground layer preserves screen placement")
	var nose:=actual+camera.global_basis.x*0.5+camera.global_basis.y*0.45
	var screen:=camera.unproject_position(nose)
	var ray:=PhysicsRayQueryParameters3D.create(camera.project_ray_origin(screen),nose)
	ray.exclude=[p.get_rid()]
	check(p.get_world_3d().direct_space_state.intersect_ray(ray).is_empty(),"foreground wall does not cut face artwork")
	check(not p.sprite.no_depth_test,"depth testing retained")
	check(p.sprite.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF,"no displaced billboard shadow")
	check(p.contact_shadow.visible and absf(p.contact_shadow.global_position.z)<0.001,"contact shadow remains on movement plane")
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/screens/v03-near-wall.png")
	print("RESULT %d checks / %d failures"%[checks,failures.size()])
	FileAccess.open("/tmp/canine-build/stage-v03-results.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures},"  "))
	lab.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
