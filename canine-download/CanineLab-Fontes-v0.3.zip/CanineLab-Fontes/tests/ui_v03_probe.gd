extends SceneTree
var lab
var failures: Array[String] = []
var checks := 0
func _initialize() -> void:
	call_deferred("run")
func check(ok: bool, name: String) -> void:
	checks += 1
	print(("PASS " if ok else "FAIL ") + name)
	if not ok: failures.append(name)
func run() -> void:
	lab = load("res://main.tscn").instantiate()
	root.add_child(lab)
	lab.player.input_override = true
	for i in range(40):
		await process_frame
	check(Engine.max_fps == 0, "engine frame cap removed")
	check(ProjectSettings.get_setting("display/window/vsync/vsync_mode") == 0, "project VSync disabled")
	check(Engine.physics_ticks_per_second == 120, "physics stays at 120 Hz")
	check(lab.fps_value > 0 and lab.fps_label.text.contains("ms"), "live FPS and frame time")
	check(lab.fps_label.get_parent().position == Vector2(28,18), "FPS top-left")
	check(is_zero_approx(CaninePlayer.analog_response(0.15)), "analog deadzone")
	check(is_equal_approx(CaninePlayer.analog_response(1.0),1.0), "full-stick range")
	check(is_equal_approx(CaninePlayer.analog_response(-0.7),-CaninePlayer.analog_response(0.7)), "symmetric analog response")
	var previous := -1.0
	var monotonic := true
	for i in range(101):
		var raw := i / 100.0
		var value := CaninePlayer.analog_response(raw) * CaninePlayer.analog_speed_limit(raw, false)
		monotonic = monotonic and value >= previous
		previous = value
	check(monotonic, "progressive speed without thresholds")
	check(absf(CaninePlayer.analog_speed_limit(0.951, false)-CaninePlayer.analog_speed_limit(0.949, false)) < 0.01, "continuous run blend")
	check(CaninePlayer.analog_speed_limit(0.5, true) == CaninePlayer.RUN, "sprint speed override")
	var icon_count := 0
	var grid_count := 0
	for item in lab.world.get_children():
		if item is Sprite3D and item.texture != null: icon_count += 1
		if item is StaticBody3D:
			for child in item.get_children():
				if child is MeshInstance3D and child.material_override is ShaderMaterial: grid_count += 1
	check(icon_count == 8, "8 PlayStation-style tutorial prompts")
	check(grid_count >= 14, "world-scaled test grid material")
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/screens/v03-stage.png")
	lab.open_controls(false)
	check(lab.controls_panel.visible and lab.paused and not lab.player.is_physics_processing(), "controls opened from gameplay pause movement")
	for i in range(6): await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/screens/v03-controls.png")
	lab.close_controls()
	check(not lab.paused and not lab.controls_panel.visible, "closing controls resumes gameplay")
	lab.set_pause(true)
	lab.open_controls(true)
	lab.close_controls()
	check(lab.paused and lab.pause_panel.visible, "controls return to pause menu")
	lab.set_pause(false)
	var pad := InputEventJoypadButton.new()
	pad.button_index = JOY_BUTTON_TOUCHPAD
	pad.pressed = true
	check(InputMap.event_is_action(pad,"controls"), "touchpad controls menu mapping")
	print("RESULT %d checks / %d failures" % [checks, failures.size()])
	FileAccess.open("/tmp/canine-build/ui-v03-results.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures,"renderer":"Linux software OpenGL; not Windows GPU benchmark","engine_cap":Engine.max_fps,"physics_hz":Engine.physics_ticks_per_second},"  "))
	lab.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
