extends CharacterBody3D
class_name CaninePlayer

const WALK := 3.2
const RUN := 6.8
const CROUCH_SPEED := 1.5
const ACCEL := 26.0
const AIR_ACCEL := 11.0
const BRAKE := 32.0
const GRAVITY := 24.0
const JUMP_SPEED := 8.8
const STAND_HEIGHT := 1.72
const LOW_HEIGHT := 0.88
var input_override := false
var test_input := {}
var state := "idle"
var facing := 1.0
var jump_buffer := 0.0
var coyote := 0.0
var slide_time := 0.0
var slide_cooldown := 0.0
var crouched := false
var landed := 0.0
var last_floor := false
var jumps := 0
var slide_count := 0
var clock := 0.0
var animation_time := 0.0
var last_state := ""
var collider: CollisionShape3D
var capsule: CapsuleShape3D
var sprite: Sprite3D
var atlas: AtlasTexture
var sheet: Texture2D
var stand_probe := CapsuleShape3D.new()
var cell := Vector2i(256, 256)
var spawn := Vector3(-18, 0.04, 0)
var measured_bottom := 224.0
var measured_top := 30.0
var base_y := 0.0
var visual_squash := 0.0
var previous_position := Vector3.ZERO
var contact_shadow: MeshInstance3D
var shadow_material: ShaderMaterial
const SPRITE_DEPTH_LAYER := 3.4
var shadow_ground := Vector3.ZERO
var shadow_valid := false
var shadow_height := 0.0

func _ready() -> void:
	floor_snap_length = 0.22
	floor_max_angle = deg_to_rad(47)
	floor_stop_on_slope = true
	floor_constant_speed = true
	motion_mode = CharacterBody3D.MOTION_MODE_GROUNDED
	capsule = CapsuleShape3D.new()
	capsule.radius = 0.26
	capsule.height = STAND_HEIGHT
	collider = CollisionShape3D.new()
	collider.shape = capsule
	collider.position.y = STAND_HEIGHT / 2
	add_child(collider)
	stand_probe.radius = 0.26
	stand_probe.height = STAND_HEIGHT
	sheet = load("res://assets/canine_sheet.png")
	if sheet:
		cell = Vector2i(sheet.get_width() / 8, sheet.get_height() / 6)
		var metrics = JSON.parse_string(FileAccess.get_file_as_string("res://assets/metrics.json"))
		if metrics:
			measured_bottom = float(metrics.bottom)
			measured_top = float(metrics.top)
		sprite = Sprite3D.new()
		atlas = AtlasTexture.new()
		atlas.atlas = sheet
		atlas.region = Rect2(0, 0, cell.x, cell.y)
		sprite.texture = atlas
		sprite.pixel_size = STAND_HEIGHT / maxf(measured_bottom - measured_top, 1.0)
		base_y = (measured_bottom - cell.y / 2.0) * sprite.pixel_size
		sprite.position.y = base_y
		sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		sprite.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		sprite.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		sprite.alpha_scissor_threshold = 0.2
		sprite.no_depth_test = false
		sprite.shaded = false
		sprite.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(sprite)
	contact_shadow = MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(1.15, 0.75)
	contact_shadow.mesh = plane
	shadow_material = ShaderMaterial.new()
	shadow_material.shader = preload("res://shaders/contact_shadow.gdshader")
	contact_shadow.material_override = shadow_material
	contact_shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(contact_shadow)
	position = spawn
	previous_position = position

static func analog_response(raw: float) -> float:
	var strength := clampf((absf(raw) - 0.16) / 0.84, 0, 1)
	return signf(raw) * pow(strength, 1.2)

static func analog_speed_limit(raw: float, sprint: bool) -> float:
	return RUN if sprint else lerpf(WALK, RUN, smoothstep(0.45, 0.95, absf(raw)))

func command() -> Dictionary:
	if input_override:
		return test_input
	var axis := Input.get_axis("left", "right")
	var sprint := Input.is_action_pressed("run")
	var analog_active := false
	var limit := RUN if sprint else WALK
	var keyboard_direction := Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_RIGHT)
	if not keyboard_direction:
		for id in Input.get_connected_joypads():
			var raw := Input.get_joy_axis(id, JOY_AXIS_LEFT_X)
			if absf(raw) > 0.16:
				axis = analog_response(raw)
				limit = analog_speed_limit(raw, sprint)
				analog_active = true
				break
	return {"axis": axis, "analog": analog_active, "speed_limit": limit, "run": sprint, "crouch": Input.is_action_pressed("crouch"), "jump": Input.is_action_just_pressed("jump"), "jump_held": Input.is_action_pressed("jump"), "slide": Input.is_action_just_pressed("slide") or (Input.is_action_just_pressed("crouch") and absf(velocity.x) > 4.0)}

func can_stand() -> bool:
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = stand_probe
	q.transform = Transform3D(Basis.IDENTITY, global_position + Vector3(0, STAND_HEIGHT / 2 + 0.035, 0))
	q.exclude = [get_rid()]
	q.collision_mask = collision_mask
	q.margin = 0.001
	return get_world_3d().direct_space_state.intersect_shape(q, 1).is_empty()

func reset() -> void:
	global_position = spawn
	previous_position = global_position
	velocity = Vector3.ZERO
	slide_time = 0
	jump_buffer = 0
	coyote = 0
	crouched = false
	state = "idle"
	capsule.height = STAND_HEIGHT
	collider.position.y = STAND_HEIGHT / 2

func _physics_process(dt: float) -> void:
	previous_position = global_position
	var cmd := command()
	var axis := clampf(float(cmd.get("axis", 0)), -1, 1)
	var floor_now := is_on_floor()
	if floor_now:
		coyote = 0.11
	else:
		coyote = maxf(0, coyote - dt)
	jump_buffer = maxf(0, jump_buffer - dt)
	slide_cooldown = maxf(0, slide_cooldown - dt)
	if cmd.get("jump", false):
		jump_buffer = 0.13
	if cmd.get("slide", false) and floor_now and absf(velocity.x) > 3.4 and slide_cooldown <= 0:
		slide_time = 0.62
		slide_cooldown = 0.85
		slide_count += 1
		velocity.x = signf(velocity.x) * maxf(absf(velocity.x), 7.8)
	var slide_active := slide_time > 0
	if slide_active:
		slide_time = maxf(0, slide_time - dt)
		velocity.x = move_toward(velocity.x, 0, 7.2 * dt)
		if absf(velocity.x) < 2.1 or not floor_now:
			slide_time = 0
	var low_requested: bool = bool(cmd.get("crouch", false)) or slide_time > 0
	crouched = low_requested or (crouched and not can_stand())
	var height := LOW_HEIGHT if crouched else STAND_HEIGHT
	capsule.height = height
	collider.position.y = height / 2
	if slide_time <= 0:
		var max_speed := CROUCH_SPEED if crouched else (RUN if cmd.get("run", false) else WALK)
		if cmd.get("analog", false) and not crouched:
			max_speed = clampf(float(cmd.get("speed_limit", WALK)), WALK, RUN)
		var desired := axis * max_speed
		var accel := AIR_ACCEL if not floor_now else (BRAKE if absf(axis) < 0.01 or signf(axis) != signf(velocity.x) else ACCEL)
		velocity.x = move_toward(velocity.x, desired, accel * dt)
	if jump_buffer > 0 and coyote > 0 and not (crouched and not can_stand()):
		velocity.y = JUMP_SPEED
		jump_buffer = 0
		coyote = 0
		slide_time = 0
		jumps += 1
	if not floor_now or velocity.y > 0:
		var gravity_scale := 1.65 if velocity.y < 0 else (1.7 if not cmd.get("jump_held", false) else 1.0)
		velocity.y = maxf(velocity.y - GRAVITY * gravity_scale * dt, -22)
	velocity.z = 0
	var before_y := velocity.y
	move_and_slide()
	global_position.z = 0
	if is_on_floor() and not floor_now and before_y < -3:
		landed = 0.13
	landed = maxf(0, landed - dt)
	if absf(axis) > 0.1 and slide_time <= 0:
		facing = signf(axis)
	if not is_on_floor():
		state = "jump" if velocity.y > 0 else "fall"
	elif slide_time > 0:
		state = "slide"
	elif crouched:
		state = "crouch"
	elif absf(velocity.x) > 3.6:
		state = "run"
	elif absf(velocity.x) > 0.15:
		state = "walk"
	else:
		state = "idle"
	if global_position.y < -8:
		reset()
	last_floor = is_on_floor()
	var shadow_query := PhysicsRayQueryParameters3D.create(global_position + Vector3(0,0.1,0), global_position - Vector3(0,6,0))
	shadow_query.exclude = [get_rid()]
	var shadow_hit := get_world_3d().direct_space_state.intersect_ray(shadow_query)
	shadow_valid = not shadow_hit.is_empty()
	if shadow_valid:
		shadow_ground = shadow_hit.position
		shadow_height = maxf(0, global_position.y - shadow_ground.y)


func _process(dt: float) -> void:
	if not sprite:
		return
	clock += dt
	if state != last_state:
		animation_time = 0
		last_state = state
	animation_time += dt
	var row := 0
	var frame := 0
	match state:
		"idle": row = 0; frame = int(animation_time * 6.0) % 8
		"walk": row = 1; frame = int(animation_time * clampf(absf(velocity.x) * 3.2, 4, 12)) % 8
		"run": row = 2; frame = int(animation_time * 13) % 8
		"crouch": row = 3; frame = 3 + mini(2, int(animation_time * 12))
		"jump": row = 4; frame = clampi(int((JUMP_SPEED - velocity.y) / JUMP_SPEED * 4), 0, 3)
		"fall": row = 4; frame = clampi(4 + int(-velocity.y / 4), 4, 6)
		"slide": row = 5; frame = 2 + mini(3, int(animation_time * 10))
	atlas.region = Rect2(frame * cell.x, row * cell.y, cell.x, cell.y)
	sprite.flip_h = facing < 0
	# Mild landing compression only; character silhouettes come from the sheet.
	var target := -0.055 if landed > 0 else 0.0
	visual_squash = lerpf(visual_squash, target, 1 - exp(-dt * 22))
	sprite.scale = Vector3(1 - visual_squash * 0.6, 1 + visual_squash, 1)
	var interpolated := previous_position.lerp(global_position, Engine.get_physics_interpolation_fraction())
	# Move only the billboard along the camera ray. Orthographic screen position is
	# preserved, while foreground faces no longer slice through the 2D artwork.
	var camera := get_viewport().get_camera_3d()
	var foreground := camera.global_basis.z * SPRITE_DEPTH_LAYER if camera else Vector3(0,0,SPRITE_DEPTH_LAYER)
	sprite.global_position = interpolated + Vector3(0, base_y * (1 + visual_squash), 0) + foreground
	# Shadow geometry is sampled during the physics tick, then interpolated here.
	contact_shadow.visible = shadow_valid
	if shadow_valid:
		contact_shadow.global_position = Vector3(interpolated.x, shadow_ground.y + 0.015, interpolated.z)
		contact_shadow.scale = Vector3.ONE * (1 + minf(shadow_height,3) * 0.12)
		shadow_material.set_shader_parameter("opacity", 0.26 / (1 + shadow_height * 0.35))
