extends Control
class_name CanineControlsPanel
signal closed
var font := ThemeDB.fallback_font
var controller_art := preload("res://assets/ui/dualsense.png")
var close_button: Button
var device_id := -1
var analog_value := Vector2.ZERO
var trigger_value := 0.0

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	close_button = Button.new()
	close_button.position = Vector2(1040, 642)
	close_button.size = Vector2(172, 42)
	close_button.text = "Voltar  ·  Esc"
	close_button.pressed.connect(func(): closed.emit())
	add_child(close_button)

func _process(_dt: float) -> void:
	var devices := Input.get_connected_joypads()
	device_id = -1 if devices.is_empty() else devices[0]
	analog_value = Vector2.ZERO if device_id < 0 else Vector2(Input.get_joy_axis(device_id, JOY_AXIS_LEFT_X), Input.get_joy_axis(device_id, JOY_AXIS_LEFT_Y))
	trigger_value = 0 if device_id < 0 else maxf(0, Input.get_joy_axis(device_id, JOY_AXIS_TRIGGER_RIGHT))
	if visible:
		queue_redraw()

func text(at: Vector2, value: String, size := 17, color := Color("d9e4ed")) -> void:
	draw_string(font, at, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func leader(p: Vector2, end: Vector2, left: bool) -> void:
	var index := clampf(roundf((end.y + 7.0 - 200.0) / 75.0), 0, 3)
	var elbow_x := 374.0 + index * 8.0 if left else 910.0 - index * 8.0
	draw_polyline(PackedVector2Array([p, Vector2(elbow_x, p.y), Vector2(elbow_x, end.y), end]), Color("627a90"), 1.3, true)
	draw_circle(p, 3, Color("c1d6e6"))

func entry(kind: String, title: String, description: String, y: float, point: Vector2, left: bool) -> void:
	var start := Vector2(78 if left else 940, y)
	leader(point, Vector2(358 if left else 912, y - 7), left)
	CanineGlyph.paint(self, kind, start, 15, Color("d8eaff"))
	text(start + Vector2(29, -1), title, 17)
	text(start + Vector2(29, 21), description, 12, Color("91a9bb"))

func _draw() -> void:
	draw_rect(Rect2(0, 0, 1280, 720), Color(0.035, 0.055, 0.085, 1.0))
	text(Vector2(350, 68), "CONTROLES  /  DUALSENSE", 28, Color("edc792"))
	text(Vector2(350, 96), "Movimentação analógica progressiva · teste os comandos com o controle conectado", 15, Color("9eb3c4"))
	draw_line(Vector2(62, 119), Vector2(1212, 119), Color("344657"), 1)
	# Detailed front view replaces the simplified procedural shell.
	draw_texture_rect(controller_art, Rect2(425, 205, 430, 286.67), false)
	# Rings are interaction overlays; they do not replace the physical buttons.
	if analog_value.length() > 0.16:
		draw_arc(Vector2(576,355) + analog_value * 6, 22, 0, TAU, 48, Color(0.45,0.8,1,0.85), 2, true)
	for item in [[JOY_BUTTON_A,Vector2(774,323)],[JOY_BUTTON_B,Vector2(803,290)],[JOY_BUTTON_X,Vector2(744,290)],[JOY_BUTTON_Y,Vector2(774,260)]]:
		if device_id >= 0 and Input.is_joy_button_pressed(device_id, item[0]):
			draw_circle(item[1], 15, Color(0.4,0.75,1.0,0.35))
	entry("stick", "Mover / andar / correr", "Inclinação controla a velocidade", 200, Vector2(576,355), true)
	entry("r2", "Correr com mais resposta", "R2 ou L3 + direção", 275, Vector2(775,216), true)
	entry("create", "Voltar ao início", "Create  ·  teclado R", 350, Vector2(538,245), true)
	entry("touchpad", "Abrir os controles", "Touchpad  ·  teclado F2", 425, Vector2(640,258), true)
	entry("cross", "Pular", "Segure para saltar mais alto", 200, Vector2(774,323), false)
	entry("circle", "Agachar", "Em corrida também desliza", 275, Vector2(803,290), false)
	entry("square", "Deslizar", "Precisa estar em movimento", 350, Vector2(744,290), false)
	entry("options", "Pausar / continuar", "Options  ·  teclado Esc", 425, Vector2(740,245), false)
	text(Vector2(62,515), "TECLADO", 16, Color("edc792"))
	text(Vector2(62,546), "A / D ou setas   mover       Shift   correr       Espaço   pular       Ctrl   agachar       C   deslizar", 16)
	text(Vector2(62,575), "Tab / △   ajuda       F2 / touchpad   controles       F11   tela cheia       R / Create   reiniciar", 15, Color("9eb3c4"))
	var connection := "Nenhum controle conectado · teclado disponível"
	if device_id >= 0:
		connection = Input.get_joy_name(device_id) + " · L %.2f / %.2f · R2 %.2f" % [analog_value.x, analog_value.y, trigger_value]
	text(Vector2(62,628), connection, 14, Color("8fb5c8"))
	text(Vector2(62,671), "Resistência física dos gatilhos adaptativos não implementada nesta versão.", 12, Color("748e9f"))

