extends CharacterBody2D
class_name Hero2D
const UNIT := 72.0
const WALK := 230.4
const RUN := 489.6
const CROUCH_SPEED := 108.0
const STAND := 124.0
const LOW := 64.0
const JUMP := 633.6
var state := "idle"
var locked := false
var input_grace := 0.0
var override_input := false
var commands := {}
var crouched := false
var coyote := 0.0
var buffer := 0.0
var slide_time := 0.0
var cooldown := 0.0
var direction := 1.0
var clock := 0.0
var frame_index := 0
var jumps := 0
var slides := 0
var previous_position := Vector2.ZERO
var capsule: CapsuleShape2D
var collider: CollisionShape2D
var sprite: Sprite2D
var atlas: AtlasTexture
var metrics := {}
var cell := Vector2i(192,192)
var base_scale := 1.0
var main_sheet: Texture2D
var crawl_sheet: Texture2D
var crawl_metrics := {}
var animation_clock := 0.0
var last_state := ""
var spawn := Vector2(-1296,-2)

static func analog(raw: float) -> float:
	return signf(raw) * pow(clampf((absf(raw)-0.16)/0.84,0,1),1.2)

func _ready() -> void:
	floor_snap_length = 16
	floor_max_angle = deg_to_rad(47)
	floor_constant_speed = true
	capsule = CapsuleShape2D.new()
	capsule.radius = 19
	capsule.height = STAND
	collider = CollisionShape2D.new()
	collider.position.y = -STAND/2
	collider.shape = capsule
	add_child(collider)
	metrics = JSON.parse_string(FileAccess.get_file_as_string("res://assets/metrics.json"))
	var sheet: Texture2D = load("res://assets/hero.png")
	main_sheet=sheet
	crawl_sheet=load("res://assets/crouch_walk.png")
	crawl_metrics=JSON.parse_string(FileAccess.get_file_as_string("res://assets/crawl_metrics.json"))
	cell = Vector2i(int(metrics.cell_width),int(metrics.cell_height))
	base_scale = STAND / float(metrics.stand_height)
	atlas = AtlasTexture.new()
	atlas.atlas = sheet
	atlas.region = Rect2(0,0,cell.x,cell.y)
	sprite = Sprite2D.new()
	sprite.texture = atlas
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var shader := Shader.new()
	shader.code = "shader_type canvas_item; void fragment(){vec4 c=texture(TEXTURE,UV); if(c.a<0.88){discard;} COLOR=vec4(c.rgb,1.0);}"
	var material := ShaderMaterial.new()
	material.shader = shader
	sprite.material = material
	add_child(sprite)
	z_index = 10
	reset()

func reset() -> void:
	position = spawn
	previous_position = position
	velocity = Vector2.ZERO
	slide_time = 0
	buffer = 0
	coyote = 0
	crouched = false
	state = "idle"
	capsule.height = STAND
	collider.position.y = -STAND/2

func read_command() -> Dictionary:
	if locked or input_grace>0: return {}
	if override_input: return commands
	var axis := Input.get_axis("left","right")
	var speed := RUN if Input.is_action_pressed("run") else WALK
	var keyboard := Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_RIGHT)
	if not keyboard:
		for id in Input.get_connected_joypads():
			var raw := Input.get_joy_axis(id,JOY_AXIS_LEFT_X)
			if absf(raw)>0.16:
				axis = analog(raw)
				speed = RUN if Input.is_action_pressed("run") else lerpf(WALK,RUN,smoothstep(0.45,0.95,absf(raw)))
				break
	return {"axis":axis,"speed":speed,"jump":Input.is_action_just_pressed("jump"),"held":Input.is_action_pressed("jump"),"crouch":Input.is_action_pressed("crouch"),"slide":Input.is_action_just_pressed("slide") or (Input.is_action_just_pressed("crouch") and absf(velocity.x)>290)}

func clear_above() -> bool:
	var shape := CapsuleShape2D.new()
	shape.radius = 19
	shape.height = STAND
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = shape
	q.transform = Transform2D(0,global_position+Vector2(0,-STAND/2-2))
	q.exclude = [get_rid()]
	q.collision_mask = collision_mask
	return get_world_2d().direct_space_state.intersect_shape(q,1).is_empty()

func _physics_process(dt: float) -> void:
	previous_position = global_position
	input_grace=maxf(0,input_grace-dt)
	var cmd := read_command()
	var axis := clampf(float(cmd.get("axis",0)),-1,1)
	var grounded := is_on_floor()
	coyote = 0.11 if grounded else maxf(0,coyote-dt)
	buffer = maxf(0,buffer-dt)
	cooldown = maxf(0,cooldown-dt)
	if cmd.get("jump",false): buffer=0.13
	if cmd.get("slide",false) and grounded and absf(velocity.x)>245 and cooldown<=0:
		slide_time=0.62
		cooldown=0.85
		velocity.x=signf(velocity.x)*maxf(absf(velocity.x),560)
		slides+=1
	if slide_time>0:
		slide_time=maxf(0,slide_time-dt)
		velocity.x=move_toward(velocity.x,0,518*dt)
		if not grounded or absf(velocity.x)<150: slide_time=0
	crouched = bool(cmd.get("crouch",false)) or slide_time>0 or (crouched and not clear_above())
	capsule.height = LOW if crouched else STAND
	collider.position.y=-capsule.height/2
	if slide_time<=0:
		var speed: float = CROUCH_SPEED if crouched else float(cmd.get("speed",WALK))
		var target := axis*speed
		var accel := 792.0 if not grounded else (2304.0 if absf(axis)<0.01 or signf(axis)!=signf(velocity.x) else 1872.0)
		velocity.x=move_toward(velocity.x,target,accel*dt)
	if buffer>0 and coyote>0 and not(crouched and not clear_above()):
		velocity.y=-JUMP
		buffer=0
		coyote=0
		slide_time=0
		jumps+=1
	if not grounded or velocity.y<0:
		var gravity_scale:=1.65 if velocity.y>0 else (1.7 if not cmd.get("held",false) else 1.0)
		velocity.y=minf(1584,velocity.y+1728*gravity_scale*dt)
	move_and_slide()
	if absf(axis)>0.1 and slide_time<=0: direction=signf(axis)
	if not is_on_floor(): state="jump" if velocity.y<0 else "fall"
	elif slide_time>0: state="slide"
	elif crouched: state="crouch_walk" if absf(velocity.x)>8 else "crouch"
	elif absf(velocity.x)>259: state="run"
	elif absf(velocity.x)>10: state="walk"
	else: state="idle"
	if position.y>650: reset()

func _process(dt: float) -> void:
	clock+=dt
	if last_state!=state:
		animation_clock=0
		last_state=state
	animation_clock+=dt
	var row:=0
	var f:=0
	match state:
		"idle": row=0; f=int(animation_clock*6)%8
		"walk": row=1; f=int(animation_clock*clampf(absf(velocity.x)/UNIT*3.2,4,12))%8
		"run": row=2; f=int(animation_clock*13)%8
		"crouch": row=3; f=3+int(animation_clock*5)%3
		"crouch_walk": row=4; f=int(animation_clock*clampf(absf(velocity.x)/UNIT*6,4,9))%8
		"jump": row=5; f=clampi(int((JUMP+velocity.y)/JUMP*4),0,3)
		"fall": row=5; f=clampi(4+int(velocity.y/288),4,6)
		"slide": row=6; f=2+mini(3,int(animation_clock*10))
	frame_index=row*8+f
	var current_cell:=cell
	var current_scale:=base_scale
	var foot: float=float(metrics.frames[frame_index].bottom)
	atlas.atlas=main_sheet
	if state=="crouch_walk":
		f=int(animation_clock*clampf(absf(velocity.x)/UNIT*6,4,9))%8
		frame_index=f
		current_cell=Vector2i(int(crawl_metrics.cell_width),int(crawl_metrics.cell_height))
		current_scale=76.0/float(crawl_metrics.pose_height)
		foot=float(crawl_metrics.frames[f].bottom)
		atlas.atlas=crawl_sheet
		atlas.region=Rect2((f%4)*current_cell.x,int(f/4)*current_cell.y,current_cell.x,current_cell.y)
	else:
		atlas.region=Rect2(f*cell.x,row*cell.y,cell.x,cell.y)
	sprite.flip_h=direction<0
	sprite.scale=Vector2.ONE*current_scale
	var interp:=previous_position.lerp(global_position,Engine.get_physics_interpolation_fraction())
	sprite.global_position=interp+Vector2(0,(current_cell.y/2.0-foot)*current_scale)
	queue_redraw()

func _draw() -> void:
	if is_on_floor(): draw_ellipse()
func draw_ellipse() -> void:
	draw_set_transform(Vector2(0,-2),0,Vector2(1,0.22))
	draw_circle(Vector2.ZERO,32,Color(0.02,0.04,0.05,0.17))
	draw_set_transform(Vector2.ZERO,0,Vector2.ONE)
