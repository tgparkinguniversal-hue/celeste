extends SceneTree
var app
var p
var checks:=0
var failures: Array[String]=[]
func _initialize() -> void:call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1;print(("PASS " if ok else "FAIL ")+message)
	if not ok:failures.append(message)
func tick(count: int,cmd: Dictionary={}) -> void:
	p.commands=cmd
	for i in range(count):await physics_frame;await process_frame
func reset_player() -> void:
	p.reset();await tick(25)
func count_3d(node: Node) -> int:
	var result:=1 if node is Node3D else 0
	for child in node.get_children():result+=count_3d(child)
	return result
func run() -> void:
	app=load("res://main.tscn").instantiate();root.add_child(app);p=app.player
	check(app.mode=="title" and app.title_menu.visible,"title screen present")
	check(count_3d(app)==0,"entire scene is 2D")
	check(Engine.max_fps==0,"uncapped rendering")
	check(ProjectSettings.get_setting("display/window/vsync/vsync_mode")==0,"VSync disabled")
	check(Engine.physics_ticks_per_second==120,"120 Hz physics")
	app.play();p.override_input=true;await reset_player()
	check(p.is_on_floor(),"2D floor contact")
	await tick(90,{"axis":1.0})
	check(absf(p.velocity.x-p.WALK)<0.1 and p.state=="walk","walk speed and animation")
	await tick(30)
	check(absf(p.velocity.x)<0.01,"braking")
	await reset_player();await tick(90,{"axis":1.0,"speed":p.RUN})
	check(absf(p.velocity.x-p.RUN)<0.1 and p.state=="run","running")
	await tick(1,{"axis":1.0,"slide":true});await tick(5,{"axis":1.0})
	check(p.slide_time>0 and p.crouched,"sliding reduces collider")
	await tick(100)
	check(p.slide_time<=0,"slide stops")
	await reset_player();await tick(1,{"jump":true,"held":true})
	var full: float=-p.position.y
	for i in range(130):await tick(1,{"held":true});full=maxf(full,-p.position.y)
	check(full>100 and p.is_on_floor(),"full jump and landing")
	await reset_player();await tick(1,{"jump":true,"held":true})
	var short: float=-p.position.y
	for i in range(130):await tick(1);short=maxf(short,-p.position.y)
	check(short<full*0.8,"variable jump height")
	await reset_player();await tick(30,{"crouch":true})
	check(p.state=="crouch" and p.crouched,"crouched idle")
	var seen:={}
	for i in range(130):
		await tick(1,{"crouch":true,"axis":1.0})
		if p.state=="crouch_walk" and p.atlas.atlas==p.crawl_sheet:seen[p.frame_index]=true
	check(p.state=="crouch_walk" and seen.size()==8,"dedicated crouch walk cycle")
	check(p.atlas.atlas==p.crawl_sheet,"crouch walk uses its own sprite sheet")
	check(absf(p.velocity.x-p.CROUCH_SPEED)<0.1,"crouch walk speed")
	check(p.sprite.material.shader.code.contains("0.88") and p.sprite.material.shader.code.contains("discard"),"alpha fringe rejection enabled")
	check(p.sprite.texture_filter==CanvasItem.TEXTURE_FILTER_NEAREST,"pixel-art sampling retained")
	await reset_player();p.crouched=true;p.capsule.height=p.LOW;p.collider.position.y=-p.LOW/2;p.position=Vector2(-360,-2)
	await tick(20)
	check(p.crouched and not p.clear_above(),"low ceiling prevents standing")
	p.position=Vector2(-720,-2);await tick(20)
	check(not p.crouched,"standing after clearance")
	await reset_player();p.position.y=-25;p.velocity.y=144;await tick(2)
	var before: int=p.jumps
	await tick(1,{"jump":true,"held":true});await tick(18,{"held":true})
	check(p.jumps>before and p.velocity.y<0,"landing jump buffer")
	await reset_player();p.position=Vector2(430,-2)
	var edge:=false
	for i in range(45):
		await tick(1,{"axis":1.0,"speed":p.RUN})
		if not p.is_on_floor():edge=true;break
	before=p.jumps;await tick(1,{"jump":true,"held":true});await tick(2,{"held":true})
	check(edge and p.jumps>before,"coyote jump")
	p.position.y=800;await tick(3)
	check(p.position.y<10,"fall recovery")
	app.set_mode("pause")
	check(not p.is_physics_processing() and app.pause_menu.visible,"pause freezes movement")
	app.open_controls();check(app.controls.visible,"controls menu")
	app.back();check(app.mode=="pause","controls return to pause")
	app.open_options();check(app.options_menu.visible,"options screen")
	app.back();check(app.mode=="pause","options return to pause")
	app.home();check(app.mode=="title" and p.locked,"main menu locks movement")
	var e:=InputEventJoypadButton.new();e.button_index=JOY_BUTTON_A;e.pressed=true
	check(InputMap.event_is_action(e,"jump"),"DualSense cross mapping")
	e.button_index=JOY_BUTTON_B;check(InputMap.event_is_action(e,"crouch"),"DualSense circle mapping")
	e.button_index=JOY_BUTTON_X;check(InputMap.event_is_action(e,"slide"),"DualSense square mapping")
	e.button_index=JOY_BUTTON_TOUCHPAD;check(InputMap.event_is_action(e,"controls"),"DualSense touchpad mapping")
	check(is_zero_approx(p.analog(0.15)) and is_equal_approx(p.analog(1),1),"analog deadzone and range")
	print("RESULT %d checks / %d failures"%[checks,failures.size()])
	FileAccess.open("/tmp/canine-build/v04/results.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures,"jump_full_px":full,"jump_short_px":short,"crouch_walk_frames":seen.size()},"  "))
	app.queue_free();await process_frame;quit(0 if failures.is_empty() else 1)
