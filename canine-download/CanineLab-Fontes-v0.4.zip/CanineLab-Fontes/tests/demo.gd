extends SceneTree
var app
var p
var time:=0.0
var phase:=0
var local_time:=0.0
var hold:=0.0
var cooldown:=0.0
var visited:={}
var reset_count:=0
var previous_x:=-1296.0
var gameplay_started:=false
var menu_stage:=0
var tag: Label
func _initialize() -> void:call_deferred("run")
func run() -> void:
	app=load("res://main.tscn").instantiate();root.add_child(app);p=app.player;p.override_input=true
	var layer:=CanvasLayer.new();layer.layer=50;root.add_child(layer)
	tag=SoftUI.label("DEMONSTRAÇÃO 0.4\nCaptura fixa · não é benchmark",12,false);tag.position=Vector2(970,24);layer.add_child(tag)
	physics_frame.connect(drive)
func drive() -> void:
	var dt:=1.0/120
	time+=dt
	if time<2:return
	if time<4:
		if menu_stage==0:app.play();app.set_mode("pause");menu_stage=1
		return
	if time<6:
		if menu_stage==1:app.open_controls();menu_stage=2
		return
	if not gameplay_started:
		app.back();app.play();gameplay_started=true
	local_time+=dt;hold=maxf(0,hold-dt);cooldown=maxf(0,cooldown-dt)
	visited[p.state]=true
	if p.position.x<previous_x-600:reset_count+=1
	previous_x=p.position.x
	var cmd:={"axis":0.0}
	match phase:
		0:
			cmd={"axis":1.0}
			if p.position.x>-11*72:phase=1
		1:
			cmd={"axis":1.0,"speed":p.RUN}
			if p.position.x>-8*72:phase=2;local_time=0
		2:
			cmd={"axis":1.0,"slide":local_time<0.02}
			if local_time>0.67:phase=3
		3:
			cmd={"axis":1.0,"crouch":true}
			if p.position.x>-2.5*72:phase=4
		4:
			cmd={"axis":1.0,"speed":p.RUN,"held":hold>0}
			if p.is_on_floor() and cooldown<=0:
				var space=p.get_world_2d().direct_space_state
				var obstacle:=false
				for height in [25.0,57.0,94.0]:
					var q:=PhysicsRayQueryParameters2D.create(p.position-Vector2(0,height),p.position+Vector2(86,-height));q.exclude=[p.get_rid()]
					obstacle=obstacle or not space.intersect_ray(q).is_empty()
				var down:=PhysicsRayQueryParameters2D.create(p.position+Vector2(72,-14),p.position+Vector2(72,100));down.exclude=[p.get_rid()]
				if obstacle or space.intersect_ray(down).is_empty():cmd.jump=true;cmd.held=true;hold=0.42;cooldown=0.65
	if p.position.x>36*72:cmd={}
	p.commands=cmd
	if time>25:
		var result:={"states":visited.keys(),"resets":reset_count,"x_m":p.position.x/72.0,"jumps":p.jumps,"slides":p.slides}
		print("DEMO_COMPLETE ",JSON.stringify(result))
		FileAccess.open("/tmp/canine-build/v04/demo-results.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
		quit()
