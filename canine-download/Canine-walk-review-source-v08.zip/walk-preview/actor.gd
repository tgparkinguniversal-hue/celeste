extends Node2D
const COLS:=64
const ROWS:=88
var skin: Polygon2D
var source:=PackedVector2Array()
var phase:=0.0
var amount:=0.0
var last_feet: Array[Vector2]=[]
var rest_hips: Array[Vector2]=[Vector2(515,1100),Vector2(700,1100)]
var rest_knees: Array[Vector2]=[Vector2(540,1188),Vector2(725,1188)]
var rest_feet: Array[Vector2]=[Vector2(515,1275),Vector2(700,1275)]
func _ready():
	skin=Polygon2D.new();skin.texture=load("res://approved.png");skin.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(skin)
	for y in range(ROWS+1):
		for x in range(COLS+1):source.append(Vector2(x*1086.0/COLS,y*1448.0/ROWS))
	skin.uv=source;skin.polygon=source
	var triangles: Array[PackedInt32Array]=[]
	for y in range(ROWS):
		for x in range(COLS):
			var a:=y*(COLS+1)+x
			triangles.append(PackedInt32Array([a,a+1,a+COLS+2]))
			triangles.append(PackedInt32Array([a,a+COLS+2,a+COLS+1]))
	skin.polygons=triangles
func turn(p: Vector2,pivot: Vector2,at: Vector2,angle: float) -> Vector2:
	return at+(p-pivot).rotated(angle)
func animate(dt: float,moving: bool):
	amount=move_toward(amount,1.0 if moving else 0.0,dt*3)
	phase+=dt*0.855*amount
	var body_shift:=Vector2(0,amount*(13+3*cos(phase*TAU*2)))
	var targets: Array[Vector2]=[];var knees: Array[Vector2]=[]
	for i in range(2):
		var t:=fmod(phase+i*0.5,1.0)
		var foot:=rest_feet[i]
		# Flat stance and a lifted recovery, with fixed-length two-link legs.
		if t<0.6:foot.x+=lerpf(40,-40,t/0.6)*amount
		else:
			var swing:=(t-0.6)/0.4
			foot.x+=lerpf(-40,40,swing)*amount;foot.y-=sin(swing*PI)*20*amount
		var hip:=rest_hips[i]+body_shift
		var upper:=rest_hips[i].distance_to(rest_knees[i]);var lower:=rest_knees[i].distance_to(rest_feet[i])
		var delta:=foot-hip;var distance:=clampf(delta.length(),absf(upper-lower)+1,upper+lower-0.1)
		foot=hip+delta.normalized()*distance
		var theta:=delta.angle()-acos(clampf((upper*upper+distance*distance-lower*lower)/(2*upper*distance),-1,1))
		targets.append(foot);knees.append(hip+Vector2.from_angle(theta)*upper)
	last_feet=targets
	var output:=PackedVector2Array();output.resize(source.size())
	for index in range(source.size()):
		var p:=source[index];var q:=p+body_shift
		if p.y>1070 and p.x>385 and p.x<850:
			var leg_weight:=smoothstep(1070,1230,p.y)*smoothstep(385,430,p.x)*(1-smoothstep(800,850,p.x))
			var side:=smoothstep(510,720,p.x)
			var candidates: Array[Vector2]=[]
			for i in range(2):
				var upper_angle:float=(knees[i]-(rest_hips[i]+body_shift)).angle()-(rest_knees[i]-rest_hips[i]).angle()
				var lower_angle:float=(targets[i]-knees[i]).angle()-(rest_feet[i]-rest_knees[i]).angle()
				var thigh:=turn(p,rest_hips[i],rest_hips[i]+body_shift,upper_angle)
				var shin:=turn(p,rest_knees[i],knees[i],lower_angle)
				var boot:=p+targets[i]-rest_feet[i]
				var limb:=thigh.lerp(shin,smoothstep(1135,1220,p.y)).lerp(boot,smoothstep(1190,1330,p.y))
				candidates.append(limb)
			q=q.lerp(candidates[0].lerp(candidates[1],side),leg_weight)
		# Shoulders blend into the same connected mesh; the head stays rigid.
		if p.y>720 and p.y<1130:
			var arm_weight:=smoothstep(325,375,p.x)*(1-smoothstep(530,590,p.x))*smoothstep(735,825,p.y)*(1-smoothstep(1080,1130,p.y))
			var angle:=sin(phase*TAU)*0.05*amount
			q=q.lerp(turn(p,Vector2(470,780),Vector2(470,780)+body_shift,angle),arm_weight)
		var final:Vector2=(p+body_shift).lerp(q,0.65)
		if p.y>1240 and p.x>385 and p.x<850:
			final.y-=body_shift.y*0.35*smoothstep(1240,1350,p.y)*smoothstep(385,430,p.x)*(1-smoothstep(800,850,p.x))
		output[index]=final
	skin.polygon=output
