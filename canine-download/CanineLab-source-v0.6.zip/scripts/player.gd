extends CharacterBody2D
class_name Hero2D
const UNIT := 72.0
const WALK := 230.4
const RUN := 489.6
const CROUCH_SPEED := 108.0
const STAND := 124.0
const LOW := 100.0
const JUMP := 633.6
var state := "idle"
var locked := false
var input_grace := 0.0
var override_input := false
var commands := {}
var crouched := false
var coyote := 0.0
var buffer := 0.0
var slide_time := 0.0
var cooldown := 0.0
var direction := 1.0
var rig: CutoutActor
var grabbed: PhysicsProp
var grab_side := 1.0
var jumps := 0
var slides := 0
var previous_position := Vector2.ZERO
var capsule: CapsuleShape2D
var collider: CollisionShape2D
var spawn := Vector2(-1296,-2)

static func analog(raw: float) -> float:
	return signf(raw) * pow(clampf((absf(raw)-0.16)/0.84,0,1),1.2)

func _ready() -> void:
	floor_snap_length = 16
	floor_max_angle = deg_to_rad(47)
	floor_constant_speed = true
	capsule = CapsuleShape2D.new()
	capsule.radius = 19
	capsule.height = STAND
	collider = CollisionShape2D.new()
	collider.position.y = -STAND/2
	collider.shape = capsule
	add_child(collider)
	rig=CutoutActor.new()
	add_child(rig)
	collision_layer=4
	collision_mask=3
	z_index = 10
	reset()

func reset() -> void:
	grabbed=null
	position = spawn
	previous_position = position
	velocity = Vector2.ZERO
	slide_time = 0
	buffer = 0
	coyote = 0
	crouched = false
	state = "idle"
	if is_instance_valid(rig):rig.reset_pose(direction)
	capsule.height = STAND
	collider.position.y = -STAND/2

func read_command() -> Dictionary:
	if locked or input_grace>0: return {}
	if override_input: return commands
	var axis := Input.get_axis("left","right")
	var speed := RUN if Input.is_action_pressed("run") else WALK
	var keyboard := Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_RIGHT)
	if not keyboard:
		for id in Input.get_connected_joypads():
			var raw := Input.get_joy_axis(id,JOY_AXIS_LEFT_X)
			if absf(raw)>0.16:
				axis = analog(raw)
				speed = RUN if Input.is_action_pressed("run") else lerpf(WALK,RUN,smoothstep(0.45,0.95,absf(raw)))
				break
	return {"axis":axis,"speed":speed,"jump":Input.is_action_just_pressed("jump"),"held":Input.is_action_pressed("jump"),"crouch":Input.is_action_pressed("crouch"),"grab":Input.is_action_pressed("grab"),"slide":Input.is_action_just_pressed("slide") or (Input.is_action_just_pressed("crouch") and absf(velocity.x)>290)}

func clear_above() -> bool:
	var shape := CapsuleShape2D.new()
	shape.radius = 19
	shape.height = STAND
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = shape
	q.transform = Transform2D(0,global_position+Vector2(0,-STAND/2-2))
	q.exclude = [get_rid()]
	q.collision_mask = collision_mask
	return get_world_2d().direct_space_state.intersect_shape(q,1).is_empty()

func _physics_process(dt: float) -> void:
	previous_position = global_position
	input_grace=maxf(0,input_grace-dt)
	var cmd := read_command()
	var axis := clampf(float(cmd.get("axis",0)),-1,1)
	var grounded := is_on_floor()
	update_grab(cmd,axis,dt)
	coyote = 0.11 if grounded else maxf(0,coyote-dt)
	buffer = maxf(0,buffer-dt)
	cooldown = maxf(0,cooldown-dt)
	if cmd.get("jump",false): buffer=0.13
	if cmd.get("slide",false) and grounded and absf(velocity.x)>245 and cooldown<=0:
		slide_time=0.62
		cooldown=0.85
		velocity.x=signf(velocity.x)*maxf(absf(velocity.x),560)
		slides+=1
	if slide_time>0:
		slide_time=maxf(0,slide_time-dt)
		velocity.x=move_toward(velocity.x,0,518*dt)
		if not grounded or absf(velocity.x)<150: slide_time=0
	crouched = bool(cmd.get("crouch",false)) or slide_time>0 or (crouched and not clear_above())
	capsule.height = LOW if crouched else STAND
	collider.position.y=-capsule.height/2
	if slide_time<=0:
		var speed: float = CROUCH_SPEED if crouched else float(cmd.get("speed",WALK))
		if is_instance_valid(grabbed):speed=minf(speed,170)
		var target := axis*speed
		var accel := 792.0 if not grounded else (2304.0 if absf(axis)<0.01 or signf(axis)!=signf(velocity.x) else 1872.0)
		velocity.x=move_toward(velocity.x,target,accel*dt)
	if buffer>0 and coyote>0 and not(crouched and not clear_above()):
		velocity.y=-JUMP
		buffer=0
		coyote=0
		slide_time=0
		jumps+=1
	if not grounded or velocity.y<0:
		var gravity_scale:=1.65 if velocity.y>0 else (1.7 if not cmd.get("held",false) else 1.0)
		velocity.y=minf(1584,velocity.y+1728*gravity_scale*dt)
	move_and_slide()
	for i in range(get_slide_collision_count()):
		var hit:=get_slide_collision(i)
		var body=hit.get_collider()
		if body is PhysicsProp and absf(hit.get_normal().x)>0.5 and axis*hit.get_normal().x<0 and absf(body.linear_velocity.x)<250:
			body.apply_central_force(Vector2(axis*42000,0))
	if absf(axis)>0.1 and slide_time<=0: direction=signf(axis)
	if not is_on_floor(): state="jump" if velocity.y<0 else "fall"
	elif slide_time>0: state="slide"
	elif crouched: state="crouch_walk" if absf(velocity.x)>8 else "crouch"
	elif absf(velocity.x)>259: state="run"
	elif absf(velocity.x)>10: state="walk"
	else: state="idle"
	if position.y>650: reset()

func _process(dt: float) -> void:
	var interp:=previous_position.lerp(global_position,Engine.get_physics_interpolation_fraction())
	rig.global_position=interp
	rig.pose(state,velocity,direction,is_on_floor(),is_instance_valid(grabbed),minf(dt,0.05))
	queue_redraw()

func _draw() -> void:
	if is_on_floor(): draw_ellipse()
func draw_ellipse() -> void:
	draw_set_transform(Vector2(0,-2),0,Vector2(1,0.22))
	draw_circle(Vector2.ZERO,32,Color(0.02,0.04,0.05,0.17))
	draw_set_transform(Vector2.ZERO,0,Vector2.ONE)

func update_grab(cmd: Dictionary,_axis: float,_dt: float) -> void:
	if not cmd.get("grab",false) or locked or crouched:
		grabbed=null
		return
	if not is_instance_valid(grabbed):
		var shape:=CircleShape2D.new();shape.radius=90
		var q:=PhysicsShapeQueryParameters2D.new();q.shape=shape;q.transform=Transform2D(0,position+Vector2(direction*45,-40));q.collision_mask=2
		var hits:=get_world_2d().direct_space_state.intersect_shape(q,16)
		var nearest:=140.0
		for hit in hits:
			var candidate=hit.collider
			if candidate is PhysicsProp:
				var distance:=position.distance_to(candidate.position)
				if distance<nearest:grabbed=candidate;nearest=distance
		if is_instance_valid(grabbed):grab_side=signf(grabbed.position.x-position.x)
	if is_instance_valid(grabbed):
		if absf(grabbed.position.x-position.x)>170 or absf(grabbed.position.y-(position.y-40))>130:
			grabbed=null
			return
		var target:=position.x+grab_side*(19+grabbed.dimensions.x/2+7)
		var force:=clampf((target-grabbed.position.x)*1000-(grabbed.linear_velocity.x-velocity.x)*grabbed.mass*12,-45000,45000)
		grabbed.apply_central_force(Vector2(force,0))
