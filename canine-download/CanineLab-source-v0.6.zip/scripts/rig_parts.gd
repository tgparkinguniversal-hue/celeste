extends Resource
class_name CanineRigParts
@export var textures: Array[Texture2D]=[]
@export var removed_pixels:=0
@export var source_grid:=Vector2i(4,2)
