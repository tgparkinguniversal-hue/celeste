extends SceneTree
func _initialize():call_deferred("run")
func run():
	var world:=Node2D.new();root.add_child(world)
	var bg:=ColorRect.new();bg.z_index=-20;bg.color=Color("203a42");bg.size=Vector2(1280,720);world.add_child(bg)
	var font:=SystemFont.new();font.font_names=PackedStringArray(["DejaVu Sans"])
	var states:=["idle","walk","run","crouch","crouch_walk","slide","jump","fall"]
	for i in range(states.size()):
		var actor:=CutoutActor.new();world.add_child(actor);actor.position=Vector2(160+(i%4)*310,285+int(i/4)*330);actor.scale=Vector2.ONE*1.8
		for frame in range(35):actor.pose(states[i],Vector2(490 if i==2 else (108 if i==4 else (230 if i==1 else 0)),-300 if i==6 else 200),1,i<6,false,1.0/120)
		var label:=Label.new();label.add_theme_font_override("font",font);label.text=states[i];label.position=actor.position+Vector2(-45,30);world.add_child(label)
	for i in range(3):await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/canine-build/v06/rig-poses.png")
	quit()
