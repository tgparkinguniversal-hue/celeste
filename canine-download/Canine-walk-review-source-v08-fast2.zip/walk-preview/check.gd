extends SceneTree
func _initialize():call_deferred("run")
func run():
	var actor=load("res://actor.gd").new();root.add_child(actor)
	actor.animate(0,false)
	var rest_error:=0.0
	for i in range(actor.source.size()):rest_error=maxf(rest_error,actor.source[i].distance_to(actor.skin.polygon[i]))
	var head_error:=0.0;var flips:=0;var visible_flips:=0;var locations:=[];var sampled:=0
	var image:Image=actor.skin.texture.get_image()
	for frame in range(90):
		actor.animate(1.0/60,true)
		var output:PackedVector2Array=actor.skin.polygon
		var shift:Vector2=output[0]-actor.source[0]
		for i in range(actor.source.size()):
			if actor.source[i].y<710:head_error=maxf(head_error,(output[i]-actor.source[i]-shift).length())
		for tri in actor.skin.polygons:
			var area:float=(output[tri[1]]-output[tri[0]]).cross(output[tri[2]]-output[tri[0]])
			if area<=0:
				flips+=1
				var uv:Vector2=(actor.source[tri[0]]+actor.source[tri[1]]+actor.source[tri[2]])/3
				if image.get_pixel(int(uv.x),int(uv.y)).a>0.88:
					visible_flips+=1
					if locations.size()<5:locations.append(str(uv))
		sampled+=1
	print("REVIEW_CHECK ",JSON.stringify({"frames":sampled,"rest_error_px":rest_error,"head_relative_error_px":head_error,"inverted_triangles":flips,"visible_flips":visible_flips,"locations":locations}))
	quit(0 if rest_error<0.05 and head_error<0.05 and flips==0 else 1)
