extends SceneTree
func _initialize():call_deferred("run")
func run():
	var boundary_error:=0.0
	var max_stance_error:=0.0;var max_step:=0.0;var max_length_error:=0.0;var wrap_error:=0.0;var samples:=0
	for direction in [1.0,-1.0]:
		var actor=load("res://actor.gd").new();root.add_child(actor)
		actor.speed=actor.SPEED
		var previous_feet:Array[Vector2]=[];var previous_phases:Array[float]=[]
		for frame in range(1201):
			actor.animate(1.0/120,true)
			for i in range(2):
				var ankle:Vector2=actor.feet[i]-Vector2(0,17)
				max_length_error=maxf(max_length_error,absf(actor.hips[i].distance_to(actor.knees[i])-actor.UPPER))
				max_length_error=maxf(max_length_error,absf(actor.knees[i].distance_to(ankle)-actor.LOWER))
				var world:=Vector2(direction*(actor.distance+actor.feet[i].x),actor.feet[i].y)
				if frame>0:
					var change:=world.distance_to(previous_feet[i]);max_step=maxf(max_step,change)
					if actor.phases[i]<actor.STANCE and previous_phases[i]<actor.STANCE and actor.phases[i]>=previous_phases[i]:
						max_stance_error=maxf(max_stance_error,change)
					if actor.phases[i]<previous_phases[i]:wrap_error=maxf(wrap_error,change)
				if frame==0:previous_feet.append(world);previous_phases.append(actor.phases[i])
				else:previous_feet[i]=world;previous_phases[i]=actor.phases[i]
				samples+=1
		for boundary in [0.0,0.6]:
			actor.phase=fposmod(boundary-0.000001,1.0);actor.animate(0,true)
			var before:Array[Vector2]=actor.feet.duplicate()
			actor.phase=boundary+0.000001;actor.animate(0,true)
			for i in range(2):boundary_error=maxf(boundary_error,before[i].distance_to(actor.feet[i]))
		actor.queue_free()
	var result:={"boundary_position_difference_px":boundary_error,"foot_samples":samples,"max_support_drift_px":max_stance_error,"max_frame_step_120hz_px":max_step,"max_bone_length_error_px":max_length_error,"cycle_wrap_step_px":wrap_error}
	print("CONTINUITY_CHECK ",JSON.stringify(result))
	FileAccess.open("/tmp/canine-build/walk-v10/check.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	quit(0 if max_stance_error<0.01 and max_step<7.2 and max_length_error<0.01 and wrap_error<7.2 and boundary_error<0.002 else 1)
