extends SceneTree
func _initialize():call_deferred("run")
func components(mask:PackedByteArray,w:int,h:int) -> Array:
	var seen:=PackedByteArray();seen.resize(w*h);var sizes:=[]
	for start in range(w*h):
		if mask[start]==0 or seen[start]!=0:continue
		var queue:=PackedInt32Array([start]);seen[start]=1;var offset:=0
		while offset<queue.size():
			var at:=queue[offset];offset+=1;var x:=at%w;var y:=int(at/w)
			for dy in [-1,0,1]:
				for dx in [-1,0,1]:
					var nx:int=x+dx;var ny:int=y+dy
					if nx<0 or ny<0 or nx>=w or ny>=h:continue
					var k:int=ny*w+nx
					if mask[k]!=0 and seen[k]==0:seen[k]=1;queue.append(k)
		sizes.append(queue.size())
	return sizes
func run():
	var view:=SubViewport.new();view.size=Vector2i(512,512);view.transparent_bg=true;view.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(view)
	var actor=load("res://actor.gd").new();view.add_child(actor);actor.position=Vector2(256,460);actor.speed=actor.SPEED
	var detached:=[];var below:=[]
	for direction in [1,-1]:
		actor.scale=Vector2(direction,1)
		for phase in range(24):
			actor.phase=phase/24.0;actor.animate(0,true)
			await process_frame;await process_frame;await RenderingServer.frame_post_draw
			var im:=view.get_texture().get_image();var mask:=PackedByteArray();mask.resize(512*512)
			for y in range(512):
				for x in range(512):mask[y*512+x]=1 if im.get_pixel(x,y).a>0.8 else 0
			var count:=0
			for size in components(mask,512,512):
				if size>3:count+=1
			if count!=1:detached.append([direction,phase,count])
			if im.get_used_rect().end.y>462:below.append([direction,phase])
	var result:={"rendered_poses":48,"detached":detached,"under_floor":below}
	print("RENDER_CHECK ",JSON.stringify(result))
	FileAccess.open("/tmp/canine-build/walk-v10/render-check.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	quit(0 if detached.is_empty() and below.is_empty() else 1)
