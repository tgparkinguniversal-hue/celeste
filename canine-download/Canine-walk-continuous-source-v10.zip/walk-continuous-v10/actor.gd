extends Node2D
const PERIOD:=0.60
const STANCE:=0.60
const SPEED:=260.0
const UPPER:=45.0
const LOWER:=45.0
const STRIDE:=SPEED*PERIOD*STANCE
var phase:=0.0
var speed:=0.0
var distance:=0.0
var hips:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var knees:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var feet:Array[Vector2]=[Vector2.ZERO,Vector2.ZERO]
var phases:Array[float]=[0.0,0.5]
var upper:Node2D
var head:Sprite2D
var boot:AtlasTexture
var arm_material:ShaderMaterial
var body_y:=-88.0
func _ready():
	var bank:WalkFrames=load("res://approved_frames.res")
	boot=AtlasTexture.new();boot.atlas=bank.frames[0];boot.region=Rect2(95,260,90,55)
	upper=Node2D.new();upper.z_index=2;add_child(upper)
	var body:=Polygon2D.new();body.texture=bank.frames[0];body.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	var points:=PackedVector2Array([Vector2(0,0),Vector2(383,0),Vector2(383,190),Vector2(300,190),Vector2(300,185),Vector2(240,185),Vector2(220,200),Vector2(195,205),Vector2(165,220),Vector2(135,220),Vector2(130,225),Vector2(0,225)])
	body.polygon=points;body.uv=points;body.scale=Vector2.ONE*0.72;body.position=-Vector2(230,200)*0.72;upper.add_child(body)
	var shader:=Shader.new();shader.code="""shader_type canvas_item;
	uniform float swing=0.0;
	void fragment(){
	 vec2 sz=vec2(textureSize(TEXTURE,0));vec2 p=UV*sz;vec2 q=p;
	 float w=smoothstep(65.0,145.0,p.y)*(1.0-smoothstep(175.0,220.0,p.x))*smoothstep(90.0,125.0,p.x)*(1.0-smoothstep(195.0,225.0,p.y));
	 float a=-swing;mat2 r=mat2(vec2(cos(a),sin(a)),vec2(-sin(a),cos(a)));q=mix(q,vec2(170.0,65.0)+r*(p-vec2(170.0,65.0)),w);
	 vec4 c=texture(TEXTURE,q/sz);
	 if(p.y>188.0&&c.b>c.r*0.9&&c.b>c.g*0.95){discard;}
	 COLOR=c;
	}"""
	arm_material=ShaderMaterial.new();arm_material.shader=shader;body.material=arm_material
	head=Sprite2D.new();head.texture=bank.head;head.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	head.scale=Vector2.ONE*bank.head_scale*0.72
	head.position=(bank.necks[0]-Vector2(230,200))*0.72+(head.texture.get_size()/2-bank.head_anchor)*head.scale
	upper.add_child(head)
	animate(0,false)
func animate(dt:float,moving:bool):
	speed=move_toward(speed,SPEED if moving else 0.0,dt*1000)
	var step:=speed*dt;distance+=step;phase=fmod(phase+step/(SPEED*PERIOD),1.0)
	body_y=-88+sin(phase*TAU*2)*1.6
	upper.position=Vector2(0,body_y)
	upper.rotation=sin(phase*TAU)*0.018;head.rotation=-upper.rotation
	arm_material.set_shader_parameter("swing",sin(phase*TAU)*0.15)
	for i in range(2):
		var hip_x:float=18 if i==0 else -22
		hips[i]=Vector2(hip_x,body_y)
		var t:=fmod(phase+i*0.5,1.0);phases[i]=t
		var point:=Vector2(hip_x+STRIDE/2,0)
		if t<STANCE:point.x-=STRIDE*t/STANCE
		else:
			var u:float=(t-STANCE)/(1-STANCE)
			point.x=hip_x-STRIDE/2+STRIDE*(u*u*(3-2*u))
			point.y=-sin(u*PI)*25
		feet[i]=point
		var target:=point-Vector2(0,17)
		var delta:=target-hips[i];var length:=clampf(delta.length(),0.1,UPPER+LOWER-0.1)
		var angle:=delta.angle()-acos(clampf((UPPER*UPPER+length*length-LOWER*LOWER)/(2*UPPER*length),-1,1))
		knees[i]=hips[i]+Vector2.from_angle(angle)*UPPER
	queue_redraw()
func draw_limb(a:Vector2,b:Vector2,width:float,color:Color):
	draw_line(a,b,Color("302526"),width+4,false);draw_circle(a,(width+4)/2,Color("302526"));draw_circle(b,(width+4)/2,Color("302526"))
	draw_line(a,b,color,width,false);draw_circle(a,width/2,color);draw_circle(b,width/2,color)
func _draw():
	draw_limb(hips[0],hips[1],27,Color("3b3949"))
	for i in range(2):
		var shade:=Color("b4b3b4") if i==0 else Color.WHITE
		var pants:=Color("3b3549")*shade
		var ankle:=feet[i]-Vector2(0,17)
		var up:Vector2=(knees[i]-hips[i]).normalized().orthogonal()
		var down:Vector2=(ankle-knees[i]).normalized().orthogonal()
		var middle:Vector2=(up+down).normalized()
		var joint:Vector2=middle*13/maxf(0.7,middle.dot(up))
		var edge:=PackedVector2Array([hips[i]+up*15,knees[i]+joint,ankle+down*11,ankle-down*11,knees[i]-joint,hips[i]-up*15])
		draw_colored_polygon(edge,pants)
		var outline:=edge.duplicate();outline.append(edge[0]);draw_polyline(outline,Color("302526"),3,false)
		draw_colored_polygon(PackedVector2Array([hips[i]+up*4,knees[i]+middle*5,ankle+down*3,ankle,knees[i],hips[i]]),Color("4b4359")*shade)
		draw_texture_rect(boot,Rect2(ankle+Vector2(-25,-14),Vector2(54,33)),false,shade)
