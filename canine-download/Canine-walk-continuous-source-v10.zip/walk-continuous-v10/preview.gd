extends Node2D
var actor
var elapsed:=0.0
var travel:=500.0
var camera_x:=0.0
var direction:=1.0
var label:Label
var ui_font:=SystemFont.new()
func _ready():
	ui_font.font_names=PackedStringArray(["DejaVu Sans"])
	actor=load("res://actor.gd").new();add_child(actor)
	var title:=Label.new();title.text="CANINE · PASSOS CONTÍNUOS";title.position=Vector2(40,30);title.add_theme_font_override("font",ui_font);title.add_theme_font_size_override("font_size",24);add_child(title)
	label=Label.new();label.position=Vector2(40,75);label.add_theme_font_override("font",ui_font);label.add_theme_font_size_override("font_size",16);add_child(label)
	var note:=Label.new();note.text="Prévia de revisão · mesmas pernas em todo o ciclo · captura fixa de 60 FPS";note.position=Vector2(40,676);note.add_theme_font_override("font",ui_font);add_child(note)
func _process(dt):
	elapsed+=dt
	var moving:bool=(elapsed>2 and elapsed<7) or (elapsed>9 and elapsed<14)
	if elapsed>8:direction=-1
	actor.animate(dt,moving);travel+=actor.speed*direction*dt
	camera_x=lerpf(camera_x,maxf(0,travel-640),1-exp(-dt*8))
	actor.position=Vector2(travel-camera_x,610);actor.scale=Vector2(direction,1)
	label.text="APOIO → AVANÇO → APOIO" if moving else "POSE PARADA"
	queue_redraw()
	if elapsed>16:get_tree().quit()
func _draw():
	draw_rect(Rect2(0,610,1280,110),Color("23383e"));draw_line(Vector2(0,610),Vector2(1280,610),Color("adc0bb"),2)
	for tile in range(-1,22):
		var x:=tile*64-fmod(camera_x,64);draw_line(Vector2(x,615),Vector2(x,720),Color(0.5,0.6,0.6,0.16),1)
