extends Resource
class_name WalkFrames
@export var frames:Array[Texture2D]=[]
@export var necks:Array[Vector2]=[]
@export var soles:Array[float]=[]
@export var head:Texture2D
@export var head_anchor:=Vector2.ZERO
@export var head_scale:=1.0
@export var original:Texture2D
