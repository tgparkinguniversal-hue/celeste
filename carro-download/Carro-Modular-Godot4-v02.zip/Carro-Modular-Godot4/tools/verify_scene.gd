extends SceneTree
var failures=0
func verify(value:bool,message:String):
 if not value:failures+=1;push_error(message)
func make_view(size:Vector2i)->SubViewport:
 var view=SubViewport.new();view.size=size;view.transparent_bg=true;view.disable_3d=true;view.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(view);return view
func _initialize():call_deferred("run")
func run():
 var manifest=JSON.parse_string(FileAccess.get_file_as_string("res://parts_manifest.json"))
 var size=Vector2i(manifest.canvas[0],manifest.canvas[1])
 var view=make_view(size);var car=load("res://Carro.tscn").instantiate();view.add_child(car)
 var reference_view=make_view(size);var reference=Sprite2D.new();reference.texture=load("res://assets/master_clean.png");reference.centered=false;reference.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;reference_view.add_child(reference)
 verify(car.all_components().size()==23,"Expected 23 independent Sprite2D nodes")
 for c in manifest.components:
  var node=car.get_node_or_null(c.node)
  verify(node is Sprite2D,"Missing sprite "+c.node)
  if not node is Sprite2D:continue
  var r=c.canvas_rect
  verify(node.texture.get_width()==int(r[2]) and node.texture.get_height()==int(r[3]),"Texture dimensions: "+c.node)
  verify(node.global_position==Vector2(r[0],r[1]),"Original canvas alignment: "+c.node)
  verify(node.scale==Vector2.ONE,"Unexpected per-part scaling: "+c.node)
  verify(node.texture.resource_path.begins_with("res://assets/parts/"),"Baked master texture used by component: "+c.node)
 await process_frame;await process_frame;await RenderingServer.frame_post_draw
 var assembled=view.get_texture().get_image();var reference_image=reference_view.get_texture().get_image()
 assembled.convert(Image.FORMAT_RGBA8);reference_image.convert(Image.FORMAT_RGBA8)
 var diff=0
 for y in size.y:
  for x in size.x:
   if assembled.get_pixel(x,y)!=reference_image.get_pixel(x,y):diff+=1
 verify(diff==0,"Assembly differs from master at %d pixels"%diff)
 var bounds=reference_image.get_used_rect().grow(16).intersection(Rect2i(Vector2i.ZERO,size))
 assembled.get_region(bounds).save_png("res://build/carro_montado.png")
 var stripped_names=["ParaChoqueDianteiro","ParaChoqueTraseiro","SaiaLateral","Aerofolio"]
 for n in stripped_names:verify(car.set_component_visible(NodePath(n),false),"Can hide "+n)
 await process_frame;await RenderingServer.frame_post_draw
 view.get_texture().get_image().get_region(bounds).save_png("res://build/sem_bodykit.png")
 car.restore_all()
 for p in car.all_components():p.visible=p.name=="Chassi"
 await process_frame;await RenderingServer.frame_post_draw
 view.get_texture().get_image().get_region(bounds).save_png("res://build/somente_chassi.png")
 car.restore_all()
 for p in car.all_components():
  if p.name=="Aro":p.visible=false
 await process_frame;await RenderingServer.frame_post_draw
 view.get_texture().get_image().get_region(bounds).save_png("res://build/sem_aros.png")
 car.restore_all()
 verify(car.all_components().all(func(p):return p.visible),"Restore assembly")
 var report={"engine":Engine.get_version_info().string,"sprites":car.all_components().size(),"reference_canvas":[size.x,size.y],"different_pixels":diff,"independent_scale":[1,1],"failures":failures,"tested":["scene load","all nodes present","native texture size","exact canvas placement","no per-part scale","rendered master equality","bodykit removal","chassis isolation","rim removal","assembly restore"]}
 var f=FileAccess.open("res://build/validation.json",FileAccess.WRITE);f.store_string(JSON.stringify(report,"  "));f.close()
 print(JSON.stringify(report));quit(1 if failures else 0)
