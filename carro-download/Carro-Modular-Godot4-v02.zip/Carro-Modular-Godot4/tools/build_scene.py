"""Godot scene assembly with mechanical mount points; raster assets unchanged."""
import json,pathlib
p=pathlib.Path(__file__).resolve().parents[1];m=json.loads((p/'parts_manifest.json').read_text())
components=m['components'];aux=[c for c in components if 'occlusion' in c]
lines=['[gd_scene load_steps=%d format=3]'%(len(components)+len(aux)+2),'[ext_resource type="Script" path="res://car.gd" id="script"]']
for i,c in enumerate(components):
 lines.append('[ext_resource type="Texture2D" path="res://%s" id="p%d"]'%(c['texture'],i))
 if 'occlusion' in c:lines.append('[ext_resource type="Texture2D" path="res://%s" id="s%d"]'%(c['occlusion']['texture'],i))
lines+=['[node name="Carro" type="Node2D" groups=["carro"]]','texture_filter = 1','script = ExtResource("script")','metadata/canvas_width = %d'%m['canvas'][0],'metadata/canvas_height = %d'%m['canvas'][1]]
mounts={'Carroceria':(0,0),'Carroceria/ConjuntoPorta':(812,373),'Carroceria/ConjuntoParaChoqueDianteiro':(1612,447),'Carroceria/ConjuntoTampaTraseira':(760,220),'Rodas':(0,0)}
for axle in ['Traseira','Dianteira']:
 hub=next(c['pivot'] for c in components if c['name']=='Aro'+axle)
 for suffix in ['', '/Montante','/Montante/Cubo','/Montante/Cubo/ConjuntoRoda']:mounts['Rodas/Roda'+axle+suffix]=tuple(hub)
for path,pivot in mounts.items():
 parent=path.rsplit('/',1)[0] if '/' in path else '.';base=mounts.get(parent,(0,0));name=path.split('/')[-1]
 lines+=['[node name="%s" type="Node2D" parent="%s"]'%(name,parent),'position = Vector2(%s, %s)'%(pivot[0]-base[0],pivot[1]-base[1])]
for i,c in enumerate(components):
 name=c['name'];old=c.get('legacy_node',c['node']);c['legacy_node']=old
 mount='Carroceria';part=name;assembly=''
 if c['wheel']:
  axle='Traseira' if name.endswith('Traseira') else 'Dianteira';part=name.removesuffix(axle);root='Rodas/Roda'+axle+'/Montante'
  mount=root if part=='Pinca' else root+'/Cubo'
  if part in ['Pneu','Aro']:mount+='/ConjuntoRoda'
  if part=='Aro':assembly=mount
 elif name in ['Porta','Retrovisor','VidroLateral']:
  mount='Carroceria/ConjuntoPorta'
  if name=='Porta':assembly=mount
 elif name in ['ParaChoqueDianteiro','FarolDianteiro']:
  mount='Carroceria/ConjuntoParaChoqueDianteiro'
  if name=='ParaChoqueDianteiro':assembly=mount
 elif name in ['Aerofolio','VidroTraseiro']:mount='Carroceria/ConjuntoTampaTraseira'
 origin=mounts[mount];rect=c['canvas_rect'];pos=[rect[j]-origin[j] for j in range(2)]
 c['node']=mount+'/'+part;c['position']=pos;c['pivot']=list(origin);c['assembly']=assembly
 z={'Pneu':0,'Disco':1,'Pinca':2,'Aro':3}.get(part,10)
 if name in ['FarolDianteiro','LanternaTraseira','PiscaLateral']:z=20
 elif name in ['VidroLateral','VidroTraseiro','ParaBrisa','Retrovisor']:z=15
 lines+=['[node name="%s" type="Sprite2D" parent="%s" groups=["peca_carro"]]'%(part,mount),'position = Vector2(%s, %s)'%tuple(pos),'z_index = %d'%z,'texture = ExtResource("p%d")'%i,'centered = false','metadata/component_id = "%s"'%name,'metadata/legacy_node = "%s"'%old,'metadata/assembly = "%s"'%assembly]
 if 'occlusion' in c:
  shadow=c['occlusion'];offset=[shadow['canvas_rect'][j]-rect[j] for j in range(2)]
  lines+=['[node name="SombraInterna" type="Sprite2D" parent="%s" groups=["oclusao_aro"]]'%c['node'],'position = Vector2(%s, %s)'%tuple(offset),'texture = ExtResource("s%d")'%i,'centered = false']
m['hierarchy_version']=2
(p/'parts_manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
(p/'Carro.tscn').write_text('\n\n'.join(lines)+'\n')
print('Mechanical mount hierarchy generated; original canvas coordinates preserved.')
