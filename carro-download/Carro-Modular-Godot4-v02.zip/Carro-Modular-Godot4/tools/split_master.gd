extends SceneTree
# Asset preparation: masks preserve the visible pixels of one master.
# No independent rescaling or redrawing of the bodykit is involved.
const OUT="res://assets/parts/"
const HUBS={"Traseira":Vector2(564,539),"Dianteira":Vector2(1425,539)}
var parts:Dictionary={}
var source:Image
var clean:Image
var count:Dictionary={}
var masks:Array=[]
var metadata:Dictionary={}
func add_mask(name:String,coords:Array):
 var poly=PackedVector2Array()
 for pair in coords:poly.append(Vector2(pair[0],pair[1]))
 masks.append({"name":name,"polygon":poly})
func _initialize():
 DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT))
 source=Image.load_from_file("res://assets/master.png");source.convert(Image.FORMAT_RGBA8)
 clean=Image.create(source.get_width(),source.get_height(),false,Image.FORMAT_RGBA8)
 # All masks use the same unchanged canvas coordinates.
 add_mask("Aerofolio",[[238,253],[355,253],[433,331],[426,350],[271,351],[245,298]])
 add_mask("Escapamento",[[226,550],[299,558],[300,574],[439,596],[439,612],[226,613]])
 add_mask("Retrovisor",[[1115,323],[1151,322],[1176,351],[1205,373],[1111,375],[1098,354],[1099,339]])
 add_mask("LanternaTraseira",[[261,375],[318,376],[339,390],[342,418],[325,437],[260,437]])
 add_mask("FarolDianteiro",[[1630,489],[1685,489],[1696,503],[1685,516],[1632,516]])
 add_mask("PiscaLateral",[[1257,444],[1304,444],[1304,471],[1257,471]])
 add_mask("VidroTraseiro",[[429,340],[739,220],[775,219],[743,263],[738,287],[721,354],[682,363],[429,359]])
 add_mask("VidroLateral",[[806,226],[844,227],[1004,229],[1115,296],[1195,368],[811,373]])
 add_mask("ParaBrisa",[[1020,224],[1040,231],[1269,361],[1266,374],[1216,373],[1120,308]])
 add_mask("ParaChoqueDianteiro",[[1612,447],[1705,447],[1732,478],[1730,568],[1728,625],[1537,626],[1537,578],[1609,577]])
 add_mask("ParaChoqueTraseiro",[[220,438],[336,438],[341,533],[443,546],[443,602],[365,594],[277,579],[225,544]])
 add_mask("SaiaLateral",[[678,566],[1307,566],[1307,626],[678,626]])
 add_mask("Porta",[[809,374],[1201,374],[1227,398],[1239,432],[1239,500],[1226,551],[1211,568],[849,568],[828,550],[818,519]])
 add_mask("Capo",[[1265,349],[1382,349],[1382,358],[1461,363],[1461,370],[1538,388],[1589,402],[1669,425],[1680,440],[1625,439],[1559,421],[1473,401],[1365,384],[1266,380]])
 for name in ["Chassi","Aerofolio","Escapamento","Retrovisor","LanternaTraseira","FarolDianteiro","PiscaLateral","VidroTraseiro","VidroLateral","ParaBrisa","ParaChoqueDianteiro","ParaChoqueTraseiro","SaiaLateral","Porta","Capo"]:
  make_part(name)
 for axle in HUBS:
  for component in ["Pneu","Disco","Pinca","Aro"]:make_part(component+axle)
 var assigned=0
 for y in source.get_height():
  for x in source.get_width():
   var c=source.get_pixel(x,y)
   if c.a<.5:continue
   c.a=1.0;clean.set_pixel(x,y,c)
   var name=owner(Vector2(x,y),c)
   parts[name].set_pixel(x,y,c);count[name]+=1;assigned+=1
 # Full brake discs and calipers are independent surfaces.
 # The rim carries a separate occlusion mask for its original shadows.
 var hidden=0
 for axle in HUBS:
  var old_disc:Image=parts["Disco"+axle]
  parts["SombraAro"+axle]=old_disc
  var disc=Image.create(source.get_width(),source.get_height(),false,Image.FORMAT_RGBA8)
  parts["Disco"+axle]=disc
  var hub=HUBS[axle]
  for y in range(int(hub.y)-83,int(hub.y)+84):
   for x in range(int(hub.x)-83,int(hub.x)+84):
    var point=Vector2(x,y);var r=point.distance_to(hub)
    if r>82 or clean.get_pixel(x,y).a==0:continue
    var role=owner(point,clean.get_pixel(x,y))
    if role not in ["Aro"+axle,"Pinca"+axle,"Disco"+axle]:continue
    var tone=Color8(91,92,96) if r<76 else Color8(61,63,67)
    var drill=posmod(int(atan2(y-hub.y,x-hub.x)*180/PI)+360,24)<5 and r>61 and r<69
    if r<24 or drill:tone=Color8(25,26,29)
    disc.set_pixel(x,y,tone);hidden+=1
    if x>=hub.x+40 and x<=hub.x+65 and absi(y-int(hub.y))<42 and r<80 and role in ["Aro"+axle,"Disco"+axle]:
     parts["Pinca"+axle].set_pixel(x,y,Color8(172,16,12));hidden+=1
 var canvas=clean.get_size()
 var manifest={"version":1,"canvas":[canvas.x,canvas.y],"filter":"nearest","scale":[1,1],"master":"assets/master_clean.png","components":[],"normalization":"Alpha below 0.5 removed; opaque source RGB preserved. No body panel resizing.","hidden_brake_pixels":hidden}
 clean.save_png("res://assets/master_clean.png")
 for name in parts:
  if name.begins_with("SombraAro"):continue
  var im:Image=parts[name]
  var rect=im.get_used_rect()
  if rect.size.x<=0:push_error("Empty part: "+name);quit(1);return
  var path=OUT+name+".png"
  im.get_region(rect).save_png(path)
  var is_wheel=name.ends_with("Traseira") or name.ends_with("Dianteira")
  # Lights/bumpers are not wheel layers despite their axle adjectives.
  is_wheel=is_wheel and (name.begins_with("Pneu") or name.begins_with("Aro") or name.begins_with("Disco") or name.begins_with("Pinca"))
  var node_path=name
  var offset=Vector2(rect.position)
  var pivot=Vector2.ZERO
  if is_wheel:
   var axle="Traseira" if name.ends_with("Traseira") else "Dianteira"
   var part_name=name.trim_suffix(axle)
   node_path="Rodas/Roda"+axle+"/"+part_name;pivot=HUBS[axle];offset-=pivot
  elif name.begins_with("Vidro") or name=="ParaBrisa":node_path="Vidros/"+name
  elif name in ["FarolDianteiro","LanternaTraseira","PiscaLateral"]:node_path="Luzes/"+name
  manifest.components.append({"name":name,"node":node_path,"texture":"assets/parts/"+name+".png","canvas_rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"position":[offset.x,offset.y],"pivot":[pivot.x,pivot.y],"visible_pixels":count[name],"wheel":is_wheel})
 for axle in HUBS:
  var shadow:Image=parts["SombraAro"+axle]
  var rect=shadow.get_used_rect()
  var path=OUT+"SombraAro"+axle+".png"
  shadow.get_region(rect).save_png(path)
  for component in manifest.components:
   if component.name=="Aro"+axle:component["occlusion"]={"texture":"assets/parts/SombraAro"+axle+".png","canvas_rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y]}
 var f=FileAccess.open("res://parts_manifest.json",FileAccess.WRITE);f.store_string(JSON.stringify(manifest,"  "));f.close()
 print("Generated ",parts.size()," independent sprites. Visible pixels assigned: ",assigned,". Hidden brake support pixels: ",hidden)
 quit()
func make_part(name:String):
 parts[name]=Image.create(source.get_width(),source.get_height(),false,Image.FORMAT_RGBA8);count[name]=0
func owner(point:Vector2,c:Color)->String:
 for axle in HUBS:
  var r=point.distance_to(HUBS[axle])
  var paint=c.g>c.r*1.35+.025 and c.b>c.r*1.2+.025
  if r<=120 and not paint:
   if r>=92:return "Pneu"+axle
   if r<=26:return "Aro"+axle
   if c.r>c.g*1.5+.08 and c.r>c.b*1.4+.08:return "Pinca"+axle
   if r>=81 or r<=24 or maxf(c.r,maxf(c.g,c.b))>.20:return "Aro"+axle
   return "Disco"+axle
 for mask in masks:
  if Geometry2D.is_point_in_polygon(point,mask.polygon):
   if mask.name=="Escapamento" and c.g>c.r*1.35+.025 and c.b>c.r*1.2+.025:continue
   return mask.name
 return "Chassi"
