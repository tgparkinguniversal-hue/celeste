extends SceneTree
var failures=0
func check(v:bool,msg:String):
 if not v:failures+=1;push_error(msg)
func _initialize():call_deferred("run")
func run():
 var car=load("res://Carro.tscn").instantiate();root.add_child(car)
 var door=car.get_node("Carroceria/ConjuntoPorta")
 var mirror=car.component(^"Retrovisor");var glass=car.component(^"VidroLateral");var before=mirror.global_position;var glass_before=glass.global_position
 door.position+=Vector2(20,0);check(mirror.global_position==before+Vector2(20,0) and glass.global_position==glass_before+Vector2(20,0),"Door attachments follow door mount")
 door.position-=Vector2(20,0)
 car.set_component_visible(^"Porta",false);check(not mirror.is_visible_in_tree() and not glass.is_visible_in_tree(),"Removing door removes glass and mirror")
 car.restore_all();car.set_component_visible(^"ParaChoqueDianteiro",false)
 check(not car.component(^"FarolDianteiro").is_visible_in_tree(),"Bumper carries auxiliary light")
 check(car.component(^"LanternaTraseira").is_visible_in_tree(),"Rear light is independent of front bumper")
 car.restore_all();car.set_component_visible(^"AroTraseira",false)
 check(not car.component(^"PneuTraseira").is_visible_in_tree(),"Rim carries mounted tire")
 check(car.component(^"DiscoTraseira").is_visible_in_tree() and car.component(^"PincaTraseira").is_visible_in_tree(),"Brake stays on car when wheel removed")
 car.restore_all();car.set_component_visible(^"DiscoTraseira",false)
 check(car.component(^"AroTraseira").is_visible_in_tree(),"Wheel bolts to hub, not disc sprite")
 car.restore_all();var caliper=car.component(^"PincaTraseira");var transform=caliper.global_transform
 car.rotate_hubs(.35);check(caliper.global_transform==transform,"Caliper does not rotate with hub")
 check(is_equal_approx(car.component(^"DiscoTraseira").global_rotation,.35) and is_equal_approx(car.component(^"AroTraseira").global_rotation,.35),"Hub turns disc and fitted wheel")
 car.restore_all();car.isolate_component(^"Retrovisor")
 check(mirror.self_modulate.a==1 and car.component(^"Porta").self_modulate.a==0 and mirror.is_visible_in_tree(),"Isolation works with mechanical parents")
 car.restore_all();check(car.all_components().size()==23,"23 replaceable parts retained")
 print("MECHANICAL RELATIONS failures=",failures);quit(1 if failures else 0)
