extends Node2D
class_name ModularCar
func component(path:NodePath)->Sprite2D:
 var direct=get_node_or_null(path) as Sprite2D
 if direct!=null:return direct
 for sprite in all_components():
  if str(path)==str(sprite.get_meta("component_id")) or str(path)==str(sprite.get_meta("legacy_node")):return sprite
 return null
func set_component_visible(path:NodePath,enabled:bool)->bool:
 var sprite=component(path)
 if sprite==null:return false
 var assembly=str(sprite.get_meta("assembly",""))
 if assembly!="":get_node(assembly).visible=enabled
 sprite.visible=enabled
 if enabled:sprite.self_modulate=Color.WHITE
 return true
func replace_component(path:NodePath,new_texture:Texture2D,new_offset:Vector2)->bool:
 var sprite=component(path)
 if sprite==null or new_texture==null:return false
 sprite.texture=new_texture;sprite.position=new_offset
 for child in sprite.get_children():
  if child.is_in_group("oclusao_aro"):child.hide();child.set_meta("replaced",true)
 return true
func restore_all():
 _restore(self)
func _restore(node:Node):
 for child in node.get_children():
  if child.is_in_group("oclusao_aro") and not child.get_meta("replaced",false):child.visible=true
  if child is Node2D and not child.is_in_group("oclusao_aro"):
   child.visible=true;child.self_modulate=Color.WHITE
   if child is not Sprite2D:child.rotation=0
  _restore(child)
func isolate_component(path:NodePath):
 restore_all()
 var selected=component(path)
 for sprite in all_components():
  # self_modulate hides the panel without hiding its mounted children.
  sprite.self_modulate=Color.WHITE if sprite==selected else Color(1,1,1,0)
  for child in sprite.get_children():
   if child.is_in_group("oclusao_aro"):child.visible=sprite==selected and not child.get_meta("replaced",false)
func rotate_hubs(angle:float):
 for axle in ["Traseira","Dianteira"]:get_node("Rodas/Roda"+axle+"/Montante/Cubo").rotation=angle
func all_components()->Array[Sprite2D]:
 var result:Array[Sprite2D]=[];_collect(self,result);return result
func _collect(node:Node,result:Array[Sprite2D]):
 for child in node.get_children():
  if child is Sprite2D and child.is_in_group("peca_carro"):result.append(child)
  _collect(child,result)
