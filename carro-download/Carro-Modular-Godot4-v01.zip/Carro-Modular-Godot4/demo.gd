extends Control
var car:Node2D
var viewport:SubViewport
var current_part:Label
var selected_index=0
var parts:Array[Sprite2D]=[]
func _ready():
 var main=VBoxContainer.new();main.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);add_child(main)
 var title=Label.new();title.text="CARRO MODULAR • GODOT 4";title.add_theme_font_size_override("font_size",26);title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;main.add_child(title)
 var help=Label.new();help.text="Cada peça é um Sprite2D independente. Use os controles abaixo para desmontar e conferir o encaixe.";help.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;main.add_child(help)
 var container=SubViewportContainer.new();container.stretch=true;container.size_flags_vertical=Control.SIZE_EXPAND_FILL;main.add_child(container)
 viewport=SubViewport.new();viewport.size=Vector2i(1280,500);viewport.transparent_bg=true;viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS;container.add_child(viewport)
 car=load("res://Carro.tscn").instantiate();viewport.add_child(car);parts=car.all_components()
 var bar=HBoxContainer.new();bar.alignment=BoxContainer.ALIGNMENT_CENTER;main.add_child(bar)
 for data in [["◀ Peça anterior",func():selected_index=posmod(selected_index-1,parts.size());refresh()],["Ocultar / mostrar",func():parts[selected_index].visible=not parts[selected_index].visible;refresh()],["Próxima peça ▶",func():selected_index=posmod(selected_index+1,parts.size());refresh()],["Mostrar só esta",func():
  for p in parts:p.visible=p==parts[selected_index]
  refresh()
 ],["Montar tudo",func():car.restore_all();refresh()]]:
  var b=Button.new();b.text=data[0];b.custom_minimum_size=Vector2(190,52);b.pressed.connect(data[1]);bar.add_child(b)
 current_part=Label.new();current_part.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;current_part.custom_minimum_size.y=40;current_part.add_theme_font_size_override("font_size",20);main.add_child(current_part)
 var list=HBoxContainer.new();list.alignment=BoxContainer.ALIGNMENT_CENTER;main.add_child(list)
 for info in [["Sem bodykit",func():
  car.restore_all()
  for n in ["ParaChoqueDianteiro","ParaChoqueTraseiro","SaiaLateral","Aerofolio"]:car.set_component_visible(NodePath(n),false)
  refresh()
 ],["Somente chassi",func():
  for p in parts:p.visible=p.name=="Chassi"
  refresh()
 ],["Sem aros",func():
  car.restore_all()
  for p in parts:
   if p.name=="Aro":p.visible=false
  refresh()
 ]]:
  var b=Button.new();b.text=info[0];b.custom_minimum_size=Vector2(220,44);b.pressed.connect(info[1]);list.add_child(b)
 resized.connect(fit_car);viewport.size_changed.connect(fit_car);call_deferred("fit_car");refresh()
func fit_car():
 if not is_instance_valid(car):return
 var dimensions=Vector2(car.get_meta("canvas_width"),car.get_meta("canvas_height"))
 var fit=minf((viewport.size.x-60)/dimensions.x,(viewport.size.y-30)/dimensions.y)
 car.scale=Vector2.ONE*fit;car.position=(Vector2(viewport.size)-dimensions*fit)/2
func refresh():
 var p=parts[selected_index]
 current_part.text="%d / %d • %s • %s"%[selected_index+1,parts.size(),str(car.get_path_to(p)),"visível" if p.visible else "oculta"]
