"""Serialize the Godot scene and component transforms; no raster manipulation."""
import json,pathlib
p=pathlib.Path(__file__).resolve().parents[1];m=json.loads((p/'parts_manifest.json').read_text())
aux=[c for c in m['components'] if 'occlusion' in c]
lines=['[gd_scene load_steps=%d format=3]'%(len(m['components'])+len(aux)+2),'[ext_resource type="Script" path="res://car.gd" id="script"]']
for i,c in enumerate(m['components']):
 lines.append('[ext_resource type="Texture2D" path="res://%s" id="p%d"]'%(c['texture'],i))
 if 'occlusion' in c:lines.append('[ext_resource type="Texture2D" path="res://%s" id="s%d"]'%(c['occlusion']['texture'],i))
lines+=['[node name="Carro" type="Node2D" groups=["carro"]]','texture_filter = 1','script = ExtResource("script")','metadata/canvas_width = %d'%m['canvas'][0],'metadata/canvas_height = %d'%m['canvas'][1], '[node name="Vidros" type="Node2D" parent="."]','[node name="Luzes" type="Node2D" parent="."]','[node name="Rodas" type="Node2D" parent="."]']
for axle in ['Traseira','Dianteira']:
 c=next(c for c in m['components'] if c['name']=='Aro'+axle)
 lines+=['[node name="Roda%s" type="Node2D" parent="Rodas"]'%axle,'position = Vector2(%s, %s)'%tuple(c['pivot'])]
for i,c in enumerate(m['components']):
 path=c['node'].split('/');name=path[-1];parent='/'.join(path[:-1]) or '.'
 z=10
 if c['wheel']:z={'Pneu':0,'Disco':1,'Pinca':2,'Aro':3}[name]
 elif parent=='Luzes':z=20
 elif c['name'] in ['VidroLateral','VidroTraseiro','ParaBrisa','Retrovisor']:z=15
 lines+=['[node name="%s" type="Sprite2D" parent="%s" groups=["peca_carro"]]'%(name,parent),'position = Vector2(%s, %s)'%tuple(c['position']),'z_index = %d'%z,'texture = ExtResource("p%d")'%i,'centered = false','metadata/component_id = "%s"'%c['name']]
 if 'occlusion' in c:
  shadow=c['occlusion'];pos=[shadow['canvas_rect'][j]-c['canvas_rect'][j] for j in range(2)]
  lines+=['[node name="SombraInterna" type="Sprite2D" parent="%s" groups=["oclusao_aro"]]'%c['node'],'position = Vector2(%s, %s)'%tuple(pos),'texture = ExtResource("s%d")'%i,'centered = false']
(p/'Carro.tscn').write_text('\n\n'.join(lines)+'\n')
print('Scene:',len(m['components']),'components and',len(aux),'internal rim occlusion masks')
