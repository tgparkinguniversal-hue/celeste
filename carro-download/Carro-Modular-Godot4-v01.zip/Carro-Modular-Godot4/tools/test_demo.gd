extends SceneTree
func _initialize():call_deferred("run")
func run():
 var scene=load("res://demo.tscn").instantiate();root.add_child(scene)
 await process_frame;await process_frame
 assert(scene.parts.size()==23)
 var rim=scene.car.get_node("Rodas/RodaTraseira/Aro")
 rim.hide();assert(not rim.get_node("SombraInterna").is_visible_in_tree())
 scene.car.restore_all();assert(rim.visible)
 scene.car.set_component_visible(^"ParaChoqueDianteiro",false)
 assert(not scene.car.get_node("ParaChoqueDianteiro").visible)
 scene.car.restore_all();print("DEMO PASS: 23 components; rim shadow inheritance and bodykit toggle.");quit()
