extends Node2D
class_name ModularCar
## All component positions originate from the same master canvas.
## Sprite textures contain no other component's visible pixels.
func component(path:NodePath)->Sprite2D:
 return get_node_or_null(path) as Sprite2D
func set_component_visible(path:NodePath,enabled:bool)->bool:
 var sprite=component(path)
 if sprite==null:return false
 sprite.visible=enabled
 return true
func replace_component(path:NodePath,new_texture:Texture2D,new_offset:Vector2)->bool:
 var sprite=component(path)
 if sprite==null or new_texture==null:return false
 sprite.texture=new_texture
 sprite.position=new_offset
 for child in sprite.get_children():
  if child.is_in_group("oclusao_aro"):child.hide()
 return true
func restore_all():
 for child in all_components():child.visible=true;child.modulate=Color.WHITE
func all_components()->Array[Sprite2D]:
 var result:Array[Sprite2D]=[]
 _collect(self,result)
 return result
func _collect(node:Node,result:Array[Sprite2D]):
 for child in node.get_children():
  if child is Sprite2D and child.is_in_group("peca_carro"):result.append(child)
  _collect(child,result)
