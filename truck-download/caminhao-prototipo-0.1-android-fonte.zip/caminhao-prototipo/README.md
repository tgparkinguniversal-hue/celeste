# Eixo — caminhão isométrico, protótipo 0.1

Abra caminhao-teste.html em um navegador. É autocontido e funciona sem rede ou instalação. index.html usa os arquivos JS separados para desenvolvimento. No celular, prefira tela horizontal.

W/↑ acelera; S/↓ freia; A/D ou ←/→ dirigem; espaço aciona freio de mão; R alterna frente/ré quando quase parado. Botões na tela suportam múltiplos toques. Repor reinicia a posição.

Visual: geometria projetada em perspectiva ortográfica isométrica, rasterização de baixa resolução, cabine bege, módulo verde escuro e caçamba marrom inspirados na referência. Não é uma reprodução idêntica do asset original nem o PNG gerado antes. Geometria gira no mundo em vez de rotacionar uma fotografia plana.

Física: passo fixo 120 Hz, massa nominal 9 toneladas, forças laterais nos pneus, saturação por aderência, direção dependente da velocidade, força motriz, resistência, inércia linear/angular, frenagem, ré, freio traseiro de mão. Modelo de dois eixos equivalente ao veículo de três eixos. Rodas visuais são seis; eixos traseiros são agrupados na física.

Limites: terreno plano, sem suspensão, transferência dinâmica de carga, deformação de pneus, caixa de marchas detalhada, tombamento ou carga variável. Colisões usam um círculo para o caminhão: são aproximações de teste, não correspondem à carroceria inteira. Não é uma simulação automotiva validada. Não há saves ou conteúdo de campanha. O APK de teste está disponível como descrito abaixo.

Verificação: node test_physics.cjs. Testa repouso, aceleração, desaceleração livre, frenagem, curva, ré e finitude numérica. Chromium headless verificou carregamento e aceleração por teclado sem erros JavaScript. Não foi testado em celular físico.

Teste Chromium adicional com dois toques simultâneos via CDP: acelerar + virar, ambos os botões ativos, sem erros JavaScript; soltura removeu os estados ativos. Não substitui teste no aparelho.

## Android 0.1

APK: eixo-caminhao-0.1.apk. Aplicativo Android com WebView, dados locais incorporados, sem permissão de internet. Não é uma conversão para engine 3D nativa. Android 6 ou superior; depende de Android System WebView instalado/funcional. Orientação horizontal, tela imersiva e controles multitoque do mesmo protótipo. Build de desenvolvimento assinada com chave debug.

Pacote org.eixo.truck, versionCode 1, target SDK 35. Assinatura APK verificada em v1/v2/v3 e manifesto inspecionado. Sem teste de instalação/execução em Android: adb não encontrou aparelhos. Os testes Chromium anteriores validam o conteúdo web, não a integração WebView em aparelho.

Fontes Java, manifesto, ícone vetorial e script de build estão em android/. O arquivo de assinatura não é distribuído. O script usa ferramentas já instaladas neste ambiente; outros ambientes precisam configurar os caminhos SDK/JDK e TRUCK_DEBUG_KEYSTORE.
