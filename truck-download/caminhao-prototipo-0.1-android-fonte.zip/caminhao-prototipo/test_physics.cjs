const assert=require('node:assert/strict');const {Truck}=require('./physics.js');
function run(t,seconds,input){for(let i=0;i<seconds*120;i++)t.step(1/120,input);}
let t=new Truck();run(t,3,{});assert.equal(t.speed,0);
run(t,8,{throttle:1});assert(t.speed>8&&t.speed<20);let speed=t.speed;
run(t,1,{});assert(t.speed>speed*.7&&t.speed<speed);
run(t,4,{brake:1});assert(t.speed<.1);
t=new Truck();run(t,5,{throttle:1});let a=t.a;run(t,3,{throttle:1,steer:1});assert(t.a>a+.15);
t=new Truck();t.gear=-1;run(t,3,{throttle:1});assert(t.vx*Math.cos(t.a)+t.vy*Math.sin(t.a)<-1);
for(let i=0;i<6000;i++){t.step(1/120,{throttle:1,steer:Math.sin(i*.02),handbrake:i%200<30},[{x:8,y:8,r:2}]);assert([t.x,t.y,t.vx,t.vy,t.a,t.w].every(Number.isFinite));}
console.log('PASS: repouso, aceleração, inércia, frenagem, direção, ré e estabilidade numérica');
