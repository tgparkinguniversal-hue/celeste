"""Build offline Android WebView package using existing Android SDK/JDK tools."""
import os,subprocess,zipfile,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
sdk=Path(os.environ.get('ANDROID_SDK_ROOT','/workspace/android-sdk'))
jdk=Path(os.environ.get('JAVA_HOME','/workspace/tools/jdk17-package/usr/lib/jvm/msopenjdk-17-amd64'))
work=Path('/tmp/truck-apk');work.mkdir(exist_ok=True)
bt=sdk/'build-tools/35.0.0';android=sdk/'platforms/android-35/android.jar'
env=dict(os.environ,JAVA_HOME=str(jdk));env['PATH']=str(jdk/'bin')+os.pathsep+env['PATH']
def run(*args):subprocess.run([str(x) for x in args],check=True,env=env)
for d in ['assets','classes','dex']:(work/d).mkdir(exist_ok=True)
shutil.copyfile(root.parent/'caminhao-teste.html',work/'assets/index.html')
run(bt/'aapt','package','-f','-M',root/'AndroidManifest.xml','-S',root/'res','-A',work/'assets','-I',android,'-F',work/'unsigned.apk')
run(jdk/'bin/javac','--release','8','-cp',android,'-d',work/'classes',root/'src/org/eixo/truck/MainActivity.java')
run(jdk/'bin/jar','cf',work/'activity.jar','-C',work/'classes','.')
run(bt/'d8','--lib',android,'--min-api','23','--output',work/'dex',work/'activity.jar')
with zipfile.ZipFile(work/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:z.write(work/'dex/classes.dex','classes.dex')
run(bt/'zipalign','-f','4',work/'unsigned.apk',work/'aligned.apk')
# Standard development-only Android debug identity, not a production signing key.
key=Path(os.environ.get('TRUCK_DEBUG_KEYSTORE','/workspace/godot-config/godot/debug.keystore'))
output=Path('/workspace/artifacts/eixo-caminhao-0.1.apk')
run(bt/'apksigner','sign','--ks',key,'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',output,work/'aligned.apk')
run(bt/'apksigner','verify','--verbose',output)
run(bt/'aapt','dump','badging',output)
print(output)
