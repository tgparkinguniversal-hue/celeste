'use strict';
const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d',{alpha:false});
const truck=new Truck(),keys=new Set(),touch=new Map();let running=false,last=0,acc=0,cam={x:0,y:0},zoom=14;
const obstacles=[{x:15,y:8,r:1.3},{x:21,y:8,r:1.3},{x:27,y:8,r:1.3},{x:-16,y:14,r:2},{x:8,y:-20,r:1.6}];
function resize(){const ratio=2;canvas.width=Math.ceil(innerWidth/ratio);canvas.height=Math.ceil(innerHeight/ratio);ctx.imageSmoothingEnabled=false;zoom=Math.min(canvas.width,canvas.height)/23;}
addEventListener('resize',resize);resize();
const bindings={KeyW:'throttle',ArrowUp:'throttle',KeyS:'brake',ArrowDown:'brake',KeyA:'left',ArrowLeft:'left',KeyD:'right',ArrowRight:'right',Space:'handbrake'};
addEventListener('keydown',e=>{if(bindings[e.code]){keys.add(bindings[e.code]);e.preventDefault();}if(e.code==='KeyR'&&!e.repeat)reverse();});
addEventListener('keyup',e=>{if(bindings[e.code])keys.delete(bindings[e.code]);});
function clear(){keys.clear();touch.clear();document.querySelectorAll('.on').forEach(b=>b.classList.remove('on'));acc=0;}
addEventListener('blur',clear);document.addEventListener('visibilitychange',()=>{clear();last=0;});
for(const b of document.querySelectorAll('[data-key]')){
 b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);touch.set(e.pointerId,b.dataset.key);b.classList.add('on');});
 const release=e=>{touch.delete(e.pointerId);if(![...touch.values()].includes(b.dataset.key))b.classList.remove('on');};b.addEventListener('pointerup',release);b.addEventListener('pointercancel',release);b.addEventListener('lostpointercapture',release);
}
function reverse(){if(Math.hypot(truck.vx,truck.vy)<.8){truck.gear*=-1;document.querySelector('#reverse').textContent=truck.gear>0?'D ▸':'◂ R';}}
document.querySelector('#reverse').onclick=reverse;document.querySelector('#reset').onclick=()=>{truck.reset();cam.x=0;cam.y=0;clear();document.querySelector('#reverse').textContent='D ▸';};
document.querySelector('#play').onclick=()=>{document.querySelector('#help').style.display='none';running=true;last=0;};document.querySelector('#info').onclick=()=>{running=false;clear();document.querySelector('#help').style.display='grid';};
function has(k){return keys.has(k)||[...touch.values()].includes(k);}
function project(x,y,z=0){const dx=x-cam.x,dy=y-cam.y;return [Math.round(canvas.width/2+(dx-dy)*.866*zoom),Math.round(canvas.height*.49+(dx+dy)*.43*zoom-z*zoom)];}
function poly(points,color){ctx.fillStyle=color;ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fill();}
function worldbox(x,y,z,l,w,h,color){const v=(a,b,c)=>project(x+a,y+b,z+c);poly([v(0,0,0),v(l,0,0),v(l,0,h),v(0,0,h)],color[1]);poly([v(l,0,0),v(l,w,0),v(l,w,h),v(l,0,h)],color[2]);poly([v(0,0,h),v(l,0,h),v(l,w,h),v(0,w,h)],color[0]);}
function local(x,y,z){const c=Math.cos(truck.a),s=Math.sin(truck.a);return project(truck.x+x*c-y*s,truck.y+x*s+y*c,z);}
function box(x,y,z,l,w,h,colors){const v=(a,b,c)=>local(x+a,y+b,z+c);const faces=[{depth:0,p:[v(0,0,0),v(l,0,0),v(l,0,h),v(0,0,h)],c:colors[1]},{p:[v(l,0,0),v(l,w,0),v(l,w,h),v(l,0,h)],c:colors[2]},{p:[v(l,w,0),v(0,w,0),v(0,w,h),v(l,w,h)],c:colors[2]},{p:[v(0,w,0),v(0,0,0),v(0,0,h),v(0,w,h)],c:colors[1]}];
 // Draw only the two camera-facing vertical sides, then the top.
 const cs=Math.cos(truck.a),sn=Math.sin(truck.a);const nx=cs+sn,ny=cs-sn;
 for(const i of [nx>0?1:3,ny>0?2:0])poly(faces[i].p,faces[i].c);
 poly([v(0,0,h),v(l,0,h),v(l,w,h),v(0,w,h)],colors[0]);}
const steel=['#45463a','#232a25','#30362b'],rust=['#855638','#513824','#66412b'],tan=['#9d8860','#64583f','#7f6b4d'];
function wheel(x,y){const p=local(x,y,.47);const r=zoom*.62;ctx.fillStyle='#171e1c';ctx.beginPath();ctx.ellipse(...p,r*.86,r*.7,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#353b34';ctx.beginPath();ctx.ellipse(...p,r*.56,r*.47,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#73776b';ctx.fillRect(p[0]-2,p[1]-2,4,4);}
function drawTruck(){
 const shadow=project(truck.x,truck.y);ctx.fillStyle='#26352a88';ctx.beginPath();ctx.ellipse(shadow[0],shadow[1]+zoom*.35,zoom*3.9,zoom*.95,0,0,Math.PI*2);ctx.fill();
 const c=Math.cos(truck.a),s=Math.sin(truck.a),nearSide=c-s>0?1:-1;
 for(const x of [-2.6,-1.15,2.25])wheel(x,-nearSide*1.17);
 box(-3.4,-1.05,.55,6.6,2.1,.35,steel);
 // Rear open rust-colored cargo box: floor and four low walls.
 box(-3.4,-1.05,.92,2.1,2.1,.14,rust);
 box(-3.4,-1.05,1.05,2.1,.12,.76,rust);box(-3.4,.93,1.05,2.1,.12,.76,rust);
 box(-3.4,-1.05,1.05,.12,2.1,.76,rust);box(-1.42,-1.05,1.05,.12,2.1,.76,rust);
 // Dark olive utility module and roof fittings.
 box(-1.15,-1.02,.94,2.1,2.04,1.14,['#596047','#292f25','#343a2b']);
 for(const x of [-1.13,.85])for(const y of [-1.04,1.0])box(x,y,.94,.08,.08,1.2,rust);
 for(let i=0;i<8;i++)box(-.94+(i%4)*.46,-.72+Math.floor(i/4)*1.05,2.08,.11,.11,.07,steel);
 // Cab, low hood, windshield and side windows.
 box(1.22,-1.07,.94,1.7,2.14,1.52,tan);box(2.92,-1.0,.95,.47,2,.82,tan);
 box(2.925,-.88,1.77,.025,1.76,.52,['#647b78','#293d3e','#3b5351']);
 for(const side of [-1,1]){box(1.65,side>0?1.075:-1.1,1.64,.78,.025,.51,['#6c8180','#31474a','#35494b']);box(1.85,side>0?1.12:-1.22,1.48,.22,.1,.055,steel);}
 box(3.35,-1.17,.5,.14,2.34,.22,steel);
 for(const y of [-.82,.6])box(3.39,y,1.05,.055,.22,.15,['#cfbf79','#a18d57','#d6c385']);
 for(const x of [-2.6,-1.15,2.25])wheel(x,nearSide*1.18);
 // Rust patches and straps stay attached in local 3D space.
 for(let i=0;i<12;i++){let x=-3.2+(i*17%100)/100*1.6,y=-.8+(i*37%100)/100*1.6;box(x,y,1.065,.14,.12,.015,['#745033','#533a28','#64422a']);}
 for(const x of [-2.9,-1.65])box(x,-1.08,1.07,.045,2.16,.025,steel);
 box(-2.8,nearSide>0?1.057:-1.075,1.17,.62,.018,.3,['#a69f83','#9d957d','#aaa186']);
 // Pixel weathering, stable local-space clusters.
 for(let i=0;i<16;i++){const x=1.3+(i*31%100)/100*1.4,y=-.9+(i*47%100)/100*1.7;poly([local(x,y,2.463),local(x+.12,y,2.463),local(x+.12,y+.07,2.463),local(x,y+.07,2.463)],i%2?'#8e7955':'#aa956a');}
}
function draw(){ctx.fillStyle='#526347';ctx.fillRect(0,0,canvas.width,canvas.height);
 const startX=Math.floor(cam.x/5)*5,startY=Math.floor(cam.y/5)*5;
 for(let x=startX-42;x<startX+42;x+=3)for(let y=startY-42;y<startY+42;y+=3){const seed=Math.abs(Math.sin(x*12.4+y*44.1));const p=project(x+seed*2,y+seed);ctx.fillStyle=seed>.5?'#75804b':'#5e704a';ctx.fillRect(p[0],p[1],2,2);if(seed>.5)ctx.fillRect(p[0]+2,p[1]-2,1,3);}
 poly([project(-90,-5),project(90,-5),project(90,5),project(-90,5)],'#756f5b');
 for(let x=Math.floor((cam.x-50)/5)*5;x<cam.x+50;x+=5)poly([project(x,-.08),project(x+2,-.08),project(x+2,.08),project(x,.08)],'#b1a583');
 const items=obstacles.map(o=>({depth:o.x+o.y,draw:()=>worldbox(o.x-o.r/2,o.y-o.r/2,0,o.r,o.r,1.3,['#a18b67','#665c47','#807255'])}));items.push({depth:truck.x+truck.y,draw:drawTruck});items.sort((a,b)=>a.depth-b.depth);items.forEach(o=>o.draw());
 document.querySelector('#speed').textContent=Math.round(Math.hypot(truck.vx,truck.vy)*3.6)+' km/h';document.querySelector('#stats').textContent='9,0 t · '+(truck.gear>0?'FRENTE':'RÉ')+'\nAderência '+(truck.slip>.3?'baixa':'normal');}
function frame(now){if(!last)last=now;const delta=Math.min((now-last)/1000,.1);last=now;if(running){acc+=delta;const input={steer:(has('right')?1:0)-(has('left')?1:0),throttle:has('throttle')?1:0,brake:has('brake')?1:0,handbrake:has('handbrake')};while(acc>=1/120){truck.step(1/120,input,obstacles);acc-=1/120;}const t=1-Math.exp(-delta*5);cam.x+=(truck.x-cam.x)*t;cam.y+=(truck.y-cam.y)*t;}draw();requestAnimationFrame(frame);}requestAnimationFrame(frame);
