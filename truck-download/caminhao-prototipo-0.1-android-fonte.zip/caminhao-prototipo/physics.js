(function(root){
'use strict';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
class Truck {
 constructor(){this.reset();}
 reset(){Object.assign(this,{x:0,y:0,vx:0,vy:0,a:-Math.PI/4,w:0,steer:0,gear:1,speed:0,slip:0,damage:0});}
 step(dt,input,obstacles=[]){
  const mass=9000,inertia=37000,g=9.81,front=2.3,rear=-1.7;
  const c=Math.cos(this.a),s=Math.sin(this.a),fx=c,fy=s,rx=-s,ry=c;
  const longitudinal=this.vx*fx+this.vy*fy, lateral=this.vx*rx+this.vy*ry;
  this.speed=Math.hypot(this.vx,this.vy);
  const target=clamp(input.steer||0,-1,1)*(.52/(1+this.speed*.035));
  this.steer+=clamp(target-this.steer,-dt*1.3,dt*1.3);
  let forceX=0,forceY=0,torque=0,maxSlip=0;
  const drive=clamp(input.throttle||0,0,1)*this.gear*18000/(1+Math.abs(longitudinal)/12);
  for(const axle of [{z:front,share:.43,angle:this.steer,drive:.25},{z:rear,share:.57,angle:0,drive:.75}]){
   const ca=Math.cos(this.a+axle.angle),sa=Math.sin(this.a+axle.angle);
   const ux=this.vx-this.w*axle.z*s,uy=this.vy+this.w*axle.z*c;
   const along=ux*ca+uy*sa,across=-ux*sa+uy*ca;
   const slip=Math.atan2(across,Math.abs(along)+1.5);
   maxSlip=Math.max(maxSlip,Math.abs(slip));
   let side=-slip*mass*g*axle.share*5;
   const stopping=Math.min(Math.abs(along)*mass*axle.share/Math.max(dt,.001),mass*g*axle.share*.9);
   let thrust=drive*axle.drive-Math.sign(along)*stopping*clamp(input.brake||0,0,1);
   if(axle.z<0 && input.handbrake)thrust-=Math.sign(along)*stopping;
   const grip=mass*g*axle.share*(input.handbrake&&axle.z<0?.42:.82);
   const norm=Math.hypot(thrust,side);if(norm>grip){thrust*=grip/norm;side*=grip/norm;}
   const ax=ca*thrust-sa*side,ay=sa*thrust+ca*side;
   forceX+=ax;forceY+=ay;torque+=axle.z*(c*ay-s*ax);
  }
  const resistance=(160+this.speed*9+this.speed*this.speed*3.6);
  if(this.speed>.03){forceX-=resistance*this.vx/this.speed;forceY-=resistance*this.vy/this.speed;}
  this.vx+=forceX/mass*dt;this.vy+=forceY/mass*dt;
  this.w+=(torque/inertia-this.w*.12)*dt;
  this.a+=this.w*dt;this.x+=this.vx*dt;this.y+=this.vy*dt;this.slip=maxSlip;
  if(!input.throttle&&this.speed<.05&&Math.abs(this.w)<.02){this.vx=0;this.vy=0;this.w=0;}
  for(const o of obstacles){const dx=this.x-o.x,dy=this.y-o.y,d=Math.hypot(dx,dy),r=o.r+1.25;
   if(d<r){const nx=dx/(d||1),ny=dy/(d||1);this.x=o.x+nx*r;this.y=o.y+ny*r;
    const impact=this.vx*nx+this.vy*ny;if(impact<0){this.vx-=impact*1.08*nx;this.vy-=impact*1.08*ny;this.w*=.4;this.damage=Math.min(100,this.damage+Math.abs(impact)*2);}}
  }
  return {longitudinal,lateral};
 }
}
if(typeof module!=='undefined')module.exports={Truck};else root.Truck=Truck;
})(globalThis);
